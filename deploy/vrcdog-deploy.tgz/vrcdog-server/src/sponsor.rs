//! 爱发电赞助：配置、名单与特权。
//!
//! 与社区模块同一套持久化风格：数据挂在 `PersistentData.sponsor`，改完调用
//! `crate::schedule_persist`，由主进程统一落盘。
//!
//! 设计目标：
//! - 支付路径最短：客户端直接打开管理端配置的爱发电链接，回来填昵称认领；
//! - 管理员完全掌控：开关、链接、自动通过、受限功能目录、赞助者特权、默认时长，
//!   以及赞助名单的增删改查；
//! - 特权落到「功能键」上：客户端 `sponsorStore` 按服务端下发的 `gated_features`
//!   判断哪些入口需要赞助，按 `features` 判断当前用户解锁了什么。

use axum::{
    extract::{Path, State},
    http::StatusCode,
    response::{IntoResponse, Response},
    Extension, Json,
};
use chrono::{Local, NaiveDate};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::HashMap;

use crate::AppState;

const DEFAULT_FEATURES: [&str; 3] = ["rvc", "translator", "drawing"];

fn default_true() -> bool {
    true
}

fn default_features() -> Vec<String> {
    DEFAULT_FEATURES.iter().map(|item| item.to_string()).collect()
}

fn default_days() -> i64 {
    30
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct SponsorSettings {
    #[serde(default = "default_true")]
    pub enabled: bool,
    /// 爱发电主页 / 赞助页；客户端「去赞助」直接打开它。
    #[serde(default)]
    pub afdian_url: String,
    /// 认领即通过：信任昵称匹配，不再等管理员审核。
    #[serde(default = "default_true")]
    pub auto_approve: bool,
    /// 需要赞助才能使用的功能键（客户端据此上锁）。
    #[serde(default = "default_features")]
    pub gated_features: Vec<String>,
    /// 赞助者实际解锁的功能键（通常等于或小于上面的目录）。
    #[serde(default = "default_features")]
    pub features: Vec<String>,
    /// 自动通过 / 手动发放的默认有效天数；0 表示永久。
    #[serde(default = "default_days")]
    pub default_days: i64,
    /// 认领时要求的最低累计赞助额（元）；0 不限制。
    #[serde(default)]
    pub min_amount: f64,
}

impl Default for SponsorSettings {
    fn default() -> Self {
        Self {
            enabled: true,
            afdian_url: String::new(),
            auto_approve: true,
            gated_features: default_features(),
            features: default_features(),
            default_days: default_days(),
            min_amount: 0.0,
        }
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct SponsorRecord {
    pub id: String,
    #[serde(default)]
    pub user_id: String,
    #[serde(default)]
    pub nickname: String,
    #[serde(default)]
    pub plan_name: String,
    #[serde(default)]
    pub amount: f64,
    #[serde(default)]
    pub features: Vec<String>,
    /// `YYYY-MM-DD`；空表示永久。
    #[serde(default)]
    pub expires_at: String,
    #[serde(default)]
    pub note: String,
    #[serde(default)]
    pub created_at: String,
    /// 管理员可手动停用（不删除记录）。
    #[serde(default = "default_true")]
    pub active: bool,
}

#[derive(Clone, Serialize, Deserialize, Default, Debug)]
pub struct SponsorData {
    #[serde(default)]
    pub settings: SponsorSettings,
    #[serde(default)]
    pub sponsors: HashMap<String, SponsorRecord>,
}

impl SponsorData {
    /// 生效中的记录：active 且未过期。
    pub fn active_record(&self, user_id: &str) -> Option<&SponsorRecord> {
        self.sponsors
            .values()
            .filter(|record| record.active && !record.user_id.is_empty() && record.user_id == user_id)
            .filter(|record| !expired(&record.expires_at))
            .max_by(|left, right| left.created_at.cmp(&right.created_at))
    }

    fn find_by_nickname(&self, nickname: &str) -> Option<&SponsorRecord> {
        let target = nickname.trim().to_lowercase();
        if target.is_empty() {
            return None;
        }
        self.sponsors
            .values()
            .find(|record| record.nickname.trim().to_lowercase() == target)
    }
}

fn expired(expires_at: &str) -> bool {
    let trimmed = expires_at.trim();
    if trimmed.is_empty() {
        return false;
    }
    let Ok(date) = NaiveDate::parse_from_str(trimmed, "%Y-%m-%d") else {
        return false;
    };
    date < Local::now().date_naive()
}

fn now_string() -> String {
    Local::now().format("%Y-%m-%d %H:%M:%S").to_string()
}

fn new_id() -> String {
    format!("sp_{}", uuid::Uuid::new_v4().simple())
}

fn validate_settings(settings: &SponsorSettings) -> Result<(), String> {
    if settings.default_days < 0 || settings.default_days > 3650 {
        return Err("default_days 必须在 0-3650 之间".to_string());
    }
    if settings.min_amount < 0.0 || settings.min_amount > 100_000.0 {
        return Err("min_amount 必须在 0-100000 之间".to_string());
    }
    if settings.afdian_url.len() > 300 {
        return Err("爱发电链接过长".to_string());
    }
    if settings.afdian_url.trim_start().starts_with("javascript:") {
        return Err("爱发电链接不能是 javascript:".to_string());
    }
    Ok(())
}

// ─── 客户端 ──────────────────────────────────────────────────────────────────

/// `GET /api/client/sponsor/{user_id}`：返回开关、赞助入口、当前用户特权。
pub async fn client_status(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Path(user_id): Path<String>,
) -> Json<Value> {
    if verified_user_id != user_id {
        return Json(json!({ "status": "auth_failed", "active": false }));
    }
    let data = state.data.read().await;
    let sponsor = &data.sponsor;
    let record = sponsor.active_record(&user_id);
    Json(json!({
        "status": "ok",
        "enabled": sponsor.settings.enabled,
        "afdian_url": sponsor.settings.afdian_url,
        "auto_approve": sponsor.settings.auto_approve,
        "gated_features": sponsor.settings.gated_features,
        "features": sponsor.settings.features,
        "active": record.is_some(),
        "record": record,
    }))
}

#[derive(Deserialize)]
pub struct ClaimRequest {
    #[serde(default)]
    pub nickname: String,
    #[serde(default)]
    pub plan_name: String,
    #[serde(default)]
    pub amount: f64,
}

/// `POST /api/client/sponsor/claim`：用爱发电昵称认领赞助身份。
/// - 名单里已有同昵称：直接绑定当前 user_id（若尚未绑定）；
/// - 没有记录且开启自动通过：按默认天数与默认特权直接发放；
/// - 否则返回 `pending`，等管理员在名单里处理。
pub async fn client_claim(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<ClaimRequest>,
) -> Json<Value> {
    let nickname = request.nickname.trim().to_string();
    if nickname.is_empty() || nickname.chars().count() > 40 {
        return Json(json!({ "status": "invalid", "message": "昵称不合法" }));
    }

    let mut data = state.data.write().await;
    let settings = data.sponsor.settings.clone();
    if !settings.enabled {
        return Json(json!({ "status": "disabled", "message": "赞助系统未开启" }));
    }
    if request.amount > 0.0 && request.amount < settings.min_amount {
        return Json(json!({
            "status": "amount_too_low",
            "message": format!("累计赞助需达到 ¥{}", settings.min_amount)
        }));
    }

    // 1) 名单里已有同昵称：绑定并激活。
    let existing_id = data
        .sponsor
        .find_by_nickname(&nickname)
        .map(|record| record.id.clone());
    if let Some(id) = existing_id {
        if let Some(record) = data.sponsor.sponsors.get_mut(&id) {
            if record.user_id.is_empty() || record.user_id == verified_user_id {
                record.user_id = verified_user_id.clone();
                record.active = true;
                if record.features.is_empty() {
                    record.features = settings.features.clone();
                }
                let record = record.clone();
                drop(data);
                crate::schedule_persist(&state);
                return Json(json!({ "status": "ok", "active": true, "record": record }));
            }
            return Json(json!({
                "status": "nickname_taken",
                "message": "该赞助昵称已被其他账号绑定，请联系管理员"
            }));
        }
    }

    // 2) 没有记录：自动通过则直接建一条。
    if settings.auto_approve {
        let record = SponsorRecord {
            id: new_id(),
            user_id: verified_user_id.clone(),
            nickname: nickname.clone(),
            plan_name: request.plan_name.trim().to_string(),
            amount: if request.amount > 0.0 { request.amount } else { 0.0 },
            features: settings.features.clone(),
            expires_at: expires_date(settings.default_days),
            note: "自动通过（昵称认领）".to_string(),
            created_at: now_string(),
            active: true,
        };
        let record = record.clone();
        data.sponsor.sponsors.insert(record.id.clone(), record.clone());
        drop(data);
        crate::schedule_persist(&state);
        return Json(json!({ "status": "ok", "active": true, "record": record }));
    }

    Json(json!({
        "status": "pending",
        "active": false,
        "message": "已提交，等待管理员核对赞助名单"
    }))
}

fn expires_date(days: i64) -> String {
    if days <= 0 {
        return String::new();
    }
    (Local::now().date_naive() + chrono::Duration::days(days))
        .format("%Y-%m-%d")
        .to_string()
}

// ─── 管理端 ──────────────────────────────────────────────────────────────────

pub async fn admin_settings_get(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!({ "settings": data.sponsor.settings }))
}

pub async fn admin_settings_save(
    State(state): State<AppState>,
    Json(settings): Json<SponsorSettings>,
) -> Response {
    if let Err(message) = validate_settings(&settings) {
        return (StatusCode::BAD_REQUEST, message).into_response();
    }
    state.data.write().await.sponsor.settings = settings.clone();
    crate::schedule_persist(&state);
    Json(json!({ "status": "ok", "settings": settings })).into_response()
}

pub async fn admin_list(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    let mut list: Vec<SponsorRecord> = data.sponsor.sponsors.values().cloned().collect();
    list.sort_by(|left, right| right.created_at.cmp(&left.created_at));
    let active = data.sponsor.sponsors.values().filter(|record| record.active).count();
    Json(json!({
        "items": list,
        "total": data.sponsor.sponsors.len(),
        "active": active,
    }))
}

pub async fn admin_upsert(
    State(state): State<AppState>,
    Json(mut record): Json<SponsorRecord>,
) -> Json<Value> {
    if record.nickname.trim().is_empty() || record.nickname.chars().count() > 40 {
        return Json(json!({ "status": "invalid", "message": "昵称不能为空且不超过 40 字符" }));
    }
    if record.features.is_empty() {
        record.features = state.data.read().await.sponsor.settings.features.clone();
    }
    if record.id.trim().is_empty() {
        record.id = new_id();
    }
    if record.created_at.trim().is_empty() {
        record.created_at = now_string();
    }
    if !record.expires_at.trim().is_empty()
        && NaiveDate::parse_from_str(record.expires_at.trim(), "%Y-%m-%d").is_err()
    {
        return Json(json!({ "status": "invalid", "message": "到期日格式应为 YYYY-MM-DD" }));
    }
    let id = record.id.clone();
    state.data.write().await.sponsor.sponsors.insert(id, record.clone());
    crate::schedule_persist(&state);
    Json(json!({ "status": "ok", "record": record }))
}

#[derive(Deserialize)]
pub struct DeleteRequest {
    pub id: String,
}

pub async fn admin_delete(
    State(state): State<AppState>,
    Json(request): Json<DeleteRequest>,
) -> Json<Value> {
    let removed = state.data.write().await.sponsor.sponsors.remove(&request.id);
    crate::schedule_persist(&state);
    Json(json!({ "status": if removed.is_some() { "ok" } else { "not_found" } }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn settings_validation_rejects_bad_values() {
        let mut settings = SponsorSettings::default();
        assert!(validate_settings(&settings).is_ok());

        settings.default_days = -1;
        assert!(validate_settings(&settings).is_err());

        settings.default_days = 30;
        settings.min_amount = -1.0;
        assert!(validate_settings(&settings).is_err());

        settings.min_amount = 0.0;
        settings.afdian_url = "javascript:alert(1)".to_string();
        assert!(validate_settings(&settings).is_err());
    }

    #[test]
    fn expired_helpers() {
        assert!(!expired(""));
        assert!(expired("2020-01-01"));
        assert!(!expired("2999-01-01"));
    }

    #[test]
    fn active_record_ignores_inactive_and_expired() {
        let mut data = SponsorData::default();
        let record = SponsorRecord {
            id: "a".into(),
            user_id: "u1".into(),
            nickname: "n".into(),
            plan_name: String::new(),
            amount: 0.0,
            features: vec!["rvc".into()],
            expires_at: String::new(),
            note: String::new(),
            created_at: "2026-01-01 00:00:00".into(),
            active: false,
        };
        data.sponsors.insert("a".into(), record);
        assert!(data.active_record("u1").is_none());

        let mut record = data.sponsors.get("a").unwrap().clone();
        record.active = true;
        record.expires_at = "2020-01-01".into();
        data.sponsors.insert("a".into(), record);
        assert!(data.active_record("u1").is_none());

        let mut record = data.sponsors.get("a").unwrap().clone();
        record.expires_at = String::new();
        data.sponsors.insert("a".into(), record);
        assert!(data.active_record("u1").is_some());
    }
}
