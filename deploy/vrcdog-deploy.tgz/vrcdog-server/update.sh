#!/usr/bin/env bash
set -e

# ==============================================================
# VRCDog 一键/定时全自动更新脚本
# 作用: 自动检测版本更新，生产级编译 Web 前端，无损保留数据，重启后端并自愈 OpenResty 配置
# ==============================================================

# 确保环境变量包含常见的构建工具路径与用户目录
export HOME="/root"
export PATH="/usr/local/bin:/usr/bin:/opt/node/bin:/root/.bun/bin:$PATH"

# 免疫 DNS 污染与解析失败：确保 /etc/resolv.conf 包含高可用公共 DNS (阿里/腾讯)
if [ -w /etc/resolv.conf ] && ! grep -q "223.5.5.5" /etc/resolv.conf 2>/dev/null; then
    printf "nameserver 223.5.5.5\nnameserver 119.29.29.29\nnameserver 180.76.76.76\n" > /etc/resolv.conf 2>/dev/null || true
fi

# 免疫 DNS 污染：确保 /etc/hosts 包含稳定的 GitHub、镜像及 NPM 镜像 IP
if ! grep -q "github.com" /etc/hosts 2>/dev/null; then
    echo "20.205.243.166 github.com" >> /etc/hosts 2>/dev/null || true
fi
if ! grep -q "ghfast.top" /etc/hosts 2>/dev/null; then
    echo "23.94.10.228 ghfast.top" >> /etc/hosts 2>/dev/null || true
fi
if ! grep -q "ghproxy.net" /etc/hosts 2>/dev/null; then
    echo "5.135.5.132 ghproxy.net" >> /etc/hosts 2>/dev/null || true
fi
if ! grep -q "mirrors.cloud.tencent.com" /etc/hosts 2>/dev/null; then
    echo "43.141.70.120 mirrors.cloud.tencent.com" >> /etc/hosts 2>/dev/null || true
fi
if ! grep -q "rsproxy.cn" /etc/hosts 2>/dev/null; then
    echo "113.24.210.25 rsproxy.cn" >> /etc/hosts 2>/dev/null || true
    echo "199.232.162.137 index.crates.io" >> /etc/hosts 2>/dev/null || true
    echo "199.232.162.137 static.crates.io" >> /etc/hosts 2>/dev/null || true
fi

# 1. 进程锁保护，避免多个定时任务并发冲突
PIDFILE="/tmp/vrcdog-update.pid"
if [ -f "$PIDFILE" ]; then
    PID=$(cat "$PIDFILE" 2>/dev/null || echo "")
    if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
        echo "[VRCDog] 另一个更新进程 (PID: $PID) 正在运行中，跳过本次执行。"
        exit 0
    fi
fi
echo "$$" > "$PIDFILE"
trap 'rm -f "$PIDFILE"' EXIT

# 2. 定位目录结构
REPO_DIR="/opt/VRCDog"
if [ ! -d "$REPO_DIR" ]; then
    if [ -d "../.git" ]; then
        REPO_DIR="$(cd .. && pwd)"
    elif [ -d ".git" ]; then
        REPO_DIR="$(pwd)"
    else
        REPO_DIR="/opt/VRCDog"
        mkdir -p "$REPO_DIR"
    fi
fi

SERVER_DIR="$REPO_DIR/vrcdog-server"
WEB_STATIC_DIR="/opt/1panel/apps/openresty/openresty/www/sites/vrcdog-web/index"
NGINX_CONF="/opt/1panel/apps/openresty/openresty/conf/conf.d/vrcdog-web.conf"

cd "$REPO_DIR"

# 3. 配置高速 GitHub 访问凭证
GITHUB_TOKEN="${GITHUB_TOKEN:-}"
if [ -z "$GITHUB_TOKEN" ] && [ -f "$SERVER_DIR/.env" ]; then
    GITHUB_TOKEN=$(grep -E '^GITHUB_TOKEN=' "$SERVER_DIR/.env" | cut -d '=' -f2- | tr -d ' "\r\n' || true)
fi
if [ -z "$GITHUB_TOKEN" ] && [ -f "/opt/1panel/docker/compose/webgame/.env" ]; then
    GITHUB_TOKEN=$(grep -E '^GITHUB_TOKEN=' "/opt/1panel/docker/compose/webgame/.env" | cut -d '=' -f2- | tr -d ' "\r\n' || true)
fi

if [ -d "$REPO_DIR/.git" ]; then
    if [ -n "$GITHUB_TOKEN" ]; then
        git remote set-url origin "https://oauth2:${GITHUB_TOKEN}@github.com/KingXiaoTaoOVO/VRCDog.git" 2>/dev/null || true
    else
        git remote set-url origin "https://github.com/KingXiaoTaoOVO/VRCDog.git" 2>/dev/null || true
    fi
fi

# 4. 检查代码更新
FORCE_UPDATE=0
if [ "${1:-}" = "--force" ]; then
    FORCE_UPDATE=1
fi

LOCAL_HASH=""
REMOTE_HASH=""

GIT_FETCH_OK=0
if [ -d "$REPO_DIR/.git" ]; then
    # 优先测试并切换高速 Git 镜像代理，解决国内直连 GitHub 超时问题
    for remote_url in \
        "https://ghfast.top/https://github.com/KingXiaoTaoOVO/VRCDog.git" \
        "https://ghproxy.net/https://github.com/KingXiaoTaoOVO/VRCDog.git" \
        "https://github.com/KingXiaoTaoOVO/VRCDog.git"; do
        git remote set-url origin "$remote_url" 2>/dev/null || true
        if timeout 15 git fetch origin main --depth=1 --quiet 2>/dev/null; then
            GIT_FETCH_OK=1
            echo " -> 成功连接 Git 远程源: $remote_url"
            break
        fi
    done

    LOCAL_HASH=$(git rev-parse HEAD 2>/dev/null || echo "")
    REMOTE_HASH=$(git rev-parse origin/main 2>/dev/null || echo "")

    if [ "$FORCE_UPDATE" -eq 0 ] && [ "$GIT_FETCH_OK" -eq 1 ] && [ -n "$LOCAL_HASH" ] && [ "$LOCAL_HASH" = "$REMOTE_HASH" ]; then
        # 远程无新提交且非强制更新，立即静默退出
        exit 0
    fi
fi

# 5. 代码同步与拉取
echo "=================================================="
echo " [VRCDog] 执行部署与同步流程..."
echo " 本地提交: ${LOCAL_HASH:-未知}"
echo " 远程提交: ${REMOTE_HASH:-未知}"
echo " 触发时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "=================================================="

echo "[1/5] 同步最新代码与静态资源..."
if [ -d "$REPO_DIR/.git" ] && [ "$GIT_FETCH_OK" -eq 1 ]; then
    git reset --hard origin/main
    # 严格保留后端数据与配置文件
    git clean -fd -e vrcdog-server/data -e vrcdog-server/.env -e vrcdog-server/bin
    if [ -z "$_VRCDOG_RELOADED" ]; then
        echo " -> 代码更新完成，重新载入最新部署流程..."
        export _VRCDOG_RELOADED=1
        rm -f "$PIDFILE"
        exec bash "$0" "$@"
    fi
else
    echo " -> Git 直连受限或不可达，通过国内高速代理下载最新全量源码包覆盖..."
    TMP_ARCHIVE="/tmp/vrcdog-latest.tar.gz"
    TMP_DIR="/tmp/vrcdog-extract-$$"
    mkdir -p "$TMP_DIR"

    if ! curl -fsSL --connect-timeout 8 "https://ghfast.top/https://github.com/KingXiaoTaoOVO/VRCDog/archive/refs/heads/main.tar.gz" -o "$TMP_ARCHIVE"; then
        echo " -> 高速代理超时，尝试备选代理..."
        curl -fsSL --connect-timeout 15 "https://ghproxy.net/https://github.com/KingXiaoTaoOVO/VRCDog/archive/refs/heads/main.tar.gz" -o "$TMP_ARCHIVE"
    fi

    if [ -f "$TMP_ARCHIVE" ]; then
        tar -xzf "$TMP_ARCHIVE" -C "$TMP_DIR"
        cp -rf "$TMP_DIR"/VRCDog-main/* "$REPO_DIR/"
        rm -rf "$TMP_ARCHIVE" "$TMP_DIR"
        echo " -> 源码包同步完成！"
    fi
fi

# 6. 编译 Web 前端（VRCDOG_BASE=/web/）
echo "[2/5] 编译生产级 Web 前端应用 (VRCDOG_BASE=/web/)..."
cd "$REPO_DIR"
export VRCDOG_BASE=/web/

if command -v pnpm >/dev/null 2>&1; then
    SKIP_INSTALL=0
    if [ -f "$REPO_DIR/node_modules/vite/bin/vite.js" ] && [ "${VRCDOG_FORCE_INSTALL:-0}" != "1" ]; then
        echo " -> node_modules 已存在，跳过 pnpm install（如需强制安装请设置 VRCDOG_FORCE_INSTALL=1）"
        SKIP_INSTALL=1
    fi
    if [ "$SKIP_INSTALL" -eq 0 ]; then
        pnpm config set registry https://registry.npmmirror.com 2>/dev/null || true
        pnpm install --frozen-lockfile --prefer-offline || pnpm install --prefer-offline
    fi
    node scripts/build-web.mjs
elif command -v npm >/dev/null 2>&1; then
    npm config set registry https://registry.npmmirror.com 2>/dev/null || true
    npm install --prefer-offline
    node scripts/build-web.mjs
else
    echo " -> 错误: 未找到 Node/Pnpm 构建工具"
    exit 1
fi

# 7. 同步前端静态资源到 1Panel 静态站点目录
echo "[3/5] 部署 Web 静态资源到 $WEB_STATIC_DIR ..."
if [ -d "$REPO_DIR/dist" ]; then
    mkdir -p "$WEB_STATIC_DIR"
    if command -v rsync >/dev/null 2>&1; then
        rsync -a --delete "$REPO_DIR/dist/" "$WEB_STATIC_DIR/"
    else
        rm -rf "$WEB_STATIC_DIR"/*
        cp -rf "$REPO_DIR/dist"/* "$WEB_STATIC_DIR/"
    fi
    chmod -R 755 "$WEB_STATIC_DIR" 2>/dev/null || true
    echo " -> Web 静态资源部署成功！"
else
    echo " -> 错误: 未生成 dist 目录，跳过静态文件同步。"
    exit 1
fi

# 7.1 编译并部署官网 Next.js 静态站点到 vrcdog.pcb.im 目录
SITE_STATIC_DIR="/opt/1panel/apps/openresty/openresty/www/sites/vrcdog.pcb.im/index"
if [ ! -d "$SITE_STATIC_DIR" ] && [ -d "/www/sites/vrcdog.pcb.im/index" ]; then
    SITE_STATIC_DIR="/www/sites/vrcdog.pcb.im/index"
fi
if [ -d "$REPO_DIR/website-dist" ]; then
    echo " -> 检测到官网预编译静态资源 (website-dist)，直接部署到 $SITE_STATIC_DIR ..."
    mkdir -p "$SITE_STATIC_DIR"
    cp -rf "$REPO_DIR/website-dist"/* "$SITE_STATIC_DIR/" 2>/dev/null || true
    chmod -R 755 "$SITE_STATIC_DIR" 2>/dev/null || true
    echo " -> 官网静态资源部署成功！"
elif [ -d "$REPO_DIR/website" ]; then
    echo " -> 编译并部署官网 Next.js 静态站点到 $SITE_STATIC_DIR ..."
    cd "$REPO_DIR/website"
    npm install --prefer-offline 2>/dev/null || true
    npm run build 2>/dev/null || true
    if [ -d "$REPO_DIR/website/out" ]; then
        mkdir -p "$SITE_STATIC_DIR"
        cp -rf "$REPO_DIR/website/out"/* "$SITE_STATIC_DIR/" 2>/dev/null || true
        chmod -R 755 "$SITE_STATIC_DIR" 2>/dev/null || true
        echo " -> 官网静态资源部署成功！"
    fi
    cd "$REPO_DIR"
fi

# 8. 确保 OpenResty SPA 路由与缓存配置生效
if [ -f "$NGINX_CONF" ]; then
    if ! grep -q "try_files" "$NGINX_CONF"; then
        echo " -> 自动配置 OpenResty SPA 路由 fallback..."
        sed -i '/root \/www\/sites\/vrcdog-web\/index;/a \    location / {\n        try_files $uri $uri/ /index.html;\n    }\n    location /assets/ {\n        expires 30d;\n        add_header Cache-Control "public, no-transform";\n        try_files $uri =404;\n    }' "$NGINX_CONF"
    fi
fi

# 9. 校验数据持久化目录与权限，并重启后端容器
echo "[4/5] 校验持久化数据目录及权限并启动容器..."
cd "$SERVER_DIR"
mkdir -p "$SERVER_DIR/data"
chown -R 10001:10001 "$SERVER_DIR/data" 2>/dev/null || true
chmod -R 777 "$SERVER_DIR/data" 2>/dev/null || true
chcon -Rt svirt_sandbox_file_t "$SERVER_DIR/data" 2>/dev/null || true

if [ -x "$SERVER_DIR/bin/vrcdog-server" ]; then
    echo " -> 检测到预编译 Linux 二进制，跳过 Docker 基础镜像预拉取与构建..."
else
    # 仅在需要 Docker 构建时预拉取基础镜像
    for img in "rust:1-bookworm" "debian:bookworm-slim"; do
        if ! docker image inspect "$img" >/dev/null 2>&1; then
            echo " -> 尝试预拉取基础镜像 $img..."
            docker pull "$img" || true
        fi
    done
fi

if [ -x "$SERVER_DIR/bin/vrcdog-server" ]; then
    echo " -> 使用预编译 Linux 二进制启动容器（跳过 Docker 构建）..."
    docker compose up -d --no-build --force-recreate
else
    echo " -> 未找到预编译二进制，回退 Docker 构建..."
    docker compose up -d --build
fi

# 平滑重新加载 OpenResty（热重载，零停机）
docker exec openresty nginx -s reload 2>/dev/null || true

# 10. 服务健康检查
echo "[5/5] 执行健康检查..."
sleep 3

if curl -fsSL --connect-timeout 5 http://127.0.0.1:21451/ping 2>/dev/null | grep -q "ok" || \
   curl -fsSL --connect-timeout 5 http://127.0.0.1:11451/ping 2>/dev/null | grep -q "ok"; then
    echo " -> 后端服务: 正常运行 (HTTP 200 /ping)"
else
    echo " -> 警告: 后端服务未在预期端口响应，查看最新日志:"
    docker compose logs --tail=15
fi

if curl -fsSL --connect-timeout 5 http://127.0.0.1:9999/index.html 2>/dev/null | grep -q "VrcDog"; then
    echo " -> Web 前端: 正常运行 (HTTP 200 /web)"
else
    echo " -> 警告: Web 前端静态站点响应异常"
fi

echo "=================================================="
echo " [VRCDog] 自动更新完成！当前版本: $(git rev-parse --short HEAD 2>/dev/null || echo '最新')"
echo "=================================================="
