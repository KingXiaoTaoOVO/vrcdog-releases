use axum::{
    body::{Body, Bytes},
    extract::{ws::WebSocketUpgrade, ConnectInfo, DefaultBodyLimit, Extension, Path, Query, State},
    http::{header::{CACHE_CONTROL, CONTENT_DISPOSITION, CONTENT_TYPE, HeaderMap, HeaderValue, X_CONTENT_TYPE_OPTIONS}, StatusCode},
    middleware,
    response::{Html, IntoResponse, Response},
    routing::{get, on, post, MethodFilter},
    Json, Router,
};
use chrono::{Duration, Local, NaiveDateTime};
use hex;
use rand;
use reqwest::{Client as ReqwestClient, ClientBuilder, Method};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::HashMap,
    env,
    net::SocketAddr,
    path::{Path as FsPath, PathBuf},
    sync::{
        atomic::{AtomicBool, AtomicU64, Ordering},
        Arc, OnceLock,
    },
    time::{Duration as StdDuration, Instant},
};
use tokio::sync::{Notify, RwLock};
use tower_http::{
    cors::{Any, CorsLayer},
    trace::TraceLayer,
};
use tracing::{error, info, warn};

mod remote_assist_hub;
mod survey;
mod midi_library;
mod community;
mod sponsor;

use survey::{Survey, SurveyAnswerFile, SurveyClickEvent, SurveySettings, SurveySubmission};

/// 上游 API 基址：默认官方地址；服务器无法直连时通过 Cloudflare Worker 中转。
fn relay_base(env_name: &str, fallback: &str) -> String {
    env::var(env_name)
        .ok()
        .map(|value| value.trim().trim_end_matches('/').to_string())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| fallback.to_string())
}

/// Worker 中转共享密钥；未配置时保持官方直连，不影响本地开发。
fn relay_token() -> Option<String> {
    env::var("VRCDOG_RELAY_TOKEN")
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct ClientInfo {
    user_id: String,
    display_name: String,
    avatar_url: String,
    ip_address: String,
    connected_at: String,
    last_heartbeat: String,
    /// L2: 服务端签发的短期 client token，用于后续请求鉴权
    client_token: String,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct UserRecord {
    user_id: String,
    pub(crate) display_name: String,
    pub(crate) avatar_url: String,
    first_seen: String,
    last_seen: String,
    login_count: u32,
    is_online: bool,
    role_id: Option<String>,
    #[serde(default)]
    role_expires_at: Option<String>,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct BanInfo {
    user_id: String,
    reason: String,
    banned_at: String,
    duration_hours: Option<f64>,
    expires_at: Option<String>,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct FreezeInfo {
    user_id: String,
    reason: String,
    frozen_at: String,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct FeatureConfig {
    #[serde(default)]
    menus: HashMap<String, bool>,
    #[serde(default)]
    themes: HashMap<String, bool>,
    #[serde(default)]
    modes: HashMap<String, bool>,
}

impl Default for FeatureConfig {
    fn default() -> Self {
        let menus = [
            "dashboard",
            "feed",
            "locations",
            "charts",
            "playerlist",
            "gallery",
            "social",
            "friendslist",
            "moderation",
            "search",
            "notifications",
            "groups",
            "avatars",
            "favorites",
            "heatmap",
            "notes",
            "presets",
            "tools",
            "vrpiano",
            "drawing",
            "bilidown",
            "danmaku",
            "translator",
            "ovr",
            "remote",
            "env",
            "export",
            "settings",
        ]
        .into_iter()
        .map(|key| (key.to_string(), true))
        .collect();
        let themes = ["dog", "cat", "helmet", "mono"]
            .into_iter()
            .map(|key| (key.to_string(), true))
            .collect();
        let modes = ["pc", "vr"]
            .into_iter()
            .map(|key| (key.to_string(), true))
            .collect();
        Self {
            menus,
            themes,
            modes,
        }
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
struct Role {
    role_id: String,
    role_name: String,
    is_default: bool,
    features: FeatureConfig,
}

/// 服务端运营策略：全部落在管理端，不写死在代码里。
#[derive(Clone, Serialize, Deserialize, Debug)]
pub(crate) struct ServerSettings {
    /// 是否允许新用户注册；已注册用户不受影响。
    #[serde(default = "default_true")]
    allow_registration: bool,
    /// 维护模式：只拦截新注册，已在线的客户端继续可用（避免一刀切掉线）。
    #[serde(default)]
    maintenance_mode: bool,
    #[serde(default)]
    maintenance_message: String,
    /// 普通附件（问卷附件等）的单文件上限，单位 MiB。
    #[serde(default = "default_max_upload_mb")]
    max_upload_mb: u64,
    /// 附件保留天数；0 = 不按时间清理。
    #[serde(default)]
    upload_retention_days: u64,
    /// 附件目录总容量上限（MiB）；0 = 不按容量清理。
    #[serde(default)]
    upload_max_total_mb: u64,
}

fn default_true() -> bool {
    true
}

fn default_max_upload_mb() -> u64 {
    10
}

impl Default for ServerSettings {
    fn default() -> Self {
        Self {
            allow_registration: true,
            maintenance_mode: false,
            maintenance_message: String::new(),
            max_upload_mb: default_max_upload_mb(),
            upload_retention_days: 0,
            upload_max_total_mb: 0,
        }
    }
}

fn validate_server_settings(settings: &ServerSettings) -> Result<(), String> {
    if !(1..=64).contains(&settings.max_upload_mb) {
        return Err("max_upload_mb 必须在 1-64 之间".to_string());
    }
    if settings.maintenance_message.chars().count() > 200 {
        return Err("维护提示不能超过 200 个字符".to_string());
    }
    if settings.upload_retention_days > 3650 {
        return Err("upload_retention_days 不能超过 3650 天".to_string());
    }
    if settings.upload_max_total_mb > 102_400 {
        return Err("upload_max_total_mb 不能超过 102400 MiB".to_string());
    }
    Ok(())
}

#[derive(Clone, Serialize, Deserialize, Default)]
pub(crate) struct PersistentData {
    #[serde(default)]
    users: HashMap<String, UserRecord>,
    #[serde(default)]
    bans: HashMap<String, BanInfo>,
    #[serde(default)]
    frozen: HashMap<String, FreezeInfo>,
    #[serde(default)]
    kicked: HashMap<String, String>,
    #[serde(default)]
    roles: HashMap<String, Role>,
    #[serde(default)]
    survey_settings: SurveySettings,
    #[serde(default)]
    surveys: HashMap<String, Survey>,
    #[serde(default)]
    survey_submissions: HashMap<String, SurveySubmission>,
    /// Raw per-option click events reported by clients while filling surveys.
    #[serde(default)]
    survey_click_events: Vec<SurveyClickEvent>,
    /// 资产社区 + 日豆账本（见 community.rs）。默认空，老的服务端状态文件可直接加载。
    #[serde(default)]
    pub(crate) community: community::CommunityData,
    /// 运营策略（注册开关 / 维护模式 / 附件上限），默认值与历史行为一致。
    #[serde(default)]
    pub(crate) server_settings: ServerSettings,
    /// 爱发电赞助：开关、名单、特权。
    #[serde(default)]
    pub(crate) sponsor: sponsor::SponsorData,
    /// 官网内容（下载地址、文案、图片、广告位）；管理端以 JSON 形式维护。
    #[serde(default)]
    pub(crate) site_config: serde_json::Value,
    /// 管理员账号（用户名 + bcrypt 口令）。默认 admin / 123456，可在管理台改。
    #[serde(default)]
    pub(crate) admin_account: AdminAccount,
    /// 官网提交的反馈与改模定制单。
    #[serde(default)]
    pub(crate) inquiries: Vec<Inquiry>,
    /// 通过官网登录过 VRChat 的用户（身份来自官方 auth/user 接口）。
    #[serde(default)]
    pub(crate) site_users: HashMap<String, SiteUserRecord>,
    /// 官网访客（匿名，按浏览器 token 去重）。
    #[serde(default)]
    pub(crate) site_visitors: HashMap<String, SiteVisitor>,
    /// 邮件通知配置（SMTP + 管理员收件地址）。
    #[serde(default)]
    pub(crate) mail: MailSettings,
}

impl PersistentData {
    fn ensure_defaults(&mut self) {
        if self.roles.is_empty() {
            self.roles.insert(
                "default".to_string(),
                Role {
                    role_id: "default".to_string(),
                    role_name: "Default User".to_string(),
                    is_default: true,
                    features: FeatureConfig::default(),
                },
            );
        }
        for user in self.users.values_mut() {
            user.is_online = false;
        }
    }
}

#[derive(Clone)]
struct AppState {
    pub(crate) clients: Arc<RwLock<HashMap<String, ClientInfo>>>,
    pub(crate) data: Arc<RwLock<PersistentData>>,
    pub(crate) data_file: Arc<PathBuf>,
    remote_assist: remote_assist_hub::RemoteAssistHub,
    persist_dirty: Arc<AtomicBool>,
    persist_notify: Arc<Notify>,
    admin_sessions: Arc<RwLock<HashMap<String, AdminSession>>>,
    /// 官网访客的 VRChat 登录态（与客户端 client_token 完全独立）。
    site_sessions: Arc<RwLock<HashMap<String, SiteSession>>>,
    /// 两段式 VRChat 登录的临时票据：账号密码验完、等 2FA 验证码。
    vrchat_login_tickets: Arc<RwLock<HashMap<String, VrchatLoginTicket>>>,
    /// 图形验证码：id -> (答案, 生成时间)。一次性消费，5 分钟过期。
    captchas: Arc<RwLock<HashMap<String, CaptchaEntry>>>,
    http_client: Arc<ReqwestClient>,
}

/// 一张图形验证码。答案只存在服务端，前端只拿 id 与 SVG。
struct CaptchaEntry {
    code: String,
    created: Instant,
}

const CAPTCHA_TTL_SECS: u64 = 300;
const CAPTCHA_CODE_LEN: usize = 4;

#[derive(Deserialize)]
struct RegisterRequest {
    user_id: String,
    display_name: String,
    #[serde(default)]
    avatar_url: String,
    /// 客户端的 VRChat 会话 Cookie。服务端据此向官方 API 反查真实 user id，
    /// 防止任何人仅凭 user_id 冒名注册并领取 client_token（L2）。
    #[serde(default)]
    auth_cookie: Option<String>,
}

#[derive(Deserialize)]
struct UserIdRequest {
    user_id: String,
}

#[derive(Deserialize)]
struct BanRequest {
    user_id: String,
    reason: String,
    duration_hours: Option<f64>,
}

#[derive(Deserialize)]
struct FreezeRequest {
    user_id: String,
    reason: String,
}

#[derive(Deserialize)]
struct RoleIdRequest {
    role_id: String,
}

#[derive(Deserialize)]
struct SetUserRoleRequest {
    user_id: String,
    role_id: Option<String>,
}

#[derive(Deserialize)]
struct SurveyIdRequest {
    survey_id: String,
}

#[derive(Deserialize)]
struct SubmitSurveyRequest {
    user_id: String,
    survey_id: String,
    survey_revision: u32,
    #[serde(default)]
    answers: HashMap<String, Value>,
    /// Per-question file attachments uploaded by the respondent.
    #[serde(default)]
    answer_files: Option<HashMap<String, Vec<SurveyAnswerFile>>>,
}

#[derive(Deserialize)]
struct DismissSurveyRequest {
    user_id: String,
    survey_id: String,
    survey_revision: u32,
}

/// A single click/interaction reported by the client while the respondent is
/// filling a survey. Labels sent by the client are only used as a fallback when
/// the server-side survey snapshot cannot resolve them.
#[derive(Deserialize)]
struct ClickSurveyRequest {
    user_id: String,
    survey_id: String,
    #[serde(default)]
    survey_revision: u32,
    question_id: String,
    #[serde(default)]
    option_id: String,
    #[serde(default)]
    option_label: String,
    #[serde(default)]
    question_title: String,
    /// "select" | "deselect" | "input"
    #[serde(default)]
    action: String,
    #[serde(default)]
    text_value: String,
}

/// Upper bound for stored raw click events; oldest events are dropped first so
/// the persistence file cannot grow without limit.
const MAX_SURVEY_CLICK_EVENTS: usize = 20_000;

#[derive(Deserialize)]
struct DeleteSubmissionRequest {
    user_id: String,
    submission_id: String,
}

#[derive(Deserialize)]
struct AdminAuthRequest {
    /// 老管理台只发 password；缺省时按默认账号名 admin 处理，保持向后兼容。
    #[serde(default)]
    username: Option<String>,
    password: String,
    /// 图形验证码。老客户端不带这两个字段，服务端按「必须校验」处理，
    /// 只有确实未配置验证码时才放行（见 admin_captcha_required）。
    #[serde(default)]
    captcha_id: String,
    #[serde(default)]
    captcha_code: String,
}

#[derive(Clone)]
struct AdminSession {
    created_at: String,
    #[allow(dead_code)]
    username: String,
}

/// 管理员账号：用户名 + bcrypt 口令。站点与客户端共用同一份凭据，
/// 因此任何一端改密码，另一端下一次登录立即生效。
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct AdminAccount {
    pub username: String,
    pub password_hash: String,
}

fn default_admin_username() -> String {
    "admin".to_string()
}

/// 首次启动（状态文件里还没有 admin_account 时）落到 admin / 123456。
fn default_admin_hash() -> String {
    bcrypt::hash("123456", bcrypt::DEFAULT_COST).unwrap_or_default()
}

impl Default for AdminAccount {
    fn default() -> Self {
        Self {
            username: default_admin_username(),
            password_hash: default_admin_hash(),
        }
    }
}

/// 官网访客登录 VRChat 后的会话。
#[derive(Clone)]
pub(crate) struct SiteSession {
    pub vrchat_id: String,
    pub display_name: String,
    pub avatar: String,
    pub created_at: String,
    /// 最近一次访问官网的时间，用于「登录用户在座」统计。
    pub last_seen: String,
}

/// 账号密码已通过、只差 2FA 验证码的临时票据，5 分钟有效。
#[derive(Clone)]
pub(crate) struct VrchatLoginTicket {
    /// 只在内存里停留 5 分钟，用于第二段重放认证。
    pub username: String,
    pub password: String,
    /// 第一段登录响应里下发的 twoFactorAuth cookie。
    pub two_factor_cookie: String,
    /// 第一段 401 时同时下发的 auth cookie（VRChat 登录态凭据，能拿到就复用）。
    pub auth_cookie: String,
    pub created_at: String,
}

#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct InquiryFile {
    pub id: String,
    pub name: String,
    pub mime: String,
    pub size: u64,
    /// image / video / audio / file
    pub kind: String,
}

/// 官网反馈 / 改模定制单。kind 区分用途，其余字段共用。
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct Inquiry {
    pub id: String,
    /// bug / suggestion / commission
    pub kind: String,
    /// open / processing / closed
    pub status: String,
    pub title: String,
    pub content: String,
    #[serde(default)]
    pub contact: String,
    /// 提交人邮箱：新反馈会通知管理员，回复时可选通知本人。
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub files: Vec<InquiryFile>,
    #[serde(default)]
    pub vrchat_id: String,
    #[serde(default)]
    pub vrchat_name: String,
    #[serde(default)]
    pub avatar: String,
    pub created_at: String,
    #[serde(default)]
    pub reply: String,
    /// 管理员回复时附带的图片 / 视频 / 文件。
    #[serde(default)]
    pub reply_files: Vec<InquiryFile>,
    #[serde(default)]
    pub replied_at: String,
    #[serde(default)]
    pub updated_at: String,
}

/// 官网注册用户快照。昵称与头像来自 VRChat 官方 `auth/user`，不存密码和 Cookie。
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct SiteUserRecord {
    pub vrchat_id: String,
    pub display_name: String,
    pub avatar: String,
    pub first_seen: String,
    pub last_seen: String,
    #[serde(default)]
    pub login_count: u64,
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub ip: String,
}

/// 官网匿名访客：按浏览器里的随机 token 去重，只记最近路径与活跃时间。
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct SiteVisitor {
    pub id: String,
    #[serde(default)]
    pub ip: String,
    #[serde(default)]
    pub ua: String,
    #[serde(default)]
    pub path: String,
    pub first_seen: String,
    pub last_seen: String,
    #[serde(default)]
    pub vrchat_id: String,
    #[serde(default)]
    pub display_name: String,
}

/// 邮件通知配置。SMTP 密码只写不读，接口不会回传。
#[derive(Clone, Serialize, Deserialize)]
pub(crate) struct MailSettings {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default)]
    pub smtp_host: String,
    #[serde(default = "default_smtp_port")]
    pub smtp_port: u16,
    #[serde(default)]
    pub smtp_username: String,
    #[serde(default)]
    pub smtp_password: String,
    #[serde(default)]
    pub from_address: String,
    #[serde(default = "default_mail_from_name")]
    pub from_name: String,
    /// 管理员收件地址：新反馈 / 新定制单提醒发到这里。
    #[serde(default)]
    pub admin_address: String,
    /// true = 465 隐式 TLS；false = 587 STARTTLS。
    #[serde(default = "default_true")]
    pub implicit_tls: bool,
    /// 管理台回复时默认勾选「同时邮件通知用户」。
    #[serde(default = "default_true")]
    pub notify_user_default: bool,
    /// 邮件里跳转链接的站点地址。
    #[serde(default = "default_site_url")]
    pub site_url: String,
}

fn default_smtp_port() -> u16 {
    465
}

fn default_mail_from_name() -> String {
    "VrcDog".to_string()
}

fn default_site_url() -> String {
    "https://vrcdog.pcb.im".to_string()
}

impl Default for MailSettings {
    fn default() -> Self {
        Self {
            enabled: false,
            smtp_host: String::new(),
            smtp_port: 465,
            smtp_username: String::new(),
            smtp_password: String::new(),
            from_address: String::new(),
            from_name: "VrcDog".to_string(),
            admin_address: String::new(),
            implicit_tls: true,
            notify_user_default: true,
            site_url: "https://vrcdog.pcb.im".to_string(),
        }
    }
}

fn server_password_hash() -> Option<String> {
    static WARNED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let hash = env::var("VRCDOG_SERVER_PASSWORD_BCRYPT")
        .ok()
        .map(|h| h.trim().to_string())
        .filter(|h| !h.is_empty());
    if hash.is_none() {
        WARNED.get_or_init(|| {
            eprintln!(
                "[VrcDog-Server] 警告：未设置环境变量 VRCDOG_SERVER_PASSWORD_BCRYPT，管理员接口已禁用。\
                 请设置该变量为 bcrypt 哈希后重启。"
            );
            true
        });
    }
    hash
}

fn verify_server_password(password: &str) -> bool {
    match server_password_hash() {
        Some(hash) => bcrypt::verify(password, &hash).unwrap_or(false),
        None => false,
    }
}

fn now_string() -> String {
    Local::now().format("%Y-%m-%d %H:%M:%S").to_string()
}

fn survey_gate_payload(data: &PersistentData, user_id: &str) -> Value {
    let pending = survey::pending_surveys(
        data.survey_settings.enabled,
        &data.surveys,
        &data.survey_submissions,
        user_id,
    );
    let required = pending.iter().any(|survey| survey.required_for_access);
    json!({
        "status": if required { "survey_required" } else if pending.is_empty() { "ok" } else { "survey_available" },
        "pending_survey_count": pending.len(),
        "survey_required": required,
        "version": env!("CARGO_PKG_VERSION"),
        "server_version": env!("CARGO_PKG_VERSION")
    })
}

fn ban_is_expired(ban: &BanInfo) -> bool {
    let Some(hours) = ban.duration_hours else {
        return false;
    };
    let Ok(banned_at) = NaiveDateTime::parse_from_str(&ban.banned_at, "%Y-%m-%d %H:%M:%S") else {
        return false;
    };
    Local::now().naive_local() > banned_at + Duration::seconds((hours * 3600.0) as i64)
}

/// True when the user's granted role has an expiry that is already in the past.
fn role_expired(user: &UserRecord) -> bool {
    let Some(expires_at) = &user.role_expires_at else {
        return false;
    };
    let Ok(parsed) = NaiveDateTime::parse_from_str(expires_at, "%Y-%m-%d %H:%M:%S") else {
        return false;
    };
    Local::now().naive_local() > parsed
}

/// Revoke a user's granted role once it has expired. Uses a read check first so
/// healthy heartbeats (the common case) never take a write lock.
async fn revoke_expired_user_role(state: &AppState, user_id: &str) {
    let expired = {
        let data = state.data.read().await;
        data.users.get(user_id).is_some_and(role_expired)
    };
    if expired {
        let mut data = state.data.write().await;
        if let Some(user) = data.users.get_mut(user_id) {
            if role_expired(user) {
                user.role_id = None;
                user.role_expires_at = None;
            }
        }
        drop(data);
        schedule_persist(state);
    }
}

// Mutations mark state dirty instead of blocking on a full serialize+write.
// The background writer coalesces bursts into a single disk write within this
// window, which slashes IOPS and the transient 2x memory peak from cloning.
const PERSIST_DEBOUNCE_MS: u64 = 800;

async fn persist_inner(state: &AppState) -> Result<(), String> {
    // Serialize in place under a read lock (no full clone of PersistentData),
    // then drop the lock before touching the disk.
    let bytes = {
        let data = state.data.read().await;
        serde_json::to_vec_pretty(&*data).map_err(|error| error.to_string())?
    };
    if let Some(parent) = state.data_file.parent() {
        tokio::fs::create_dir_all(parent)
            .await
            .map_err(|error| error.to_string())?;
    }
    let temp_file = state.data_file.with_extension("json.tmp");
    tokio::fs::write(&temp_file, &bytes)
        .await
        .map_err(|error| error.to_string())?;
    // Linux 上 rename 原子覆盖；Windows 目标存在时 rename 会失败，才退回删除重试。
    if tokio::fs::rename(&temp_file, state.data_file.as_ref())
        .await
        .is_err()
    {
        let _ = tokio::fs::remove_file(state.data_file.as_ref()).await;
        tokio::fs::rename(&temp_file, state.data_file.as_ref())
            .await
            .map_err(|error| error.to_string())?;
    }
    Ok(())
}

pub(crate) fn schedule_persist(state: &AppState) {
    state.persist_dirty.store(true, Ordering::SeqCst);
    state.persist_notify.notify_one();
}
async fn persist_worker(state: AppState) {
    loop {
        state.persist_notify.notified().await;
        // Quiet window: any mutations within it coalesce into one write.
        tokio::time::sleep(StdDuration::from_millis(PERSIST_DEBOUNCE_MS)).await;
        if state.persist_dirty.swap(false, Ordering::SeqCst) {
            if let Err(error) = persist_inner(&state).await {
                warn!("persist failed: {error}");
                state.persist_dirty.store(true, Ordering::SeqCst);
            }
        }
    }
}

async fn load_data(path: &FsPath) -> PersistentData {
    let temp_file = path.with_extension("json.tmp");
    // 主文件读不到时（上次写盘中断在删除旧文件之后）退回读临时文件。
    let bytes = match tokio::fs::read(path).await {
        Ok(bytes) => Some(bytes),
        Err(_) => tokio::fs::read(&temp_file).await.ok(),
    };
    let mut data = match bytes {
        Some(bytes) => match serde_json::from_slice(&bytes) {
            Ok(data) => data,
            Err(error) => {
                // 直接当空库会静默清掉所有反馈和用户，先留一份坏文件再重置。
                warn!("state file is corrupt, starting empty: {error}");
                let backup = path.with_extension(format!(
                    "json.corrupt-{}",
                    Local::now().format("%Y%m%d%H%M%S")
                ));
                if let Err(rename_error) = tokio::fs::rename(path, &backup).await {
                    warn!("failed to back up corrupt state file: {rename_error}");
                }
                PersistentData::default()
            }
        },
        None => PersistentData::default(),
    };
    data.ensure_defaults();
    data
}

async fn ping() -> Json<Value> {
    Json(json!({
        "status": "ok",
        "message": "Pong from VRCDog Standalone Server",
        "version": env!("CARGO_PKG_VERSION"),
        "server_version": env!("CARGO_PKG_VERSION")
    }))
}

// Self-contained (no external assets) browser status page shown at the server
// root. Rendered dark/glassmorphism so it looks good behind any reverse proxy.
const STATUS_PAGE_HTML: &str = r#"<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>VRCDog 服务端</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
    background: radial-gradient(1200px 600px at 50% -10%, #1b2a4a 0%, #0b1020 55%, #070a14 100%);
    color: #e8ecf4; padding: 24px;
  }
  .card {
    width: min(520px, 92vw);
    background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
    border: 1px solid rgba(255,255,255,0.10); border-radius: 22px; padding: 40px 36px;
    text-align: center; backdrop-filter: blur(8px); box-shadow: 0 20px 60px rgba(0,0,0,0.45);
  }
  .badge {
    width: 84px; height: 84px; margin: 0 auto 22px; border-radius: 50%;
    display: grid; place-items: center;
    background: linear-gradient(135deg, #2bd47f, #18a0fb);
    animation: pulse 2.4s ease-in-out infinite;
  }
  .badge svg { width: 42px; height: 42px; stroke: #06121f; }
  @keyframes pulse {
    0%,100% { box-shadow: 0 0 0 8px rgba(43,212,127,0.12), 0 10px 30px rgba(24,160,251,0.35); }
    50% { box-shadow: 0 0 0 14px rgba(43,212,127,0.06), 0 10px 36px rgba(24,160,251,0.45); }
  }
  .title {
    font-size: 26px; font-weight: 800; letter-spacing: .5px;
    background: linear-gradient(90deg, #6fe3ff, #18a0fb);
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .status { margin-top: 10px; font-size: 17px; font-weight: 700; color: #d6e2ff; }
  .hint { margin-top: 6px; font-size: 14px; color: #9fb0cc; }
  .meta { margin-top: 26px; display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
  .chip {
    font-size: 12px; color: #aab8d4; background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.08); padding: 6px 12px; border-radius: 999px;
  }
  .chip b { color: #e8ecf4; font-weight: 700; }
  .foot { margin-top: 22px; font-size: 11px; color: #6b7a99; }
</style>
</head>
<body>
  <div class="card">
    <div class="badge">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>
    </div>
    <div class="title">VRCDog 服务端</div>
    <div class="status">服务已成功运行</div>
    <div class="hint">请用客户端连接！</div>
    <div class="meta">
      <span class="chip">版本 <b>{{VERSION}}</b></span>
      <span class="chip">端口 <b>11451</b></span>
      <span class="chip">启动于 <b>{{NOW}}</b></span>
    </div>
    <div class="foot">VRCDog Standalone Server · 此页面仅用于部署状态确认</div>
  </div>
</body>
</html>"#;

const ADMIN_PAGE_HTML: &str = include_str!("admin_ui.html");

async fn admin_page() -> Html<&'static str> {
    Html(ADMIN_PAGE_HTML)
}

async fn status_page() -> Html<String> {
    let html = STATUS_PAGE_HTML
        .replace("{{VERSION}}", env!("CARGO_PKG_VERSION"))
        .replace("{{NOW}}", &now_string());
    Html(html)
}

#[derive(Serialize)]
struct VersionInfo {
    version: &'static str,
    name: &'static str,
    published_at: String,
    body: &'static str,
    html_url: &'static str,
}

async fn api_version() -> Json<VersionInfo> {
    Json(VersionInfo {
        version: env!("CARGO_PKG_VERSION"),
        name: "VRCDog Server",
        published_at: now_string(),
        body: "VRCDog standalone server",
        html_url: "https://github.com/KingXiaoTaoOVO/vrcdog-releases",
    })
}

/// 公开的运营状态：客户端启动/注册前可据此展示维护公告或"注册已关闭"。
async fn server_info(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!({
        "version": env!("CARGO_PKG_VERSION"),
        "maintenance_mode": data.server_settings.maintenance_mode,
        "maintenance_message": data.server_settings.maintenance_message,
        "allow_registration": data.server_settings.allow_registration,
        "max_upload_mb": data.server_settings.max_upload_mb,
        "community_enabled": data.community.settings.enabled,
    }))
}

async fn remote_assist_ws(
    State(state): State<AppState>,
    ws: WebSocketUpgrade,
) -> impl axum::response::IntoResponse {
    state.remote_assist.upgrade(ws).await
}

fn generate_client_token() -> String {
    uuid::Uuid::new_v4().to_string()
}

/// 是否对注册做 VRChat 身份核验。默认开启（fail-closed）。
/// 无外网的自建部署可设 VRCDOG_REGISTER_SKIP_VERIFY=1 关闭，但会重新暴露冒名风险。
fn register_verification_enabled() -> bool {
    static WARNED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    let skip = env::var("VRCDOG_REGISTER_SKIP_VERIFY")
        .map(|v| v == "1" || v.eq_ignore_ascii_case("true"))
        .unwrap_or(false);
    if skip {
        WARNED.get_or_init(|| {
            eprintln!(
                "[VrcDog-Server] 警告：VRCDOG_REGISTER_SKIP_VERIFY 已开启，注册不再校验 VRChat 身份，任何人都可凭 user_id 冒名。仅在可信内网使用。"
            );
            true
        });
    }
    !skip
}

/// L2：用客户端的 VRChat 会话 Cookie 向官方 API 反查真实 user id，
/// 确认与请求声明的 user_id 一致，防止仅凭 user_id 冒名注册并领取 client_token。
fn normalize_cookie_header(raw_cookie: &str) -> String {
    let raw = raw_cookie.trim();
    if raw.is_empty() {
        return String::new();
    }
    if raw.starts_with('[') {
        if let Ok(cookies) = serde_json::from_str::<Vec<String>>(raw) {
            let list: Vec<String> = cookies
                .iter()
                .flat_map(|c| {
                    normalize_cookie_header(c)
                        .split(';')
                        .map(|s| s.trim().to_string())
                        .filter(|s| !s.is_empty())
                        .collect::<Vec<_>>()
                })
                .collect();
            if !list.is_empty() {
                return list.join("; ");
            }
        }
    }
    let parts: Vec<String> = raw
        .split(';')
        .map(str::trim)
        .filter(|s| !s.is_empty() && s.contains('='))
        .map(String::from)
        .collect();
    if !parts.is_empty() {
        parts.join("; ")
    } else if !raw.contains('=') {
        let clean = raw.trim_matches('"').trim_matches('\'').trim();
        if !clean.is_empty() {
            format!("auth={}", clean)
        } else {
            String::new()
        }
    } else {
        raw.to_string()
    }
}

/// L2：用客户端的 VRChat 会话 Cookie 向官方 API 反查真实 user id，
/// 确认与请求声明的 user_id 一致，防止仅凭 user_id 冒名注册并领取 client_token。
async fn verify_register_identity(request: &RegisterRequest) -> Result<(), String> {
    if !register_verification_enabled() {
        return Ok(());
    }
    let cookie = request
        .auth_cookie
        .as_deref()
        .map(str::trim)
        .filter(|c| !c.is_empty())
        .ok_or_else(|| "VRChat auth cookie is required".to_string())?;

    let normalized_cookie = normalize_cookie_header(cookie);
    if normalized_cookie.is_empty() {
        return Err("VRChat auth cookie is invalid or empty".to_string());
    }

    let user_agent = format!("VRCDog/{} (https://vrcdog.pcb.im; support@pcb.im)", env!("CARGO_PKG_VERSION"));
    let client = ClientBuilder::new()
        .timeout(StdDuration::from_secs(10))
        .user_agent(&user_agent)
        .build()
        .map_err(|e| format!("VRChat auth client init failed: {e}"))?;
    let mut auth_request = client
        .get(format!(
            "{}/api/1/auth/user",
            relay_base("VRCHAT_API_BASE", "https://api.vrchat.cloud")
        ))
        .header(reqwest::header::COOKIE, &normalized_cookie)
        .header(reqwest::header::USER_AGENT, &user_agent);
    if let Some(token) = relay_token() {
        auth_request = auth_request.header("x-vrcdog-relay", token);
    }
    let res = auth_request
        .send()
        .await
        .map_err(|e| format!("VRChat auth request failed: {e}"))?;
    if !res.status().is_success() {
        return Err(format!("VRChat auth failed with status: {}", res.status()));
    }
    let body: Value = res
        .json()
        .await
        .map_err(|e| format!("Failed to parse VRChat auth response: {e}"))?;
    let verified_id = body.get("id").and_then(|v| v.as_str()).unwrap_or("");
    if verified_id.is_empty() {
        return Err("VRChat auth returned an empty user id".to_string());
    }
    if verified_id != request.user_id {
        return Err("VRChat credentials do not match the claimed identity".to_string());
    }
    Ok(())
}

async fn register(
    State(state): State<AppState>,
    ConnectInfo(address): ConnectInfo<SocketAddr>,
    Json(request): Json<RegisterRequest>,
) -> Json<Value> {
    // L2：注册前先核验身份。
    let is_already_registered = state.data.read().await.users.contains_key(&request.user_id);
    // 已注册的客户端会反复注册来拿 token，额度放宽；新身份按严格额度。
    let limit = if is_already_registered { 120 } else { 20 };
    if !register_gate(&address.ip().to_string(), limit) {
        return Json(json!({
            "status": "rate_limited",
            "reason": "注册请求过于频繁，请稍后再试"
        }));
    }
    {
        let data = state.data.read().await;
        if data.server_settings.maintenance_mode {
            let reason = if data.server_settings.maintenance_message.trim().is_empty() {
                "Server is under maintenance".to_string()
            } else {
                data.server_settings.maintenance_message.clone()
            };
            return Json(json!({ "status": "maintenance", "reason": reason }));
        }
        if !data.server_settings.allow_registration && !is_already_registered {
            return Json(json!({
                "status": "registration_closed",
                "reason": "New registrations are closed by the administrator"
            }));
        }
    }
    if let Err(reason) = verify_register_identity(&request).await {
        let is_network_or_cloudflare = reason.contains("failed")
            || reason.contains("timeout")
            || reason.contains("status: 403")
            || reason.contains("status: 429")
            || reason.contains("status: 50");
        if is_already_registered || is_network_or_cloudflare {
            warn!(user_id = %request.user_id, reason = %reason, "VRChat 身份核验受阻或用户已在此服务端存在记录，允许维持连接");
        } else {
            warn!(user_id = %request.user_id, reason = %reason, "拒绝注册：VRChat 身份核验未通过");
            return Json(json!({ "status": "auth_failed", "reason": reason }));
        }
    }

    let now = now_string();
    let client_token = generate_client_token();
    let was_kicked = state.data.read().await.kicked.contains_key(&request.user_id);
    if was_kicked {
        let mut data = state.data.write().await;
        data.kicked.remove(&request.user_id);
        drop(data);
        schedule_persist(&state);
        return Json(json!({ "status": "kicked", "reason": "Removed by administrator" }));
    }
    {
        let mut data = state.data.write().await;
        if let Some(ban) = data.bans.get(&request.user_id) {
            if !ban_is_expired(ban) {
                return Json(json!({
                    "status": "banned",
                    "reason": ban.reason,
                    "duration_hours": ban.duration_hours,
                    "expires_at": ban.expires_at
                }));
            }
        }
        data.bans.retain(|_, ban| !ban_is_expired(ban));
        if let Some(freeze) = data.frozen.get(&request.user_id) {
            return Json(json!({ "status": "frozen", "reason": freeze.reason }));
        }
        data.users
            .entry(request.user_id.clone())
            .and_modify(|user| {
                user.display_name = request.display_name.clone();
                user.avatar_url = request.avatar_url.clone();
                user.last_seen = now.clone();
                user.login_count += 1;
                user.is_online = true;
            })
            .or_insert_with(|| UserRecord {
                user_id: request.user_id.clone(),
                display_name: request.display_name.clone(),
                avatar_url: request.avatar_url.clone(),
                first_seen: now.clone(),
                last_seen: now.clone(),
                login_count: 1,
                is_online: true,
                role_id: None,
                role_expires_at: None,
            });
        // Drop an expired incentive role on (re)connection so the default role applies.
        if let Some(user) = data.users.get_mut(&request.user_id) {
            if role_expired(user) {
                user.role_id = None;
                user.role_expires_at = None;
            }
        }
    }
    state.clients.write().await.insert(
        request.user_id.clone(),
        ClientInfo {
            user_id: request.user_id.clone(),
            display_name: request.display_name.clone(),
            avatar_url: request.avatar_url.clone(),
            ip_address: address.to_string(),
            connected_at: now.clone(),
            last_heartbeat: now.clone(),
            client_token: client_token.clone(),
        },
    );
    schedule_persist(&state);
    // 新人赠送日豆：策略在管理后台（资产社区规则）里配置，0 表示不送。
    // 必须在用户记录落库之后调用，才能保证 accounts/users 两边都能对上。
    community::grant_signup_points(&state, &request.user_id).await;
    info!(user_id = %request.user_id, ip = %address, "client registered");
    let data = state.data.read().await;
    let mut response = survey_gate_payload(&data, &request.user_id);
    response["message"] = json!("registered");
    response["client_token"] = json!(client_token);
    Json(response)
}

async fn heartbeat(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    let was_kicked = state.data.read().await.kicked.contains_key(&request.user_id);
    if was_kicked {
        let mut data = state.data.write().await;
        data.kicked.remove(&request.user_id);
        drop(data);
        schedule_persist(&state);
        return Json(json!({ "status": "kicked", "reason": "Removed by administrator" }));
    }
    {
        let data = state.data.read().await;
        if let Some(ban) = data.bans.get(&request.user_id) {
            if !ban_is_expired(ban) {
                return Json(json!({
                    "status": "banned",
                    "reason": ban.reason,
                    "duration_hours": ban.duration_hours,
                    "expires_at": ban.expires_at
                }));
            }
        }
        if let Some(freeze) = data.frozen.get(&request.user_id) {
            return Json(json!({ "status": "frozen", "reason": freeze.reason }));
        }
    }
    revoke_expired_user_role(&state, &request.user_id).await;
    let mut clients = state.clients.write().await;
    let Some(client) = clients.get_mut(&request.user_id) else {
        return Json(json!({ "status": "register_required" }));
    };
    client.last_heartbeat = now_string();
    drop(clients);
    let data = state.data.read().await;
    Json(survey_gate_payload(&data, &request.user_id))
}

async fn disconnect(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    state.clients.write().await.remove(&request.user_id);
    if let Some(user) = state.data.write().await.users.get_mut(&request.user_id) {
        user.is_online = false;
        user.last_seen = now_string();
    }
    schedule_persist(&state);
    Json(json!({ "status": "ok" }))
}

/// 只允许查询**自己**的封禁/冻结状态。
///
/// `require_client_token` 已经把 token 对应的 user_id 放进 request extension，
/// 但本函数原先直接采信路径里的 `{user_id}`：任何一台已注册设备（任何登录用户）
/// 都能读出别人的封禁原因与到期时间。现在与已验证身份比对后再返回。
async fn check_status(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Path(user_id): Path<String>,
) -> Json<Value> {
    if let Err(e) = assert_client_owner(&verified_user_id, &user_id) {
        return e;
    }
    let data = state.data.read().await;
    if let Some(ban) = data.bans.get(&user_id) {
        if !ban_is_expired(ban) {
            return Json(json!({
                "status": "banned",
                "reason": ban.reason,
                "duration_hours": ban.duration_hours,
                "expires_at": ban.expires_at
            }));
        }
    }
    if let Some(freeze) = data.frozen.get(&user_id) {
        return Json(json!({ "status": "frozen", "reason": freeze.reason }));
    }
    Json(json!({ "status": "ok", "reason": null }))
}

/// 功能/菜单/主题权限只发给归属账号本人（同 `check_status`）：
/// 否则任何已注册设备都能读出别人被下发了哪些权限开关。
async fn get_features(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Path(user_id): Path<String>,
) -> Json<Value> {
    if let Err(e) = assert_client_owner(&verified_user_id, &user_id) {
        return e;
    }
    let data = state.data.read().await;
    let default_role = data.roles.values().find(|role| role.is_default);
    let user_role = data
        .users
        .get(&user_id)
        .and_then(|user| {
            if role_expired(user) {
                None
            } else {
                user.role_id.as_ref()
            }
        })
        .and_then(|role_id| data.roles.get(role_id));
    let features = user_role
        .or(default_role)
        .map(|role| role.features.clone())
        .unwrap_or_default();
    let (role_id, role_expires_at, role_expired_flag) = data
        .users
        .get(&user_id)
        .map(|user| {
            (
                user.role_id.clone(),
                user.role_expires_at.clone(),
                role_expired(user),
            )
        })
        .unwrap_or((None, None, true));
    Json(json!({
        "menus": features.menus,
        "themes": features.themes,
        "modes": features.modes,
        "role_id": role_id,
        "role_expires_at": role_expires_at,
        "role_expired": role_expired_flag
    }))
}

/// 待答问卷只发给归属账号本人（同 `check_status`）：
/// 原先直接采信路径 `{user_id}`，任何已注册设备都能读出别人的问卷进度与作答状态。
async fn client_surveys(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Path(user_id): Path<String>,
) -> Json<Value> {
    if let Err(e) = assert_client_owner(&verified_user_id, &user_id) {
        return e;
    }
    let data = state.data.read().await;
    let surveys = survey::pending_surveys(
        data.survey_settings.enabled,
        &data.surveys,
        &data.survey_submissions,
        &user_id,
    );
    Json(json!({
        "enabled": data.survey_settings.enabled,
        "surveys": surveys
    }))
}

/// 普通附件的硬上限（路由层 body limit）。真正的额度由管理端的
/// `server_settings.max_upload_mb` 决定，默认 10 MiB，最大 64 MiB。
const MAX_UPLOAD_HARD_BYTES: u64 = 64 * 1024 * 1024;

/// 资产社区直传的绝对上限。真正的业务上限由后台设置 `max_upload_mb` 决定，
/// 这里只是把 axum 的默认 2 MiB 请求体上限抬到足够高，否则大文件会在进
/// handler 之前就被无声 413 掉。
const MAX_COMMUNITY_UPLOAD_BYTES: usize = 512 * 1024 * 1024;

static UPLOAD_SEQ: AtomicU64 = AtomicU64::new(1);

/// Directory that stores respondent-uploaded files; derived from the state file location.
fn uploads_dir(state: &AppState) -> PathBuf {
    let parent = state
        .data_file
        .parent()
        .unwrap_or_else(|| FsPath::new("."));
    parent.join("uploads")
}

fn dir_total_bytes(dir: &FsPath) -> u64 {
    let Ok(entries) = std::fs::read_dir(dir) else {
        return 0;
    };
    entries
        .filter_map(|entry| entry.ok())
        .filter_map(|entry| entry.metadata().ok())
        .filter(|meta| meta.is_file())
        .map(|meta| meta.len())
        .sum()
}

fn to_hex(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push_str(&format!("{byte:02x}"));
    }
    out
}

fn safe_extension(name: &str) -> bool {
    !name.is_empty() && name.len() <= 12 && name.chars().all(|c| c.is_ascii_alphanumeric())
}

/// 落盘文件名一律是 `<内容 SHA-256>.<扩展名>`。只放行这种形态，
/// 任何带 `/`、`..`、空段的名字都直接当不存在，杜绝路径穿越。
fn is_upload_name(name: &str) -> bool {
    let Some((stem, ext)) = name.rsplit_once('.') else {
        return false;
    };
    stem.len() == 64
        && stem.chars().all(|c| c.is_ascii_hexdigit())
        && safe_extension(&ext.to_ascii_lowercase())
    }

fn extension_for(mime: &str, file_name: Option<&str>) -> String {
    if let Some(name) = file_name {
        if let Some((_, ext)) = name.rsplit_once('.') {
            let ext = ext.to_lowercase();
            if safe_extension(&ext) {
                return ext;
            }
        }
    }
    match mime {
        "image/png" => "png",
        "image/jpeg" => "jpg",
        "image/gif" => "gif",
        "image/webp" => "webp",
        "image/bmp" => "bmp",
        "image/svg+xml" => "svg",
        "application/pdf" => "pdf",
        "text/plain" => "txt",
        "application/msword" => "doc",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" => "docx",
        _ => "bin",
    }
    .to_string()
}

fn mime_for(name: &str) -> &'static str {
    match name.rsplit_once('.').map(|(_, e)| e.to_lowercase()).as_deref() {
        Some("png") => "image/png",
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("gif") => "image/gif",
        Some("webp") => "image/webp",
        Some("bmp") => "image/bmp",
        Some("svg") => "image/svg+xml",
        Some("pdf") => "application/pdf",
        Some("txt") => "text/plain",
        Some("doc") => "application/msword",
        Some("docx") => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        _ => "application/octet-stream",
    }
}

#[derive(Deserialize)]
struct UploadQuery {
    user_id: String,
    survey_id: String,
    question_id: String,
    #[serde(default)]
    file_name: Option<String>,
}

async fn client_upload_file(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Query(params): Query<UploadQuery>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    // 路径里的 user_id 只用于写审计日志，但如果不校验，任何已注册设备都能把附件
    // 记到别人名下（污染答卷归属与审计记录）。
    if verified_user_id != params.user_id {
        return (
            StatusCode::UNAUTHORIZED,
            "Client token does not match claimed user_id",
        )
            .into_response();
    }
    if body.is_empty() {
        return (StatusCode::BAD_REQUEST, "empty file").into_response();
    }
    let max_mb = state.data.read().await.server_settings.max_upload_mb;
    if body.len() as u64 > max_mb * 1024 * 1024 {
        return (
            StatusCode::PAYLOAD_TOO_LARGE,
            format!("file exceeds size limit ({max_mb} MiB)"),
        )
            .into_response();
    }
    let uploads = uploads_dir(&state);
    if let Err(error) = std::fs::create_dir_all(&uploads) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to create uploads dir: {error}"),
        )
            .into_response();
    }
    let mime = headers
        .get(CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("application/octet-stream")
        .to_string();
    let ext = extension_for(&mime, params.file_name.as_deref());
    let mut hasher = Sha256::new();
    hasher.update(now_string().as_bytes());
    hasher.update(UPLOAD_SEQ.fetch_add(1, Ordering::Relaxed).to_le_bytes());
    hasher.update(&body);
    let file_id = to_hex(&hasher.finalize());
    let stored_name = format!("{file_id}.{ext}");
    let path = uploads.join(&stored_name);
    if let Err(error) = std::fs::write(&path, &body) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to write file: {error}"),
        )
            .into_response();
    }
    let file_name = params.file_name.unwrap_or_else(|| stored_name.clone());
    let payload = SurveyAnswerFile {
        file_id,
        file_name,
        mime_type: mime,
        size: body.len() as u64,
        url: format!("/api/client/uploads/{stored_name}"),
    };
    info!(
        user_id = %params.user_id,
        survey_id = %params.survey_id,
        question_id = %params.question_id,
        "respondent uploaded a survey answer file"
    );
    Json(payload).into_response()
}

/// 按文件名取回答附件。
///
/// 访问控制现状（诚实记录，尚未做到「按上传者隔离」）：
/// 文件名是 `sha256(当前时间 + 递增序号 + 文件内容)` 的十六进制串，2^256 空间、不可枚举，
/// 服务端也没有列表接口，因此只有拿到该 URL 的人（也就是上传者本人，或后来能看到这份
/// 答卷的管理员）才读得到内容。但服务端**没有维护 file_id → user_id 的归属表**，
/// 所以任何持有合法 client token 的设备，只要知道文件名就能取到内容 —— 例如
/// 同一次会话里被共享出去的链接。真正的隔离需要落一张归属表或改用短期签名 URL，
/// 已在 `.scratch/defect-followups-2026-10-14/issues/09` 里登记。
async fn client_get_upload(State(state): State<AppState>, Path(raw): Path<String>) -> Response {
    if raw.is_empty()
        || raw.contains('/')
        || raw.contains('\\')
        || raw.contains("..")
        || raw.contains('\0')
    {
        return (StatusCode::BAD_REQUEST, "invalid file id").into_response();
    }
    let uploads = uploads_dir(&state);
    let _ = std::fs::create_dir_all(&uploads);
    let Ok(root) = std::fs::canonicalize(&uploads) else {
        return (StatusCode::NOT_FOUND, "not found").into_response();
    };
    let path = uploads.join(&raw);
    let Ok(target) = std::fs::canonicalize(&path) else {
        return (StatusCode::NOT_FOUND, "not found").into_response();
    };
    if !target.starts_with(&root) {
        return (StatusCode::FORBIDDEN, "forbidden").into_response();
    }
    match tokio::fs::read(&path).await {
        Ok(bytes) => {
            let mut response = Response::new(Body::from(bytes));
            if let Ok(value) = HeaderValue::from_str(mime_for(&raw)) {
                response.headers_mut().insert(CONTENT_TYPE, value);
            }
            response
        }
        Err(_) => (StatusCode::NOT_FOUND, "not found").into_response(),
    }
}

async fn client_click_survey(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<ClickSurveyRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    let mut data = state.data.write().await;
    // Snapshot question/option/survey labels server-side so the click log stays
    // readable even after the survey is edited or deleted.
    let (survey_title, revision, question_title, option_label) =
        match data.surveys.get(&request.survey_id) {
            Some(survey) => {
                let question = survey
                    .questions
                    .iter()
                    .find(|question| question.question_id == request.question_id);
                let question_title = question
                    .map(|question| question.title.clone())
                    .filter(|title| !title.is_empty())
                    .unwrap_or_else(|| request.question_title.clone());
                let option_label = question
                    .and_then(|question| {
                        question
                            .options
                            .iter()
                            .find(|option| option.option_id == request.option_id)
                    })
                    .map(|option| option.label.clone())
                    .filter(|label| !label.is_empty())
                    .unwrap_or_else(|| request.option_label.clone());
                (
                    survey.title.clone(),
                    if request.survey_revision > 0 {
                        request.survey_revision
                    } else {
                        survey.revision
                    },
                    question_title,
                    option_label,
                )
            }
            None => (
                String::new(),
                request.survey_revision,
                request.question_title.clone(),
                request.option_label.clone(),
            ),
        };

    let action = match request.action.as_str() {
        "deselect" | "input" => request.action.clone(),
        _ => "select".to_string(),
    };
    let event = SurveyClickEvent {
        event_id: survey::new_id("click"),
        survey_id: request.survey_id,
        survey_revision: revision,
        survey_title,
        user_id: request.user_id,
        question_id: request.question_id,
        question_title,
        option_id: request.option_id,
        option_label,
        action,
        text_value: request.text_value,
        clicked_at: now_string(),
        submission_id: String::new(),
    };
    data.survey_click_events.push(event);
    let overflow = data
        .survey_click_events
        .len()
        .saturating_sub(MAX_SURVEY_CLICK_EVENTS);
    if overflow > 0 {
        data.survey_click_events.drain(0..overflow);
    }
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true }))
}

async fn client_submit_survey(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<SubmitSurveyRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    let mut data = state.data.write().await;
    let Some(survey) = data.surveys.get(&request.survey_id).cloned() else {
        return Json(json!({ "success": false, "message": "Survey not found" }));
    };
    if survey.status != "published" || survey.revision != request.survey_revision {
        return Json(json!({ "success": false, "message": "Survey version is no longer active" }));
    }
    let evaluation = survey::evaluate(&survey, &request.answers);
    let submission_id = survey::new_id("submission");
    let status = if evaluation.passed {
        "passed"
    } else {
        "failed"
    };
    // Link this user's unclaimed clicks for the same survey + revision to the
    // submission so the admin panel can show a per-submission click timeline.
    let click_events: Vec<SurveyClickEvent> = data
        .survey_click_events
        .iter_mut()
        .filter(|event| {
            event.submission_id.is_empty()
                && event.user_id == request.user_id
                && event.survey_id == request.survey_id
                && event.survey_revision == survey.revision
        })
        .map(|event| {
            event.submission_id = submission_id.clone();
            event.clone()
        })
        .collect();
    data.survey_submissions.insert(
        submission_id.clone(),
        SurveySubmission {
            submission_id: submission_id.clone(),
            survey_id: survey.survey_id.clone(),
            survey_revision: survey.revision,
            survey_title: survey.title.clone(),
            user_id: request.user_id.clone(),
            submitted_at: now_string(),
            status: status.to_string(),
            passed: evaluation.passed,
            answers: request.answers,
            answer_files: request.answer_files.unwrap_or_default(),
            failed_question_ids: evaluation.failed_question_ids.clone(),
            click_events,
        },
    );

    // Incentive: when the submission passes and the survey defines a reward, grant
    // the configured role (temporary or permanent) to the submitting user.
    let mut reward_payload: Option<Value> = None;
    if evaluation.passed {
        if let Some(grant) = &survey.reward {
            if let Some(user) = data.users.get_mut(&request.user_id) {
                user.role_id = Some(grant.role_id.clone());
                let expires_at = grant.duration_value.and_then(|value| {
                    let seconds = match grant.duration_unit.as_str() {
                        "day" => value * 86400.0,
                        "month" => value * 2_592_000.0,
                        "year" => value * 31_536_000.0,
                        _ => value * 3600.0, // hour (default)
                    };
                    let secs = seconds as i64;
                    if secs <= 0 {
                        return None;
                    }
                    Some(
                        (Local::now() + Duration::seconds(secs))
                            .format("%Y-%m-%d %H:%M:%S")
                            .to_string(),
                    )
                });
                user.role_expires_at = expires_at.clone();
                reward_payload = Some(json!({
                    "role_id": grant.role_id,
                    "role_name": data.roles.get(&grant.role_id).map(|role| role.role_name.clone()),
                    "duration_value": grant.duration_value,
                    "duration_unit": grant.duration_unit,
                    "expires_at": expires_at,
                    "permanent": grant.duration_value.is_none()
                }));
            }
        }
    }

    drop(data);
    schedule_persist(&state);
    let mut response = json!({
        "success": true,
        "submission_id": submission_id,
        "passed": evaluation.passed,
        "failed_question_ids": evaluation.failed_question_ids,
        "access_granted": evaluation.passed || !survey.required_for_access
    });
    if let Some(reward) = reward_payload {
        response["reward"] = reward;
    }
    Json(response)
}

async fn client_dismiss_survey(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<DismissSurveyRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    let mut data = state.data.write().await;
    let Some(survey) = data.surveys.get(&request.survey_id).cloned() else {
        return Json(json!({ "success": false, "message": "Survey not found" }));
    };
    if survey.required_for_access {
        return Json(json!({ "success": false, "message": "This survey is required" }));
    }
    if survey.status != "published" || survey.revision != request.survey_revision {
        return Json(json!({ "success": false, "message": "Survey version is no longer active" }));
    }
    let submission_id = survey::new_id("submission");
    data.survey_submissions.insert(
        submission_id.clone(),
        SurveySubmission {
            submission_id,
            survey_id: survey.survey_id,
            survey_revision: survey.revision,
            survey_title: survey.title,
            user_id: request.user_id,
            submitted_at: now_string(),
            status: "dismissed".to_string(),
            passed: false,
            answers: HashMap::new(),
            answer_files: HashMap::new(),
            failed_question_ids: Vec::new(),
            click_events: Vec::new(),
        },
    );
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "Survey dismissed" }))
}

async fn client_survey_history(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Path(user_id): Path<String>,
) -> Json<Value> {
    if let Err(e) = assert_client_owner(&verified_user_id, &user_id) {
        return e;
    }
    let data = state.data.read().await;
    let mut submissions: Vec<SurveySubmission> = data
        .survey_submissions
        .values()
        .filter(|submission| submission.user_id == user_id)
        .cloned()
        .collect();
    submissions.sort_by(|left, right| right.submitted_at.cmp(&left.submitted_at));
    Json(json!({ "submissions": submissions }))
}

async fn client_delete_submission(
    State(state): State<AppState>,
    Extension(verified_user_id): Extension<String>,
    Json(request): Json<DeleteSubmissionRequest>,
) -> Json<Value> {
    if verified_user_id != request.user_id {
        return Json(json!({"status": "auth_failed", "reason": "Token mismatch"}));
    }
    let mut data = state.data.write().await;
    let owned = data
        .survey_submissions
        .get(&request.submission_id)
        .is_some_and(|submission| submission.user_id == request.user_id);
    if owned {
        data.survey_submissions.remove(&request.submission_id);
    }
    drop(data);
    if owned {
        schedule_persist(&state);
    }
    Json(json!({
        "success": owned,
        "message": if owned { "Submission deleted" } else { "Submission not found" }
    }))
}

/// R4：管理员口令爆破防护。同一来源 IP 连续失败 ADMIN_AUTH_MAX_FAILURES 次后
/// 锁定 ADMIN_AUTH_LOCKOUT_SECS 秒，避免口令被离线/在线穷举。
const ADMIN_AUTH_MAX_FAILURES: u32 = 5;
const ADMIN_AUTH_LOCKOUT_SECS: i64 = 300;

static ADMIN_AUTH_ATTEMPTS: std::sync::OnceLock<std::sync::Mutex<HashMap<String, (u32, i64)>>> =
    std::sync::OnceLock::new();

static REGISTER_ATTEMPTS: std::sync::OnceLock<std::sync::Mutex<HashMap<String, (u32, i64)>>> =
    std::sync::OnceLock::new();

/// 注册接口会代打 VRChat 官方 API，公开且无凭据，按 IP 限速防止被当成放大器。
fn register_gate(ip: &str, limit: u32) -> bool {
    const WINDOW_SECS: i64 = 3600;
    let store = REGISTER_ATTEMPTS.get_or_init(|| std::sync::Mutex::new(HashMap::new()));
    let mut guard = store.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = chrono::Utc::now().timestamp();
    if guard.len() > 4000 {
        guard.retain(|_, value| value.1 > now);
    }
    let tries = {
        let entry = guard.entry(ip.to_string()).or_insert((0, now + WINDOW_SECS));
        if entry.1 <= now {
            *entry = (0, now + WINDOW_SECS);
        }
        entry.0 += 1;
        entry.0
    };
    tries <= limit
}

static INQUIRY_SUBMIT_QUOTA: std::sync::OnceLock<std::sync::Mutex<HashMap<String, (u32, i64)>>> =
    std::sync::OnceLock::new();

/// 每次提交都会给管理员发一封邮件，按 VRChat 账号限速，避免把邮箱刷爆。
fn inquiry_submit_gate(vrchat_id: &str) -> bool {
    const WINDOW_SECS: i64 = 3600;
    const LIMIT: u32 = 5;
    let store = INQUIRY_SUBMIT_QUOTA.get_or_init(|| std::sync::Mutex::new(HashMap::new()));
    let mut guard = store.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = chrono::Utc::now().timestamp();
    if guard.len() > 4000 {
        guard.retain(|_, value| value.1 > now);
    }
    let tries = {
        let entry = guard.entry(vrchat_id.to_string()).or_insert((0, now + WINDOW_SECS));
        if entry.1 <= now {
            *entry = (0, now + WINDOW_SECS);
        }
        entry.0 += 1;
        entry.0
    };
    tries <= LIMIT
}

fn admin_auth_attempts() -> &'static std::sync::Mutex<HashMap<String, (u32, i64)>> {
    ADMIN_AUTH_ATTEMPTS.get_or_init(|| std::sync::Mutex::new(HashMap::new()))
}

static SITE_AUTH_ATTEMPTS: std::sync::OnceLock<std::sync::Mutex<HashMap<String, (u32, i64)>>> =
    std::sync::OnceLock::new();

/// 官网登录限流：同一 IP 10 分钟内最多 15 次密码尝试，超了先歇一歇。
fn site_auth_gate(ip: &str) -> bool {
    const WINDOW_SECS: i64 = 600;
    const LIMIT: u32 = 15;
    let store = SITE_AUTH_ATTEMPTS.get_or_init(|| std::sync::Mutex::new(HashMap::new()));
    let mut guard = store.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = chrono::Utc::now().timestamp();
    // 顺带清理长期不活跃的键，避免这张表本身无限长。
    if guard.len() > 4000 {
        guard.retain(|_, value| value.1 > now);
    }
    let tries = {
        let entry = guard.entry(ip.to_string()).or_insert((0, now + WINDOW_SECS));
        if entry.1 <= now {
            *entry = (0, now + WINDOW_SECS);
        }
        entry.0 += 1;
        entry.0
    };
    tries <= LIMIT
}

/// 返回剩余锁定秒数，0 表示未锁定。锁定到期后自动重置计数。
fn admin_auth_lock_remaining(ip: &str) -> i64 {
    let mut guard = admin_auth_attempts()
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = chrono::Utc::now().timestamp();
    let entry = guard.entry(ip.to_string()).or_insert((0, 0));
    if entry.1 > now {
        return entry.1 - now;
    }
    if entry.1 != 0 {
        *entry = (0, 0);
    }
    0
}

fn admin_auth_record_failure(ip: &str) {
    let mut guard = admin_auth_attempts()
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let now = chrono::Utc::now().timestamp();
    let entry = guard.entry(ip.to_string()).or_insert((0, 0));
    entry.0 += 1;
    if entry.0 >= ADMIN_AUTH_MAX_FAILURES {
        warn!(%ip, "管理员口令连续失败次数过多，已临时锁定该来源 IP");
        *entry = (0, now + ADMIN_AUTH_LOCKOUT_SECS);
    }
}

// ── 图形验证码 ─────────────────────────────────────────────────────────────
// 官网登录与管理台登录共用。答案是服务端内存里的一次性票据，前端只拿到 id 与 SVG。
const CAPTCHA_ALPHABET: &[u8] = b"23456789abcdefghjkmnpqrstuvwxyz";

fn captcha_random_code() -> String {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    (0..CAPTCHA_CODE_LEN)
        .map(|_| CAPTCHA_ALPHABET[rng.gen_range(0..CAPTCHA_ALPHABET.len())] as char)
        .collect()
}

/// 生成 132×44 的 SVG 验证码：字符随机旋转错位，叠干扰线与噪点。
fn captcha_svg(code: &str) -> String {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    let (w, h) = (132i32, 44i32);
    let mut out = String::with_capacity(1600);
    out.push_str(&format!(
        r#"<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">"#
    ));
    out.push_str(r##"<rect x="0" y="0" width="132" height="44" fill="#f7f8fa"/>"##);
    for _ in 0..4 {
        let x1 = rng.gen_range(2..w - 2);
        let y1 = rng.gen_range(2..h - 2);
        let x2 = rng.gen_range(2..w - 2);
        let y2 = rng.gen_range(2..h - 2);
        let color = ["#c9cdd4", "#d6d9de", "#bfc4cb"][rng.gen_range(0..3)];
        out.push_str(&format!(
            r#"<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="1"/>"#
        ));
    }
    for _ in 0..24 {
        let cx = rng.gen_range(2..w - 2);
        let cy = rng.gen_range(2..h - 2);
        let color = ["#d9dce1", "#c5cad2"][rng.gen_range(0..2)];
        out.push_str(&format!(
            r#"<circle cx="{cx}" cy="{cy}" r="1" fill="{color}"/>"#
        ));
    }
    for (index, ch) in code.chars().enumerate() {
        let base_x = 18 + index as i32 * 30;
        let x = base_x + rng.gen_range(-2..3);
        let y = 30 + rng.gen_range(-3..4);
        let rotate = rng.gen_range(-14..15);
        let color = ["#1d2129", "#31383f", "#4e5969"][rng.gen_range(0..3)];
        out.push_str(&format!(
            r#"<text x="{x}" y="{y}" transform="rotate({rotate} {x} {y})" font-family="Arial,Helvetica,sans-serif" font-size="25" font-weight="700" fill="{color}">{ch}</text>"#
        ));
    }
    out.push_str("</svg>");
    out
}

/// 下发一张验证码，答案留在服务端内存（顺带清理过期项）。
async fn issue_captcha(state: &AppState) -> (String, String) {
    let id = hex::encode(rand::random::<[u8; 8]>());
    let code = captcha_random_code();
    let mut store = state.captchas.write().await;
    store.retain(|_, entry| entry.created.elapsed() < StdDuration::from_secs(CAPTCHA_TTL_SECS * 2));
    // 公开接口可以被无限刷，这里给内存里的验证码加个硬上限。
    if store.len() >= 4000 {
        store.retain(|_, entry| entry.created.elapsed() < StdDuration::from_secs(60));
    }
    if store.len() >= 4000 {
        store.clear();
    }
    store.insert(
        id.clone(),
        CaptchaEntry {
            code: code.clone(),
            created: Instant::now(),
        },
    );
    (id, captcha_svg(&code))
}

/// 校验图形验证码：答对才作废；答错保留，方便用户原地重试。
async fn consume_captcha(state: &AppState, id: &str, code: &str) -> Result<(), String> {
    let id = id.trim();
    if id.is_empty() {
        return Err("请先获取图形验证码".to_string());
    }
    let found = {
        let store = state.captchas.read().await;
        store.get(id).map(|entry| (entry.code.clone(), entry.created))
    };
    let Some((expected, created)) = found else {
        return Err("图形验证码已失效，请点击图片换一张".to_string());
    };
    if created.elapsed() > StdDuration::from_secs(CAPTCHA_TTL_SECS) {
        state.captchas.write().await.remove(id);
        return Err("图形验证码已过期，请点击图片换一张".to_string());
    }
    if !expected.eq_ignore_ascii_case(code.trim()) {
        return Err("图形验证码不正确，请重试".to_string());
    }
    state.captchas.write().await.remove(id);
    Ok(())
}

/// GET /api/site/captcha —— 官网与管理台共用，公开接口。
async fn site_captcha(State(state): State<AppState>) -> Json<Value> {
    let (id, svg) = issue_captcha(&state).await;
    Json(json!({
        "success": true,
        "id": id,
        "svg": svg,
        "expires_in": CAPTCHA_TTL_SECS
    }))
}

fn admin_auth_record_success(ip: &str) {
    let mut guard = admin_auth_attempts()
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    guard.remove(ip);
}

async fn admin_auth(
    State(state): State<AppState>,
    ConnectInfo(address): ConnectInfo<SocketAddr>,
    headers: HeaderMap,
    Json(request): Json<AdminAuthRequest>,
) -> impl axum::response::IntoResponse {
    let client_ip = address.ip().to_string();
    let remaining = admin_auth_lock_remaining(&client_ip);
    if remaining > 0 {
        return (
            StatusCode::TOO_MANY_REQUESTS,
            Json(json!({
                "success": false,
                "message": format!("尝试失败次数过多，请 {} 秒后重试", remaining)
            })),
        );
    }

    // 网页管理台（带 x-vrcdog-console 头）必须过图形验证码；
    // 客户端内嵌的管理面板沿用原口令通道，避免已有安装全部登不上。
    let from_console = headers
        .get("x-vrcdog-console")
        .and_then(|value| value.to_str().ok())
        .map(|value| value.trim() == "1")
        .unwrap_or(false);
    if from_console {
        if let Err(message) = consume_captcha(&state, &request.captcha_id, &request.captcha_code).await {
            return (
                StatusCode::BAD_REQUEST,
                Json(json!({ "success": false, "message": message, "captcha": true })),
            );
        }
    }

    let account = { state.data.read().await.admin_account.clone() };
    let submitted_name = request
        .username
        .clone()
        .unwrap_or_else(|| account.username.clone());
    let username_ok = submitted_name.trim().eq_ignore_ascii_case(account.username.trim());
    // 旧部署可能只配了 VRCDOG_SERVER_PASSWORD_BCRYPT，这里保留兼容：
    // 账号名仍要对，口令命中旧 bcrypt 也能登录，避免升级后把人锁在门外。
    let password_ok = bcrypt::verify(&request.password, &account.password_hash).unwrap_or(false)
        || verify_server_password(&request.password);

    if username_ok && password_ok {
        admin_auth_record_success(&client_ip);
        let token = hex::encode(rand::random::<[u8; 32]>());
        let session = AdminSession {
            created_at: now_string(),
            username: account.username.clone(),
        };
        state.admin_sessions.write().await.insert(token.clone(), session);
        (
            StatusCode::OK,
            Json(json!({
                "success": true,
                "token": token,
                "username": account.username
            })),
        )
    } else {
        admin_auth_record_failure(&client_ip);
        (
            StatusCode::UNAUTHORIZED,
            Json(json!({
                "success": false,
                "message": "账号或密码不正确"
            })),
        )
    }
}

#[derive(Deserialize)]
struct ChangePasswordRequest {
    #[serde(default)]
    old_password: String,
    new_password: String,
}

/// 改管理员密码。改完立刻写盘，网站与客户端下一次登录就用新口令。
async fn admin_change_password(
    State(state): State<AppState>,
    Json(request): Json<ChangePasswordRequest>,
) -> Json<Value> {
    let new_password = request.new_password.trim().to_string();
    let count = new_password.chars().count();
    if count < 6 {
        return Json(json!({"success": false, "message": "新密码至少 6 位"}));
    }
    if count > 128 {
        return Json(json!({"success": false, "message": "新密码不能超过 128 位"}));
    }
    let account = { state.data.read().await.admin_account.clone() };
    let old_ok = bcrypt::verify(&request.old_password, &account.password_hash).unwrap_or(false)
        || verify_server_password(&request.old_password);
    if !old_ok {
        return Json(json!({"success": false, "message": "原密码不正确"}));
    }
    let hash = match bcrypt::hash(&new_password, bcrypt::DEFAULT_COST) {
        Ok(hash) => hash,
        Err(error) => {
            return Json(json!({"success": false, "message": format!("生成口令失败：{error}")}))
        }
    };
    {
        let mut data = state.data.write().await;
        data.admin_account.password_hash = hash;
    }
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "message": "密码已更新，官网与客户端共用同一套凭据"
    }))
}

async fn admin_me(State(state): State<AppState>) -> Json<Value> {
    let account = state.data.read().await.admin_account.clone();
    Json(json!({"success": true, "username": account.username}))
}

// ---------- 官网：VRChat 登录代理（VRCX 同款官方 API） ----------

/// 与桌面客户端完全一致的 UA：VRChat 的 WAF 会校验 UA 格式，
/// 客户端能过的写法官网也照抄，别自创品牌串。
const VRC_UA: &str = concat!("VRCDog/", env!("CARGO_PKG_VERSION"));
const VRC_REFERER: &str = "https://vrchat.com/";

/// VRChat 的 Basic 认证要求用户名和密码各自 urlencode 后再拼成 `user:pass`。
/// 邮箱里的 `@`、`+` 不编码会被官方当成凭据错误直接回 401。
fn vrc_encode(value: &str) -> String {
    let mut out = String::with_capacity(value.len() * 3);
    for byte in value.as_bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'.' | b'_' | b'~' => {
                out.push(*byte as char)
            }
            _ => out.push_str(&format!("%{byte:02X}")),
        }
    }
    out
}

/// 标准 base64（RFC 4648，带 `=` 补位）。只为一处 header 用，不必再引新依赖。
fn b64_encode(input: &str) -> String {
    const TABLE: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let bytes = input.as_bytes();
    let mut out = String::with_capacity((bytes.len() + 2) / 3 * 4);
    for chunk in bytes.chunks(3) {
        let b0 = chunk[0];
        let b1 = *chunk.get(1).unwrap_or(&0);
        let b2 = *chunk.get(2).unwrap_or(&0);
        let idx0 = (b0 >> 2) as usize;
        let idx1 = (((b0 & 0b11) << 4) | (b1 >> 4)) as usize;
        let idx2 = (((b1 & 0b1111) << 2) | (b2 >> 6)) as usize;
        let idx3 = (b2 & 0b111111) as usize;
        out.push(TABLE[idx0] as char);
        out.push(TABLE[idx1] as char);
        if chunk.len() > 1 {
            out.push(TABLE[idx2] as char);
        } else {
            out.push('=');
        }
        if chunk.len() > 2 {
            out.push(TABLE[idx3] as char);
        } else {
            out.push('=');
        }
    }
    out
}

/// 与 VRChat 官方一致：base64(urlencode(user):urlencode(password))。
fn vrc_basic(username: &str, password: &str) -> String {
    format!(
        "Basic {}",
        b64_encode(&format!("{}:{}", vrc_encode(username), vrc_encode(password)))
    )
}

fn vrchat_api_base() -> String {
    env::var("VRCHAT_API_BASE")
        .ok()
        .map(|value| value.trim().trim_end_matches('/').to_string())
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "https://api.vrchat.cloud".to_string())
}

/// 配置地址之外再补一个官方地址：自建中转下线时，登录仍然能用。
fn vrchat_api_bases() -> Vec<String> {
    let primary = vrchat_api_base();
    if primary.contains("api.vrchat.cloud") {
        vec![primary]
    } else {
        vec![primary, "https://api.vrchat.cloud".to_string()]
    }
}

/// VRChat `auth/user` 的一次完整应答。状态、Set-Cookie 与 body 一起拿回来，
/// 这样才能分辨「VRChat 明确说凭据错」和「中转/网关自己回了个空 401」。
struct VrcAuthResponse {
    status: reqwest::StatusCode,
    headers: reqwest::header::HeaderMap,
    body: Value,
}

impl VrcAuthResponse {
    /// VRChat 亲口给出的结论（有 error.message 或要求两步验证），不是中间层伪造的。
    fn from_vrchat(&self) -> bool {
        self.body.get("requiresTwoFactorAuth").is_some()
            || self
                .body
                .get("error")
                .and_then(|error| error.get("message"))
                .and_then(|value| value.as_str())
                .map(|text| !text.trim().is_empty())
                .unwrap_or(false)
    }
}

async fn vrchat_get_auth_user(
    state: &AppState,
    credentials: Option<(&str, &str)>,
    cookie: Option<&str>,
) -> Result<VrcAuthResponse, reqwest::Error> {
    let bases = vrchat_api_bases();
    let mut last_error: Option<reqwest::Error> = None;
    let mut last_response: Option<VrcAuthResponse> = None;
    for (index, base) in bases.iter().enumerate() {
        let mut request = state
            .http_client
            .get(format!("{base}/api/1/auth/user"))
            .header("User-Agent", VRC_UA)
            .header("Referer", VRC_REFERER)
            .header("Accept", "application/json");
        if let Some((username, password)) = credentials {
            request = request.header("Authorization", vrc_basic(username, password));
        }
        if let Some(value) = cookie {
            request = request.header("Cookie", value);
        }
        match request.send().await {
            Ok(response) => {
                let status = response.status();
                let headers = response.headers().clone();
                let body: Value = response.json().await.unwrap_or_else(|_| json!({}));
                let answer = VrcAuthResponse {
                    status,
                    headers,
                    body,
                };
                let has_next = index + 1 < bases.len();
                // 中转/网关自己炸了（5xx）就换下一个地址，别把 502 当成密码错误。
                if status.is_server_error() && has_next {
                    continue;
                }
                // 401 却没有 VRChat 的错误结构：多半是网关/中转伪造的，
                // 换官方地址再试，别让用户看到一句没头没脑的“密码错误”。
                if status.as_u16() == 401 && !answer.from_vrchat() && has_next {
                    last_response = Some(answer);
                    continue;
                }
                return Ok(answer);
            }
            Err(error) => last_error = Some(error),
        }
    }
    if let Some(answer) = last_response {
        return Ok(answer);
    }
    Err(last_error.expect("至少配置了一个 VRChat API 地址"))
}

async fn vrchat_verify_two_factor(
    state: &AppState,
    kind: &str,
    username: &str,
    password: &str,
    cookie: &str,
    code: &str,
) -> Result<reqwest::Response, reqwest::Error> {
    let bases = vrchat_api_bases();
    let mut last_error: Option<reqwest::Error> = None;
    for (index, base) in bases.iter().enumerate() {
        let request = state
            .http_client
            .post(format!("{base}/api/1/auth/twofactorauth/{kind}/verify"))
            .header("User-Agent", VRC_UA)
            .header("Referer", VRC_REFERER)
            .header("Accept", "application/json")
            .header("Authorization", vrc_basic(username, password))
            .header("Cookie", cookie)
            .json(&json!({ "code": code }));
        match request.send().await {
            Ok(response) => {
                if response.status().is_server_error() && index + 1 < bases.len() {
                    continue;
                }
                return Ok(response);
            }
            Err(error) => last_error = Some(error),
        }
    }
    Err(last_error.expect("至少配置了一个 VRChat API 地址"))
}


fn cookie_value(headers: &reqwest::header::HeaderMap, name: &str) -> Option<String> {
    for value in headers.get_all(reqwest::header::SET_COOKIE).iter() {
        let Ok(text) = value.to_str() else {
            continue;
        };
        let pair = text.split(';').next().unwrap_or_default().trim();
        if let Some((key, val)) = pair.split_once('=') {
            if key.trim() == name {
                return Some(val.trim().to_string());
            }
        }
    }
    None
}

/// VRChat 的英文报错直接转成人话，避免用户在中文界面里看到一串英文原因。
fn vrc_auth_error_text(detail: &str) -> String {
    let lower = detail.to_lowercase();
    if lower.contains("url-encoded") || lower.contains("url encoded") {
        return detail.to_string();
    }
    if lower.contains("invalid username")
        || lower.contains("invalid email")
        || lower.contains("invalid credentials")
        || lower.contains("or password")
    {
        return "邮箱/用户名或密码不正确".to_string();
    }
    if lower.contains("too many") || lower.contains("rate limit") {
        return "尝试次数过多，请过几分钟再试".to_string();
    }
    if lower.contains("two factor") || lower.contains("2fa") {
        return "该账号需要两步验证，请按提示输入验证码".to_string();
    }
    detail.to_string()
}

fn vrchat_user_summary(body: &Value) -> Option<(String, String, String)> {
    let id = body.get("id")?.as_str()?.to_string();
    let name = body
        .get("displayName")
        .and_then(|value| value.as_str())
        .unwrap_or("VRChat 用户")
        .to_string();
    let avatar = body
        .get("currentAvatarThumbnailImageUrl")
        .or_else(|| body.get("currentAvatarImageUrl"))
        .and_then(|value| value.as_str())
        .unwrap_or("")
        .to_string();
    Some((id, name, avatar))
}

#[derive(Deserialize)]
struct SiteAuthRequest {
    #[serde(default)]
    username: String,
    #[serde(default)]
    password: String,
    #[serde(default)]
    otp: String,
    #[serde(default)]
    ticket: String,
    /// 两步验证方式：totp（认证器）或 emailOtp（邮箱验证码）。
    #[serde(default)]
    method: String,
    /// 图形验证码：只在第一段（账号密码）校验，第二段 2FA 不需要。
    #[serde(default)]
    captcha_id: String,
    #[serde(default)]
    captcha_code: String,
}

async fn site_auth(
    State(state): State<AppState>,
    ConnectInfo(address): ConnectInfo<SocketAddr>,
    Json(request): Json<SiteAuthRequest>,
) -> Json<Value> {
    // 第一段（输账号密码）按 IP 限流；验证码本身也能被脚本自动识别，
    // 不加限流等于把 VRChat 密码交给暴力枚举。
    if request.ticket.trim().is_empty() && !site_auth_gate(&address.ip().to_string()) {
        return Json(json!({
            "success": false,
            "message": "登录尝试过于频繁，请稍后再试"
        }));
    }
    // 第二段：ticket + 两步验证码
    if !request.ticket.trim().is_empty() {
        let ticket = {
            let tickets = state.vrchat_login_tickets.read().await;
            tickets.get(request.ticket.trim()).cloned()
        };
        let Some(ticket) = ticket else {
            return Json(json!({
                "success": false,
                "message": "登录会话已过期，请重新输入账号和密码"
            }));
        };
        let verify_kind = if request.method.to_ascii_lowercase().contains("email") {
            "emailotp"
        } else {
            "totp"
        };
        // 第一段已经拿到 auth cookie 的话一起带上，VRChat 会认这个登录态。
        let verify_cookie = if ticket.auth_cookie.is_empty() {
            format!("twoFactorAuth={}", ticket.two_factor_cookie)
        } else {
            format!(
                "auth={}; twoFactorAuth={}",
                ticket.auth_cookie, ticket.two_factor_cookie
            )
        };
        let verify = vrchat_verify_two_factor(
            &state,
            verify_kind,
            &ticket.username,
            &ticket.password,
            &verify_cookie,
            request.otp.trim(),
        )
        .await;
        let verified_auth = match verify {
            Ok(response) => {
                let status = response.status();
                let headers = response.headers().clone();
                let body: Value = response.json().await.unwrap_or_else(|_| json!({}));
                if !status.is_success()
                    || body.get("verified").and_then(|value| value.as_bool()) != Some(true)
                {
                    return Json(json!({
                        "success": false,
                        "need_otp": true,
                        "ticket": request.ticket.trim(),
                        "method": verify_kind,
                        "message": "验证码不正确，请重试"
                    }));
                }
                cookie_value(&headers, "auth").unwrap_or_default()
            }
            Err(_) => {
                return Json(json!({
                    "success": false,
                    "message": "无法连接 VRChat，请稍后重试"
                }))
            }
        };

        // 验证通过后按 VRCX 的方式续用登录态：优先用 auth cookie，只在完全没拿到时才回退密码重放。
        let auth_for_user = if verified_auth.is_empty() {
            ticket.auth_cookie.clone()
        } else {
            verified_auth.clone()
        };
        let who = if auth_for_user.is_empty() {
            vrchat_get_auth_user(
                &state,
                Some((&ticket.username, &ticket.password)),
                Some(&format!("twoFactorAuth={}", ticket.two_factor_cookie)),
            )
            .await
        } else {
            vrchat_get_auth_user(
                &state,
                None,
                Some(&format!(
                    "auth={}; twoFactorAuth={}",
                    auth_for_user, ticket.two_factor_cookie
                )),
            )
            .await
        };
        let body: Value = match who {
            Ok(answer) if answer.status.is_success() => answer.body,
            Ok(_) => {
                return Json(json!({
                    "success": false,
                    "message": "两步验证已通过，但读取账号信息失败，请稍后重试"
                }))
            }
            Err(_) => {
                return Json(json!({
                    "success": false,
                    "message": "无法连接 VRChat，请稍后重试"
                }))
            }
        };
        if body.get("requiresTwoFactorAuth").is_some() {
            return Json(json!({
                "success": false,
                "message": "两步验证还没完成，请重新输入验证码"
            }));
        }
        let Some((id, name, avatar)) = vrchat_user_summary(&body) else {
            return Json(json!({
                "success": false,
                "message": "VRChat 返回了无法识别的账号数据"
            }));
        };
        return finish_site_login(&state, id, name, avatar).await;
    }

    // 第一段：账号 + 密码。先过图形验证码，再去打官方接口，避免被脚本刷。
    if let Err(message) = consume_captcha(&state, &request.captcha_id, &request.captcha_code).await {
        return Json(json!({ "success": false, "message": message, "captcha": true }));
    }
    let username = request.username.trim();
    // 密码不做 trim：VRChat 密码允许符号与空格，裁掉反而可能登不上。
    let password = request.password.as_str();
    if username.is_empty() || request.password.trim().is_empty() {
        return Json(json!({"success": false, "message": "请输入 VRChat 账号和密码"}));
    }
    let auth = vrchat_get_auth_user(&state, Some((username, password)), None).await;
    let auth = match auth {
        Ok(auth) => auth,
        Err(_) => {
            return Json(json!({
                "success": false,
                "message": "无法连接 VRChat，请稍后重试"
            }))
        }
    };
    let status = auth.status;
    let headers = auth.headers;
    let body: Value = auth.body;

    // VRChat 在“账号密码正确、但还需要两步验证”时同样返回 401，
    // 所以必须先看 body 里的 requiresTwoFactorAuth，再判 401。
    let needs_2fa = body
        .get("requiresTwoFactorAuth")
        .and_then(|value| value.as_array())
        .map(|list| !list.is_empty())
        .unwrap_or(false);
    if needs_2fa {
        let two_factor_cookie = cookie_value(&headers, "twoFactorAuth").unwrap_or_default();
        if two_factor_cookie.is_empty() {
            return Json(json!({
                "success": false,
                "message": "VRChat 要求两步验证，但没取到验证会话，请重试"
            }));
        }
        let ticket = hex::encode(rand::random::<[u8; 16]>());
        let now = Local::now().naive_local();
        {
            let mut tickets = state.vrchat_login_tickets.write().await;
            tickets.retain(|_, item| {
                NaiveDateTime::parse_from_str(&item.created_at, "%Y-%m-%d %H:%M:%S")
                    .map(|created| created > now - Duration::minutes(5))
                    .unwrap_or(false)
            });
            tickets.insert(
                ticket.clone(),
                VrchatLoginTicket {
                    username: username.to_string(),
                    password: password.to_string(),
                    two_factor_cookie,
                    auth_cookie: cookie_value(&headers, "auth").unwrap_or_default(),
                    created_at: now_string(),
                },
            );
        }
        return Json(json!({
            "success": false,
            "need_otp": true,
            "ticket": ticket,
            "methods": body.get("requiresTwoFactorAuth").cloned().unwrap_or_else(|| json!([])),
            "message": "该账号开启了两步验证，请输入验证码"
        }));
    }

    if status.as_u16() == 401 {
        let detail = body
            .get("error")
            .and_then(|error| error.get("message"))
            .and_then(|value| value.as_str())
            .unwrap_or("")
            .trim()
            .trim_matches('"')
            .to_string();
        warn!(status = 401, detail = %detail, "VRChat auth/user 返回 401");
        // 有 detail = VRChat 亲口说的；没 detail = 中间层伪造的 401，别误导用户去改密码。
        let message = if detail.is_empty() {
            "VRChat 没有返回失败原因（HTTP 401），通常是网络中转拦截了登录请求，请稍后重试".to_string()
        } else {
            format!("VRChat 拒绝了这次登录：{}", vrc_auth_error_text(&detail))
        };
        return Json(json!({ "success": false, "message": message }));
    }
    if status.as_u16() == 403 || status.as_u16() == 429 {
        warn!(status = status.as_u16(), "VRChat auth/user 被限流或拒绝");
        return Json(json!({
            "success": false,
            "message": format!(
                "VRChat 暂时限制了这次登录（HTTP {}），通常几分钟后会恢复，请稍后再试",
                status.as_u16()
            )
        }));
    }
    if !status.is_success() {
        return Json(json!({
            "success": false,
            "message": format!("VRChat 登录失败（HTTP {}）", status.as_u16())
        }));
    }

    let Some((id, name, avatar)) = vrchat_user_summary(&body) else {
        return Json(json!({
            "success": false,
            "message": "VRChat 返回了无法识别的账号数据"
        }));
    };
    finish_site_login(&state, id, name, avatar).await
}

async fn finish_site_login(
    state: &AppState,
    vrchat_id: String,
    display_name: String,
    avatar: String,
) -> Json<Value> {
    let token = hex::encode(rand::random::<[u8; 32]>());
    let now = Local::now().naive_local();
    {
        let mut sessions = state.site_sessions.write().await;
        sessions.retain(|_, session| {
            NaiveDateTime::parse_from_str(&session.created_at, "%Y-%m-%d %H:%M:%S")
                .map(|created| created > now - Duration::days(7))
                .unwrap_or(false)
        });
        sessions.insert(
            token.clone(),
            SiteSession {
                vrchat_id: vrchat_id.clone(),
                display_name: display_name.clone(),
                avatar: avatar.clone(),
                created_at: now_string(),
                last_seen: now_string(),
            },
        );
    }
    // 记一份站点用户档案：管理台据此展示「有多少人通过 VRChat 注册」。
    {
        let mut data = state.data.write().await;
        let now = now_string();
        match data.site_users.get_mut(&vrchat_id) {
            Some(user) => {
                user.display_name = display_name.clone();
                user.avatar = avatar.clone();
                user.last_seen = now;
                user.login_count += 1;
            }
            None => {
                data.site_users.insert(
                    vrchat_id.clone(),
                    SiteUserRecord {
                        vrchat_id: vrchat_id.clone(),
                        display_name: display_name.clone(),
                        avatar: avatar.clone(),
                        first_seen: now.clone(),
                        last_seen: now,
                        login_count: 1,
                        email: String::new(),
                        ip: String::new(),
                    },
                );
            }
        }
    }
    schedule_persist(state);
    Json(json!({
        "success": true,
        "token": token,
        "user": { "id": vrchat_id, "displayName": display_name, "avatar": avatar }
    }))
}

async fn site_session_of(state: &AppState, headers: &HeaderMap) -> Option<SiteSession> {
    let token = headers
        .get("x-vrcdog-site-token")
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default()
        .to_string();
    if token.is_empty() {
        return None;
    }
    state.site_sessions.read().await.get(&token).cloned()
}

async fn site_me(State(state): State<AppState>, headers: HeaderMap) -> Json<Value> {
    let token = headers
        .get("x-vrcdog-site-token")
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default()
        .to_string();
    let Some(session) = site_session_of(&state, &headers).await else {
        return Json(json!({"success": false, "message": "未登录"}));
    };
    if !token.is_empty() {
        let mut sessions = state.site_sessions.write().await;
        if let Some(item) = sessions.get_mut(&token) {
            item.last_seen = now_string();
        }
    }
    Json(json!({
        "success": true,
        "user": {
            "id": session.vrchat_id,
            "displayName": session.display_name,
            "avatar": session.avatar
        }
    }))
}

async fn site_logout(State(state): State<AppState>, headers: HeaderMap) -> Json<Value> {
    if let Some(token) = headers
        .get("x-vrcdog-site-token")
        .and_then(|value| value.to_str().ok())
    {
        state.site_sessions.write().await.remove(token);
    }
    Json(json!({"success": true}))
}

// ---------- 官网：反馈 / 改模定制 ----------

#[derive(Deserialize)]
struct InquiryUploadQuery {
    #[serde(default)]
    file_name: Option<String>,
    #[serde(default)]
    kind: Option<String>,
}

async fn site_inquiry_upload(
    State(state): State<AppState>,
    headers: HeaderMap,
    Query(params): Query<InquiryUploadQuery>,
    body: Bytes,
) -> Response {
    if site_session_of(&state, &headers).await.is_none() {
        return (StatusCode::UNAUTHORIZED, "请先登录 VRChat 账号").into_response();
    }
    if body.is_empty() {
        return (StatusCode::BAD_REQUEST, "empty file").into_response();
    }
    const MAX_INQUIRY_BYTES: u64 = 200 * 1024 * 1024;
    if body.len() as u64 > MAX_INQUIRY_BYTES {
        return (
            StatusCode::PAYLOAD_TOO_LARGE,
            "单个文件不能超过 200 MiB".to_string(),
        )
            .into_response();
    }
    let uploads = uploads_dir(&state).join("inquiries");
    if let Err(error) = std::fs::create_dir_all(&uploads) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to create uploads dir: {error}"),
        )
            .into_response();
    }
    // 反复上传可以把磁盘灌满，这里给附件目录一个总配额。
    const MAX_INQUIRY_TOTAL_BYTES: u64 = 5 * 1024 * 1024 * 1024;
    let dir = uploads.clone();
    let used = tokio::task::spawn_blocking(move || dir_total_bytes(&dir))
        .await
        .unwrap_or(0);
    if used.saturating_add(body.len() as u64) > MAX_INQUIRY_TOTAL_BYTES {
        return (
            StatusCode::INSUFFICIENT_STORAGE,
            "附件空间已满，请稍后再试或联系管理员清理",
        )
            .into_response();
    }
    let mime = headers
        .get(CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("application/octet-stream")
        .to_string();
    let ext = extension_for(&mime, params.file_name.as_deref());
    let mut hasher = Sha256::new();
    hasher.update(now_string().as_bytes());
    hasher.update(UPLOAD_SEQ.fetch_add(1, Ordering::Relaxed).to_le_bytes());
    hasher.update(&body);
    let file_id = to_hex(&hasher.finalize());
    let stored_name = format!("{file_id}.{ext}");
    if let Err(error) = std::fs::write(uploads.join(&stored_name), &body) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to write file: {error}"),
        )
            .into_response();
    }
    Json(json!({
        "success": true,
        "file": {
            "id": stored_name,
            "name": params.file_name.clone().unwrap_or_else(|| stored_name.clone()),
            "mime": mime,
            "size": body.len(),
            "kind": params.kind.clone().unwrap_or_else(|| "file".to_string())
        }
    }))
    .into_response()
}

/// 附件回读：文件名是内容 SHA-256，不可枚举；不额外要求 token，
/// 这样前端可以直接把它塞进 <img src> / <video src>。
async fn site_inquiry_file(
    State(state): State<AppState>,
    Path(file_name): Path<String>,
) -> Response {
    serve_upload(uploads_dir(&state).join("inquiries"), &file_name).await
}

/// 统一的附件回读：严格校验文件名、禁止 SVG/HTML 内联执行、加缓存与 nosniff。
async fn serve_upload(dir: std::path::PathBuf, file_name: &str) -> Response {
    if !is_upload_name(file_name) {
        return (StatusCode::NOT_FOUND, "file not found").into_response();
    }
    let path = dir.join(file_name);
    match tokio::fs::read(&path).await {
        Ok(bytes) => {
            let ext = file_name
                .rsplit_once('.')
                .map(|(_, ext)| ext.to_ascii_lowercase())
                .unwrap_or_default();
            let mut response = (StatusCode::OK, bytes).into_response();
            let headers = response.headers_mut();
            // SVG / HTML 放在同源页面里内联渲染会执行脚本，一律改成附件下载。
            if matches!(ext.as_str(), "svg" | "html" | "htm" | "xml") {
                headers.insert(
                    CONTENT_TYPE,
                    HeaderValue::from_static("application/octet-stream"),
                );
                if let Ok(value) = HeaderValue::from_str(&format!("attachment; filename=\"{file_name}\"")) {
                    headers.insert(CONTENT_DISPOSITION, value);
                }
            } else if let Ok(mime) = HeaderValue::from_str(mime_for(file_name)) {
                headers.insert(CONTENT_TYPE, mime);
            }
            headers.insert(X_CONTENT_TYPE_OPTIONS, HeaderValue::from_static("nosniff"));
            headers.insert(
                CACHE_CONTROL,
                HeaderValue::from_static("public, max-age=604800, immutable"),
            );
            response
        }
        Err(_) => (StatusCode::NOT_FOUND, "file not found").into_response(),
    }
}

/// 管理端上传官网素材（站点图标、Logo、首屏图、区块配图）。
/// 与反馈附件分开存放在 `uploads/site`，不受附件保留天数清理影响。
async fn admin_site_asset_upload(
    State(state): State<AppState>,
    Query(params): Query<InquiryUploadQuery>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    if body.is_empty() {
        return (StatusCode::BAD_REQUEST, "empty file").into_response();
    }
    const MAX_SITE_ASSET_BYTES: u64 = 8 * 1024 * 1024;
    if body.len() as u64 > MAX_SITE_ASSET_BYTES {
        return (
            StatusCode::PAYLOAD_TOO_LARGE,
            "站点图片不能超过 8 MiB".to_string(),
        )
            .into_response();
    }
    let mime = headers
        .get(CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("application/octet-stream")
        .to_string();
    if !mime.starts_with("image/") {
        return (
            StatusCode::UNSUPPORTED_MEDIA_TYPE,
            "站点素材只接受图片文件".to_string(),
        )
            .into_response();
    }
    let dir = uploads_dir(&state).join("site");
    if let Err(error) = std::fs::create_dir_all(&dir) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to create uploads dir: {error}"),
        )
            .into_response();
    }
    let ext = extension_for(&mime, params.file_name.as_deref());
    let mut hasher = Sha256::new();
    hasher.update(now_string().as_bytes());
    hasher.update(UPLOAD_SEQ.fetch_add(1, Ordering::Relaxed).to_le_bytes());
    hasher.update(b"site-asset");
    hasher.update(&body);
    let stored_name = format!("{}.{ext}", to_hex(&hasher.finalize()));
    if let Err(error) = std::fs::write(dir.join(&stored_name), &body) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to write file: {error}"),
        )
            .into_response();
    }
    Json(json!({
        "success": true,
        "file": {
            "id": stored_name,
            "name": params.file_name.clone().unwrap_or_else(|| stored_name.clone()),
            "mime": mime,
            "size": body.len(),
            "url": format!("/api/site/asset/{stored_name}")
        }
    }))
    .into_response()
}

async fn site_asset_file(
    State(state): State<AppState>,
    Path(file_name): Path<String>,
) -> Response {
    serve_upload(uploads_dir(&state).join("site"), &file_name).await
}

#[derive(Deserialize)]
struct InquirySubmitRequest {
    #[serde(default)]
    kind: String,
    #[serde(default)]
    title: String,
    #[serde(default)]
    content: String,
    #[serde(default)]
    contact: String,
    /// 必填：管理员回复时按这个地址通知用户。
    #[serde(default)]
    email: String,
    #[serde(default)]
    files: Vec<InquiryFile>,
}

async fn site_inquiry_submit(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(request): Json<InquirySubmitRequest>,
) -> Json<Value> {
    let Some(session) = site_session_of(&state, &headers).await else {
        return Json(json!({"success": false, "message": "请先登录 VRChat 账号"}));
    };
    if !inquiry_submit_gate(&session.vrchat_id) {
        return Json(json!({
            "success": false,
            "message": "提交太频繁了，一小时最多 5 条，稍后再试"
        }));
    }
    let content = request.content.trim().to_string();
    let count = content.chars().count();
    if count < 5 {
        return Json(json!({"success": false, "message": "请把问题或需求写得更具体一点"}));
    }
    if count > 5000 {
        return Json(json!({"success": false, "message": "内容不能超过 5000 字"}));
    }
    let kind = match request.kind.trim() {
        "commission" => "commission",
        "suggestion" => "suggestion",
        _ => "bug",
    }
    .to_string();
    let title = {
        let trimmed = request.title.trim().to_string();
        if trimmed.is_empty() {
            content.chars().take(40).collect::<String>()
        } else {
            trimmed.chars().take(120).collect::<String>()
        }
    };
    let mut files = request.files;
    // 只接受本服务落盘的文件名，挡住 ../ 之类的伪造附件引用。
    files.retain(|file| is_upload_name(&file.id));
    if files.len() > 10 {
        files.truncate(10);
    }
    let email = request.email.trim().to_string();
    if email.is_empty() {
        return Json(json!({"success": false, "message": "请填写邮箱，方便我们回复你"}));
    }
    if !is_valid_email(&email) {
        return Json(json!({"success": false, "message": "邮箱格式看起来不对，请检查一下"}));
    }
    let record = Inquiry {
        id: hex::encode(rand::random::<[u8; 12]>()),
        kind,
        status: "open".to_string(),
        title,
        content,
        contact: request.contact.trim().chars().take(120).collect(),
        email: email.clone(),
        files,
        vrchat_id: session.vrchat_id.clone(),
        vrchat_name: session.display_name.clone(),
        avatar: session.avatar.clone(),
        created_at: now_string(),
        reply: String::new(),
        reply_files: Vec::new(),
        replied_at: String::new(),
        updated_at: String::new(),
    };
    let id = record.id.clone();
    let snapshot = record.clone();
    {
        let mut data = state.data.write().await;
        if let Some(user) = data.site_users.get_mut(&session.vrchat_id) {
            if user.email.is_empty() {
                user.email = email;
            }
        }
        data.inquiries.push(record);
        if data.inquiries.len() > 5000 {
            let overflow = data.inquiries.len() - 5000;
            data.inquiries.drain(0..overflow);
        }
    }
    schedule_persist(&state);
    // 邮件通知走后台任务，SMTP 慢或失败都不影响用户提交结果。
    notify_admin_new_inquiry(state.clone(), snapshot);
    Json(json!({"success": true, "id": id}))
}

/// 粗暴但够用的邮箱格式校验：本地部分 + @ + 带点的域名。
fn is_valid_email(value: &str) -> bool {
    let trimmed = value.trim();
    if trimmed.len() < 6 || trimmed.len() > 120 || trimmed.contains(char::is_whitespace) {
        return false;
    }
    let mut parts = trimmed.split('@');
    let (Some(local), Some(domain), None) = (parts.next(), parts.next(), parts.next()) else {
        return false;
    };
    !local.is_empty()
        && domain.contains('.')
        && !domain.starts_with('.')
        && !domain.ends_with('.')
        && domain.chars().all(|c| c.is_ascii_alphanumeric() || c == '.' || c == '-')
}

async fn site_inquiry_mine(State(state): State<AppState>, headers: HeaderMap) -> Json<Value> {
    let Some(session) = site_session_of(&state, &headers).await else {
        return Json(json!({"success": false, "message": "请先登录 VRChat 账号"}));
    };
    let items: Vec<Value> = {
        let data = state.data.read().await;
        data.inquiries
            .iter()
            .filter(|item| item.vrchat_id == session.vrchat_id)
            .rev()
            .take(50)
            .map(|item| json!(item))
            .collect()
    };
    Json(json!({"success": true, "items": items}))
}

async fn admin_inquiries(State(state): State<AppState>) -> Json<Value> {
    let items: Vec<Value> = {
        let data = state.data.read().await;
        data.inquiries
            .iter()
            .rev()
            .take(200)
            .map(|item| json!(item))
            .collect()
    };
    Json(json!({"success": true, "total": items.len(), "items": items}))
}

#[derive(Deserialize)]
struct InquiryUpdateRequest {
    id: String,
    #[serde(default)]
    status: Option<String>,
    #[serde(default)]
    reply: Option<String>,
    /// 回复附件（图片 / 视频 / 文件），最多 10 个。
    #[serde(default)]
    reply_files: Option<Vec<InquiryFile>>,
    /// 勾选后把回复邮件发给提交人。
    #[serde(default)]
    notify_user: bool,
}

async fn admin_inquiry_update(
    State(state): State<AppState>,
    Json(request): Json<InquiryUpdateRequest>,
) -> Json<Value> {
    let snapshot;
    let notify: bool;
    {
        let mut data = state.data.write().await;
        let Some(item) = data.inquiries.iter_mut().find(|item| item.id == request.id) else {
            return Json(json!({"success": false, "message": "没有找到这条记录"}));
        };
        let mut content_changed = false;
        if let Some(status) = request.status {
            item.status = match status.as_str() {
                "processing" => "processing",
                "closed" => "closed",
                _ => "open",
            }
            .to_string();
            content_changed = true;
        }
        if let Some(reply) = request.reply {
            let trimmed: String = reply.trim().chars().take(8000).collect();
            if trimmed != item.reply {
                item.reply = trimmed;
                content_changed = true;
            }
        }
        if let Some(files) = request.reply_files {
            let mut kept: Vec<InquiryFile> = files
                .into_iter()
                .filter(|file| is_upload_name(&file.id))
                .collect();
            if kept.len() > 10 {
                kept.truncate(10);
            }
            item.reply_files = kept;
            content_changed = true;
        }
        if content_changed {
            item.replied_at = now_string();
        }
        item.updated_at = now_string();
        snapshot = item.clone();
        notify = request.notify_user && !snapshot.reply.is_empty() && !snapshot.email.is_empty();
    }
    schedule_persist(&state);
    if notify {
        notify_user_reply(state.clone(), snapshot);
    }
    Json(json!({"success": true, "notified": notify}))
}

// ---------- 邮件通知 ----------

fn escape_html(input: &str) -> String {
    input
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

async fn mail_settings_snapshot(state: &AppState) -> MailSettings {
    state.data.read().await.mail.clone()
}

/// 统一的邮件卡片外壳：方角、细边框、橙色只做点缀，与官网/管理台同一套视觉。
fn mail_shell(
    title: &str,
    body_html: &str,
    site_url: &str,
    action_label: &str,
    action_path: &str,
) -> String {
    let site = site_url.trim_end_matches('/');
    let host = site
        .trim_start_matches("https://")
        .trim_start_matches("http://")
        .trim_end_matches('/')
        .to_string();
    format!(
        r#"<!doctype html><html lang="zh-CN"><body style="margin:0;padding:0;background:#f4f5f7;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:32px 16px;">
<tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border:1px solid #e4e7ec;border-radius:2px;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;">
<tr><td style="padding:16px 26px;border-bottom:1px solid #eef0f3;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
<td style="font-size:12px;font-weight:700;letter-spacing:.14em;color:#e07a1f;text-transform:uppercase;">VrcDog</td>
<td align="right" style="font-size:11px;color:#98a2b3;letter-spacing:.02em;">{host}</td>
</tr></table>
</td></tr>
<tr><td style="padding:24px 26px 0;">
<div style="font-size:16px;font-weight:700;color:#16181d;letter-spacing:.01em;line-height:1.4;">{title}</div>
</td></tr>
<tr><td style="padding:12px 26px 24px;color:#4a4f58;font-size:13px;line-height:1.8;">{body}</td></tr>
<tr><td style="padding:0 26px 26px;">
<a href="{site}{path}" style="display:inline-block;background:#e07a1f;color:#ffffff;text-decoration:none;font-size:13px;font-weight:600;padding:11px 20px;border-radius:2px;">{label}</a>
</td></tr>
<tr><td style="padding:13px 26px;background:#fafbfc;border-top:1px solid #eef0f3;color:#98a2b3;font-size:11px;line-height:1.65;">
这封邮件由 VrcDog 官网通知系统自动发送。不想再收到，可在管理台「邮件通知」里关闭。
</td></tr>
</table></td></tr></table></body></html>"#,
        host = escape_html(&host),
        title = escape_html(title),
        body = body_html,
        site = site,
        path = action_path,
        label = escape_html(action_label)
    )
}

/// SMTP 发信：在阻塞线程池里跑，超时 20 秒，失败只记日志不打断业务。
async fn send_mail(
    state: &AppState,
    to: &str,
    subject: &str,
    html: String,
) -> Result<(), String> {
    let settings = mail_settings_snapshot(state).await;
    if !settings.enabled {
        return Err("邮件通知未开启".to_string());
    }
    let to = to.trim().to_string();
    if !is_valid_email(&to) {
        return Err("收件邮箱无效".to_string());
    }
    if settings.smtp_host.trim().is_empty() || settings.from_address.trim().is_empty() {
        return Err("SMTP 服务器或发件地址还没配".to_string());
    }
    let host = settings.smtp_host.trim().to_string();
    let port = settings.smtp_port;
    let user = settings.smtp_username.trim().to_string();
    let pass = settings.smtp_password.clone();
    let from_address = settings.from_address.trim().to_string();
    let from_name = settings.from_name.trim().to_string();
    let implicit = settings.implicit_tls;
    let subject = subject.to_string();

    tokio::task::spawn_blocking(move || -> Result<(), String> {
        use lettre::message::{header::ContentType, Mailbox};
        use lettre::transport::smtp::authentication::Credentials;
        use lettre::{Message, SmtpTransport, Transport};

        let from: lettre::Address = from_address
            .parse()
            .map_err(|_| "发件地址格式不正确".to_string())?;
        let target: lettre::Address = to
            .parse()
            .map_err(|_| "收件地址格式不正确".to_string())?;
        let message = Message::builder()
            .from(Mailbox::new(Some(from_name), from))
            .to(Mailbox::new(None, target))
            .subject(subject)
            .header(ContentType::TEXT_HTML)
            .body(html)
            .map_err(|error| error.to_string())?;

        let builder = if implicit {
            SmtpTransport::relay(&host).map_err(|error| error.to_string())?
        } else {
            SmtpTransport::starttls_relay(&host).map_err(|error| error.to_string())?
        };
        let builder = builder
            .port(port)
            .timeout(Some(std::time::Duration::from_secs(20)));
        let transport = if user.is_empty() {
            builder.build()
        } else {
            builder.credentials(Credentials::new(user, pass)).build()
        };
        transport
            .send(&message)
            .map(|_| ())
            .map_err(|error| error.to_string())
    })
    .await
    .map_err(|error| error.to_string())?
}

fn inquiry_kind_label(kind: &str) -> &'static str {
    match kind {
        "commission" => "改模定制申请",
        "suggestion" => "新建议",
        _ => "BUG 反馈",
    }
}

fn inquiry_status_label(status: &str) -> &'static str {
    match status {
        "processing" => "处理中",
        "closed" => "已结束",
        _ => "待处理",
    }
}

/// 新反馈 → 提醒管理员。失败只打日志。
fn notify_admin_new_inquiry(state: AppState, inquiry: Inquiry) {
    tokio::spawn(async move {
        let settings = mail_settings_snapshot(&state).await;
        let to = settings.admin_address.trim().to_string();
        if to.is_empty() {
            return;
        }
        let site = settings.site_url.clone();
        let label = inquiry_kind_label(&inquiry.kind);
        let attachments = inquiry.files.len();
        let summary: String = inquiry.content.chars().take(600).collect();
        let body = format!(
            r#"<p style="margin:0 0 14px;font-size:13px;color:#846251;">{who} 通过官网提交了一条{label}。</p>
<div style="background:#fbf6ee;border:1px solid #eee1cf;border-radius:12px;padding:16px;">
<div style="font-size:14px;font-weight:800;color:#3b2a1e;margin-bottom:8px;">{title}</div>
<div style="white-space:pre-wrap;font-size:12.5px;color:#5b4636;">{summary}</div>
</div>
<table role="presentation" style="margin-top:14px;font-size:11.5px;color:#846251;" cellpadding="0" cellspacing="0">
<tr><td style="padding:2px 0;">提交人：<b style="color:#3b2a1e;">{name}</b>（{vid}）</td></tr>
<tr><td style="padding:2px 0;">邮箱：{email}</td></tr>
<tr><td style="padding:2px 0;">时间：{created}</td></tr>
<tr><td style="padding:2px 0;">附件：{files} 个</td></tr>
</table>"#,
            who = if inquiry.vrchat_name.is_empty() {
                "一位访客".to_string()
            } else {
                format!("VRChat 用户 {}", escape_html(&inquiry.vrchat_name))
            },
            label = label,
            title = escape_html(&inquiry.title),
            summary = escape_html(&summary),
            name = escape_html(&inquiry.vrchat_name),
            vid = escape_html(&inquiry.vrchat_id),
            email = escape_html(&inquiry.email),
            created = escape_html(&inquiry.created_at),
            files = attachments
        );
        let subject = format!("【VrcDog】{} · {}", label, inquiry.title);
        let html = mail_shell(&format!("{}提醒", label), &body, &site, "去后台处理", "/admin");
        if let Err(error) = send_mail(&state, &to, &subject, html).await {
            tracing::warn!("[mail] 管理员提醒发送失败: {error}");
        }
    });
}

/// 管理员回复 → 可选通知用户。邮件里带回复正文与附件链接。
fn notify_user_reply(state: AppState, inquiry: Inquiry) {
    tokio::spawn(async move {
        if inquiry.email.is_empty() {
            return;
        }
        let settings = mail_settings_snapshot(&state).await;
        let site = settings.site_url.clone();
        let label = inquiry_kind_label(&inquiry.kind);
        let reply = escape_html(&inquiry.reply);
        let mut attachment_html = String::new();
        if !inquiry.reply_files.is_empty() {
            let mut rows = String::new();
            for file in &inquiry.reply_files {
                let link = format!(
                    "{}/api/site/inquiry/files/{}",
                    site.trim_end_matches('/'),
                    file.id
                );
                rows.push_str(&format!(
                    r#"<li style="margin:4px 0;"><a href="{link}" style="color:#c4631a;">{name}</a> <span style="color:#9a8271;">（{kind}）</span></li>"#,
                    link = escape_html(&link),
                    name = escape_html(&file.name),
                    kind = escape_html(&file.kind)
                ));
            }
            attachment_html = format!(
                r#"<div style="margin-top:14px;"><div style="font-size:11.5px;font-weight:700;color:#3b2a1e;margin-bottom:4px;">回复附件</div><ul style="margin:0;padding-left:18px;font-size:11.5px;">{rows}</ul></div>"#
            );
        }
        let body = format!(
            r#"<p style="margin:0 0 14px;font-size:13px;color:#846251;">你对「{title}」的回复已经发出，状态：{status}。</p>
<div style="background:#fbf6ee;border-left:3px solid #e6812f;border-radius:10px;padding:16px;white-space:pre-wrap;font-size:13px;color:#3b2a1e;">{reply}</div>
{attachment_html}
<p style="margin:16px 0 0;font-size:11.5px;color:#846251;">页面里还能看到你当初提交的附件和完整往来记录。</p>"#,
            title = escape_html(&inquiry.title),
            status = inquiry_status_label(&inquiry.status),
            reply = reply,
            attachment_html = attachment_html
        );
        let subject = format!("【VrcDog】{}有了回复 · {}", label, inquiry.title);
        let html = mail_shell("你的反馈有回复了", &body, &site, "查看完整回复", "/feedback");
        if let Err(error) = send_mail(&state, &inquiry.email, &subject, html).await {
            tracing::warn!("[mail] 用户回复通知发送失败: {error}");
        }
    });
}

// ---------- 官网访客统计 ----------

fn header_text(headers: &HeaderMap, name: &str) -> String {
    headers
        .get(name)
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default()
        .to_string()
}

fn client_ip(headers: &HeaderMap) -> String {
    if let Some(value) = headers.get("x-forwarded-for").and_then(|v| v.to_str().ok()) {
        if let Some(first) = value.split(',').next() {
            let trimmed = first.trim();
            if !trimmed.is_empty() {
                return trimmed.to_string();
            }
        }
    }
    let real = header_text(headers, "x-real-ip");
    if !real.trim().is_empty() {
        return real.trim().to_string();
    }
    "unknown".to_string()
}

/// 只给管理员看脱敏后的 IP：1.2.3.4 → 1.2.3.*
fn mask_ip(ip: &str) -> String {
    if ip.is_empty() || ip == "unknown" {
        return "未知".to_string();
    }
    match ip.rsplit_once('.') {
        Some((head, _)) => format!("{head}.*"),
        None => ip.to_string(),
    }
}

fn minutes_ago(minutes: i64) -> String {
    (chrono::Local::now().naive_local() - chrono::Duration::minutes(minutes))
        .format("%Y-%m-%d %H:%M:%S")
        .to_string()
}

fn hours_ago(hours: i64) -> String {
    (chrono::Local::now().naive_local() - chrono::Duration::hours(hours))
        .format("%Y-%m-%d %H:%M:%S")
        .to_string()
}

#[derive(Deserialize)]
struct VisitRequest {
    #[serde(default)]
    path: String,
}

/// 公开打点：前端每次进站调用一次，回传 visitor token 供下次复用。
async fn site_visit(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(request): Json<VisitRequest>,
) -> Json<Value> {
    let incoming = header_text(&headers, "x-vrcdog-visitor");
    let id = if incoming.trim().is_empty() || incoming.len() > 64 {
        hex::encode(rand::random::<[u8; 8]>())
    } else {
        incoming.trim().to_string()
    };
    let ip = client_ip(&headers);
    let ua: String = header_text(&headers, "user-agent").chars().take(180).collect();
    let path: String = request
        .path
        .trim()
        .chars()
        .take(120)
        .collect::<String>();
    let path = if path.is_empty() {
        "/".to_string()
    } else {
        path
    };
    let now = now_string();
    let cutoff = hours_ago(24);
    {
        let mut data = state.data.write().await;
        data.site_visitors
            .retain(|_, visitor| visitor.last_seen.as_str() > cutoff.as_str());
        match data.site_visitors.get_mut(&id) {
            Some(visitor) => {
                visitor.last_seen = now;
                visitor.path = path;
                if !ip.is_empty() && ip != "unknown" {
                    visitor.ip = ip;
                }
            }
            None => {
                // 访客 ID 由前端自由提供，不设上限会被刷爆内存和 state 文件。
                if data.site_visitors.len() >= 5000 {
                    let mut oldest: Vec<(String, String)> = data
                        .site_visitors
                        .iter()
                        .map(|(key, visitor)| (key.clone(), visitor.last_seen.clone()))
                        .collect();
                    oldest.sort_by(|a, b| a.1.cmp(&b.1));
                    for (key, _) in oldest.into_iter().take(1500) {
                        data.site_visitors.remove(&key);
                    }
                }
                data.site_visitors.insert(
                    id.clone(),
                    SiteVisitor {
                        id: id.clone(),
                        ip,
                        ua,
                        path,
                        first_seen: now.clone(),
                        last_seen: now,
                        vrchat_id: String::new(),
                        display_name: String::new(),
                    },
                );
            }
        }
    }
    schedule_persist(&state);
    Json(json!({"success": true, "id": id}))
}

async fn admin_site_visitors(State(state): State<AppState>) -> Json<Value> {
    let (online, today, total, mut list) = {
        let data = state.data.read().await;
        let five_minutes = minutes_ago(5);
        let today_prefix = now_string().chars().take(10).collect::<String>();
        let online = data
            .site_visitors
            .values()
            .filter(|item| item.last_seen.as_str() >= five_minutes.as_str())
            .count();
        let today = data
            .site_visitors
            .values()
            .filter(|item| {
                item.first_seen.starts_with(&today_prefix)
                    || item.last_seen.starts_with(&today_prefix)
            })
            .count();
        let total = data.site_visitors.len();
        let mut list: Vec<SiteVisitor> = data.site_visitors.values().cloned().collect();
        list.sort_by(|left, right| right.last_seen.cmp(&left.last_seen));
        (online, today, total, list)
    };
    let five_minutes = minutes_ago(5);
    let logged_in_online = {
        let sessions = state.site_sessions.read().await;
        sessions
            .values()
            .filter(|session| session.last_seen.as_str() >= five_minutes.as_str())
            .count()
    };
    let items: Vec<Value> = list
        .drain(..)
        .take(60)
        .map(|visitor| {
            json!({
                "id": visitor.id,
                "ip": mask_ip(&visitor.ip),
                "ua": visitor.ua,
                "path": visitor.path,
                "first_seen": visitor.first_seen,
                "last_seen": visitor.last_seen,
                "online": visitor.last_seen.as_str() >= five_minutes.as_str(),
                "vrchat_id": visitor.vrchat_id,
                "display_name": visitor.display_name,
            })
        })
        .collect();
    Json(json!({
        "success": true,
        "online": online,
        "logged_in_online": logged_in_online,
        "today": today,
        "total": total,
        "items": items,
    }))
}

async fn admin_site_users(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    let five_minutes = minutes_ago(5);
    let mut counts: HashMap<String, u64> = HashMap::new();
    for inquiry in data.inquiries.iter() {
        *counts.entry(inquiry.vrchat_id.clone()).or_insert(0) += 1;
    }
    let mut list: Vec<SiteUserRecord> = data.site_users.values().cloned().collect();
    list.sort_by(|left, right| right.last_seen.cmp(&left.last_seen));
    let online = list
        .iter()
        .filter(|user| user.last_seen.as_str() >= five_minutes.as_str())
        .count();
    let items: Vec<Value> = list
        .iter()
        .map(|user| {
            json!({
                "vrchat_id": user.vrchat_id,
                "display_name": user.display_name,
                "avatar": user.avatar,
                "first_seen": user.first_seen,
                "last_seen": user.last_seen,
                "login_count": user.login_count,
                "email": user.email,
                "inquiry_count": counts.get(&user.vrchat_id).copied().unwrap_or(0),
                "online": user.last_seen.as_str() >= five_minutes.as_str(),
            })
        })
        .collect();
    Json(json!({
        "success": true,
        "total": list.len(),
        "online": online,
        "items": items,
    }))
}

// ---------- 反馈 CRUD 补全 ----------

#[derive(Deserialize)]
struct InquiryIdRequest {
    id: String,
}

async fn admin_inquiry_delete(
    State(state): State<AppState>,
    Json(request): Json<InquiryIdRequest>,
) -> Json<Value> {
    let removed = {
        let mut data = state.data.write().await;
        match data
            .inquiries
            .iter()
            .position(|item| item.id == request.id)
        {
            Some(position) => Some(data.inquiries.remove(position)),
            None => None,
        }
    };
    let Some(item) = removed else {
        return Json(json!({"success": false, "message": "没有找到这条记录"}));
    };
    let directory = uploads_dir(&state).join("inquiries");
    for file in item.files.iter().chain(item.reply_files.iter()) {
        // file.id 是客户端提交的，删除前必须确认它是我们自己的落盘名，
        // 否则 `../server-state.json` 这种伪装 id 会把数据库删掉。
        if is_upload_name(&file.id) {
            let _ = tokio::fs::remove_file(directory.join(&file.id)).await;
        }
    }
    schedule_persist(&state);
    Json(json!({"success": true, "message": "已删除这条反馈"}))
}

/// 管理端上传回复附件：和用户上传共用同一个存储目录与命名规则。
async fn admin_inquiry_upload(
    State(state): State<AppState>,
    Query(params): Query<InquiryUploadQuery>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    if body.is_empty() {
        return (StatusCode::BAD_REQUEST, "empty file").into_response();
    }
    const MAX_INQUIRY_BYTES: u64 = 200 * 1024 * 1024;
    if body.len() as u64 > MAX_INQUIRY_BYTES {
        return (
            StatusCode::PAYLOAD_TOO_LARGE,
            "单个文件不能超过 200 MiB".to_string(),
        )
            .into_response();
    }
    let uploads = uploads_dir(&state).join("inquiries");
    if let Err(error) = std::fs::create_dir_all(&uploads) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to create uploads dir: {error}"),
        )
            .into_response();
    }
    // 反复上传可以把磁盘灌满，这里给附件目录一个总配额。
    const MAX_INQUIRY_TOTAL_BYTES: u64 = 5 * 1024 * 1024 * 1024;
    let dir = uploads.clone();
    let used = tokio::task::spawn_blocking(move || dir_total_bytes(&dir))
        .await
        .unwrap_or(0);
    if used.saturating_add(body.len() as u64) > MAX_INQUIRY_TOTAL_BYTES {
        return (
            StatusCode::INSUFFICIENT_STORAGE,
            "附件空间已满，请稍后再试或联系管理员清理",
        )
            .into_response();
    }
    let mime = headers
        .get(CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("application/octet-stream")
        .to_string();
    let ext = extension_for(&mime, params.file_name.as_deref());
    let mut hasher = Sha256::new();
    hasher.update(now_string().as_bytes());
    hasher.update(UPLOAD_SEQ.fetch_add(1, Ordering::Relaxed).to_le_bytes());
    hasher.update(b"admin-reply");
    hasher.update(&body);
    let file_id = to_hex(&hasher.finalize());
    let stored_name = format!("{file_id}.{ext}");
    if let Err(error) = std::fs::write(uploads.join(&stored_name), &body) {
        return (
            StatusCode::INTERNAL_SERVER_ERROR,
            format!("failed to write file: {error}"),
        )
            .into_response();
    }
    Json(json!({
        "success": true,
        "file": {
            "id": stored_name,
            "name": params.file_name.clone().unwrap_or_else(|| stored_name.clone()),
            "mime": mime,
            "size": body.len(),
            "kind": params.kind.clone().unwrap_or_else(|| "file".to_string())
        }
    }))
    .into_response()
}

// ---------- 邮件设置 ----------

async fn admin_mail_settings_get(State(state): State<AppState>) -> Json<Value> {
    let settings = state.data.read().await.mail.clone();
    Json(json!({
        "success": true,
        "settings": {
            "enabled": settings.enabled,
            "smtp_host": settings.smtp_host,
            "smtp_port": settings.smtp_port,
            "smtp_username": settings.smtp_username,
            "from_address": settings.from_address,
            "from_name": settings.from_name,
            "admin_address": settings.admin_address,
            "implicit_tls": settings.implicit_tls,
            "notify_user_default": settings.notify_user_default,
            "site_url": settings.site_url,
            "password_set": !settings.smtp_password.is_empty(),
        }
    }))
}

async fn admin_mail_settings_save(
    State(state): State<AppState>,
    Json(mut settings): Json<MailSettings>,
) -> Json<Value> {
    if settings.site_url.trim().is_empty() {
        settings.site_url = default_site_url();
    }
    if settings.smtp_port == 0 {
        settings.smtp_port = 465;
    }
    let password_updated;
    {
        let mut data = state.data.write().await;
        password_updated = !settings.smtp_password.is_empty();
        if settings.smtp_password.trim().is_empty() {
            settings.smtp_password = data.mail.smtp_password.clone();
        }
        data.mail = settings;
    }
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "message": "邮件设置已保存",
        "password_updated": password_updated
    }))
}

#[derive(Deserialize)]
struct MailTestRequest {
    #[serde(default)]
    to: String,
}

async fn admin_mail_test(
    State(state): State<AppState>,
    Json(request): Json<MailTestRequest>,
) -> Json<Value> {
    let settings = mail_settings_snapshot(&state).await;
    let to = if request.to.trim().is_empty() {
        settings.admin_address.trim().to_string()
    } else {
        request.to.trim().to_string()
    };
    if to.is_empty() {
        return Json(json!({"success": false, "message": "请先填写收件地址或管理员邮箱"}));
    }
    let body = r#"<p style="margin:0 0 12px;">这是一封测试邮件。收到它说明 SMTP 配置可用，之后新反馈会自动发到这个邮箱。</p>"#;
    let html = mail_shell("邮件通知测试", body, &settings.site_url, "去管理台", "/admin");
    match send_mail(&state, &to, "【VrcDog】邮件通知测试", html).await {
        Ok(()) => Json(json!({"success": true, "message": format!("测试邮件已发送至 {to}")})),
        Err(error) => Json(json!({"success": false, "message": format!("发送失败：{error}")})),
    }
}

// ---------- VRChat API 代理 ----------

#[derive(Deserialize)]
struct VrchatProxyQuery {
    path: String,
}

async fn require_admin_session(
    State(state): State<AppState>,
    request: axum::extract::Request,
    next: axum::middleware::Next,
) -> Result<axum::response::Response, StatusCode> {
    let token = request
        .headers()
        .get("x-vrcdog-admin-token")
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default();
    let sessions = state.admin_sessions.read().await;
    if !sessions.contains_key(token) {
        return Err(StatusCode::UNAUTHORIZED);
    }
    drop(sessions);
    Ok(next.run(request).await)
}

/// L2: 校验 client token，将验证通过的 user_id 注入 request extensions
async fn require_client_token(
    State(state): State<AppState>,
    mut request: axum::extract::Request,
    next: axum::middleware::Next,
) -> Result<axum::response::Response, StatusCode> {
    let token = request
        .headers()
        .get("x-vrcdog-client-token")
        .and_then(|value| value.to_str().ok())
        .unwrap_or_default();
    let clients = state.clients.read().await;
    let verified_user_id = clients
        .values()
        .find(|c| c.client_token == token)
        .map(|c| c.user_id.clone());
    drop(clients);
    let Some(user_id) = verified_user_id else {
        return Err(StatusCode::UNAUTHORIZED);
    };
    request.extensions_mut().insert(user_id);
    Ok(next.run(request).await)
}

/// 校验已验证的 user_id 与请求中声明的 user_id 一致（所有权 / 越权防护）
fn assert_client_owner(verified: &str, claimed: &str) -> Result<(), Json<Value>> {
    if verified != claimed {
        return Err(Json(json!({
            "status": "auth_failed",
            "reason": "Client token does not match claimed user_id"
        })));
    }
    Ok(())
}

async fn vrchat_api_proxy(
    State(state): State<AppState>,
    method: Method,
    Query(params): Query<VrchatProxyQuery>,
    headers: HeaderMap,
    body: Bytes,
) -> impl IntoResponse {
    let target = format!(
        "{}/api/1/{}",
        relay_base("VRCHAT_API_BASE", "https://api.vrchat.cloud"),
        params.path.trim_start_matches('/')
    );
    let mut builder = state.http_client.request(method.clone(), &target);
    for (key, value) in headers.iter() {
        if key == "x-vrcdog-admin-token" || key == "host" || key == "connection" || key == "content-length" {
            continue;
        }
        if let Ok(v) = value.to_str() {
            builder = builder.header(key.as_str(), v);
        }
    }
    if let Some(token) = relay_token() {
        builder = builder.header("x-vrcdog-relay", token);
    }
    if method != Method::GET && method != Method::HEAD && !body.is_empty() {
        builder = builder.body(body);
    }
    match builder.send().await {
        Ok(resp) => {
            let status = StatusCode::from_u16(resp.status().as_u16()).unwrap_or(StatusCode::BAD_GATEWAY);
            let mut response_builder = Response::builder().status(status);
            for (key, value) in resp.headers().iter() {
                if key == "content-encoding" || key == "content-length" {
                    continue;
                }
                response_builder = response_builder.header(key.as_str(), value.to_str().unwrap_or(""));
            }
            match resp.bytes().await {
                Ok(body) => response_builder.body(Body::from(body)).unwrap_or_else(|_| {
                    (StatusCode::BAD_GATEWAY, "failed to build response").into_response()
                }),
                Err(_) => (StatusCode::BAD_GATEWAY, "failed to read upstream response").into_response(),
            }
        }
        Err(_) => (StatusCode::BAD_GATEWAY, "failed to reach upstream").into_response(),
    }
}

async fn admin_clients(State(state): State<AppState>) -> Json<Value> {
    let clients: Vec<ClientInfo> = state.clients.read().await.values().cloned().collect();
    Json(json!({ "clients": clients }))
}

async fn admin_users(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    let users: Vec<UserRecord> = data.users.values().cloned().collect();
    Json(json!({
        "users": users,
        "bans": data.bans,
        "frozen": data.frozen
    }))
}

async fn mark_offline(state: &AppState, user_id: &str) {
    state.clients.write().await.remove(user_id);
    if let Some(user) = state.data.write().await.users.get_mut(user_id) {
        user.is_online = false;
        user.last_seen = now_string();
    }
}

async fn admin_kick(
    State(state): State<AppState>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    let existed = state.clients.read().await.contains_key(&request.user_id);
    mark_offline(&state, &request.user_id).await;
    if existed {
        state
            .data
            .write()
            .await
            .kicked
            .insert(request.user_id.clone(), now_string());
    }
    schedule_persist(&state);
    Json(json!({
        "success": existed,
        "message": if existed { "Client kicked" } else { "Client is not online" }
    }))
}

async fn admin_ban(State(state): State<AppState>, Json(request): Json<BanRequest>) -> Json<Value> {
    let now = now_string();
    let expires_at = request.duration_hours.map(|hours| {
        (Local::now() + Duration::seconds((hours * 3600.0) as i64))
            .format("%Y-%m-%d %H:%M:%S")
            .to_string()
    });
    state.data.write().await.bans.insert(
        request.user_id.clone(),
        BanInfo {
            user_id: request.user_id.clone(),
            reason: request.reason,
            banned_at: now,
            duration_hours: request.duration_hours,
            expires_at,
        },
    );
    mark_offline(&state, &request.user_id).await;
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "User banned" }))
}

async fn admin_unban(
    State(state): State<AppState>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    let removed = state
        .data
        .write()
        .await
        .bans
        .remove(&request.user_id)
        .is_some();
    schedule_persist(&state);
    Json(json!({
        "success": removed,
        "message": if removed { "User unbanned" } else { "User was not banned" }
    }))
}

async fn admin_freeze(
    State(state): State<AppState>,
    Json(request): Json<FreezeRequest>,
) -> Json<Value> {
    state.data.write().await.frozen.insert(
        request.user_id.clone(),
        FreezeInfo {
            user_id: request.user_id.clone(),
            reason: request.reason,
            frozen_at: now_string(),
        },
    );
    mark_offline(&state, &request.user_id).await;
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "User frozen" }))
}

async fn admin_unfreeze(
    State(state): State<AppState>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    let removed = state
        .data
        .write()
        .await
        .frozen
        .remove(&request.user_id)
        .is_some();
    schedule_persist(&state);
    Json(json!({
        "success": removed,
        "message": if removed { "User unfrozen" } else { "User was not frozen" }
    }))
}

async fn admin_remove(
    State(state): State<AppState>,
    Json(request): Json<UserIdRequest>,
) -> Json<Value> {
    state.clients.write().await.remove(&request.user_id);
    let mut data = state.data.write().await;
    data.users.remove(&request.user_id);
    data.bans.remove(&request.user_id);
    data.frozen.remove(&request.user_id);
    data.kicked.remove(&request.user_id);
    // Cascade: the player's own survey submissions are the same records the client
    // shows, so removing the user must also purge their submissions.
    data.survey_submissions
        .retain(|_, submission| submission.user_id != request.user_id);
    data.survey_click_events
        .retain(|event| event.user_id != request.user_id);
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "User record removed" }))
}

async fn admin_roles(State(state): State<AppState>) -> Json<Value> {
    let mut roles: Vec<Role> = state.data.read().await.roles.values().cloned().collect();
    roles.sort_by(|left, right| left.role_name.cmp(&right.role_name));
    Json(json!({ "roles": roles }))
}

async fn admin_save_role(State(state): State<AppState>, Json(mut role): Json<Role>) -> Json<Value> {
    let mut data = state.data.write().await;
    if data.roles.is_empty() {
        role.is_default = true;
    }
    if role.is_default {
        for current in data.roles.values_mut() {
            current.is_default = false;
        }
    }
    data.roles.insert(role.role_id.clone(), role);
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "Role saved" }))
}

async fn admin_delete_role(
    State(state): State<AppState>,
    Json(request): Json<RoleIdRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    if data
        .roles
        .get(&request.role_id)
        .is_some_and(|role| role.is_default)
    {
        return Json(json!({ "success": false, "message": "Default role cannot be deleted" }));
    }
    let removed = data.roles.remove(&request.role_id).is_some();
    if removed {
        for user in data.users.values_mut() {
            if user.role_id.as_deref() == Some(request.role_id.as_str()) {
                user.role_id = None;
            }
        }
    }
    drop(data);
    schedule_persist(&state);
    Json(json!({
        "success": removed,
        "message": if removed { "Role deleted" } else { "Role not found" }
    }))
}

async fn admin_set_default_role(
    State(state): State<AppState>,
    Json(request): Json<RoleIdRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    if !data.roles.contains_key(&request.role_id) {
        return Json(json!({ "success": false, "message": "Role not found" }));
    }
    for role in data.roles.values_mut() {
        role.is_default = role.role_id == request.role_id;
    }
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "Default role updated" }))
}

async fn admin_set_user_role(
    State(state): State<AppState>,
    Json(request): Json<SetUserRoleRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    let role_exists = request
        .role_id
        .as_ref()
        .is_none_or(|role_id| data.roles.contains_key(role_id));
    if !role_exists {
        return Json(json!({ "success": false, "message": "Role not found" }));
    }
    let Some(user) = data.users.get_mut(&request.user_id) else {
        return Json(json!({ "success": false, "message": "User not found" }));
    };
    user.role_id = request.role_id;
    drop(data);
    schedule_persist(&state);
    Json(json!({ "success": true, "message": "User role updated" }))
}

async fn admin_server_settings(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!({ "settings": data.server_settings }))
}
/// 手动清理普通附件：按保留天数与总容量两条规则回收。返回删除数量与释放字节。
async fn admin_cleanup_uploads(State(state): State<AppState>) -> Json<Value> {
    let (days, max_mb) = {
        let data = state.data.read().await;
        (
            data.server_settings.upload_retention_days,
            data.server_settings.upload_max_total_mb,
        )
    };
    let dir = uploads_dir(&state);
    let mut entries: Vec<(std::path::PathBuf, u64, std::time::SystemTime)> = Vec::new();
    let mut removed = 0usize;
    let mut freed: u64 = 0;
    if let Ok(read_dir) = std::fs::read_dir(&dir) {
        for entry in read_dir.flatten() {
            let path = entry.path();
            let Ok(meta) = entry.metadata() else { continue };
            if !meta.is_file() {
                continue;
            }
            let modified = meta.modified().unwrap_or(std::time::SystemTime::UNIX_EPOCH);
            entries.push((path, meta.len(), modified));
        }
    }
    if days > 0 {
        let cutoff = std::time::SystemTime::now()
            - std::time::Duration::from_secs(days.saturating_mul(86_400));
        entries.retain(|(path, size, modified)| {
            if *modified < cutoff {
                if std::fs::remove_file(path).is_ok() {
                    removed += 1;
                    freed += *size;
                }
                false
            } else {
                true
            }
        });
    }
    if max_mb > 0 {
        let limit = max_mb.saturating_mul(1024 * 1024);
        let mut total: u64 = entries.iter().map(|(_, size, _)| *size).sum();
        if total > limit {
            entries.sort_by_key(|(_, _, modified)| *modified);
            for (path, size, _) in &entries {
                if total <= limit {
                    break;
                }
                if std::fs::remove_file(path).is_ok() {
                    removed += 1;
                    freed += *size;
                    total = total.saturating_sub(*size);
                }
            }
        }
    }
    Json(json!({
        "status": "ok",
        "removed": removed,
        "freed_bytes": freed,
        "retention_days": days,
        "max_total_mb": max_mb
    }))
}

/// 官网配置：公开读、管理员写。内容整体是 JSON，便于官网直接渲染图片/广告位。
async fn public_site_config(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!({ "config": data.site_config }))
}

async fn admin_site_config_get(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!({ "config": data.site_config }))
}

/// 官网配置里这些叶子字段最终会进 `href` / `src`，必须限定协议。
fn config_url_field(path: &str) -> bool {
    let leaf = path.rsplit('.').next().unwrap_or("");
    let name = leaf.split('[').next().unwrap_or("");
    matches!(
        name,
        "link"
            | "url"
            | "href"
            | "cta_href"
            | "image"
            | "logo"
            | "favicon"
            | "hero_image"
            | "download_url"
    )
}

fn collect_config_strings(value: &Value, path: &str, out: &mut Vec<(String, String)>) {
    match value {
        Value::Object(map) => {
            for (key, item) in map {
                let next = if path.is_empty() {
                    key.clone()
                } else {
                    format!("{path}.{key}")
                };
                collect_config_strings(item, &next, out);
            }
        }
        Value::Array(items) => {
            for (index, item) in items.iter().enumerate() {
                collect_config_strings(item, &format!("{path}[{index}]"), out);
            }
        }
        Value::String(text) => out.push((path.to_string(), text.clone())),
        _ => {}
    }
}

/// 只放行 http(s)、站内绝对路径和锚点；`javascript:`、`data:`、`//host` 都拒绝。
fn safe_link_value(value: &str) -> bool {
    let text = value.trim();
    if text.is_empty() {
        return true;
    }
    if text.starts_with("https://") || text.starts_with("http://") {
        return true;
    }
    if text.starts_with("//") || text.starts_with('\\') {
        return false;
    }
    text.starts_with('/') || text.starts_with('#')
}

async fn admin_site_config_save(
    State(state): State<AppState>,
    Json(config): Json<Value>,
) -> Response {
    if !config.is_object() {
        return (StatusCode::BAD_REQUEST, "官网配置必须是 JSON 对象").into_response();
    }
    let size = serde_json::to_vec(&config).map(|bytes| bytes.len()).unwrap_or(0);
    if size > 1_000_000 {
        return (StatusCode::BAD_REQUEST, "官网配置超过 1 MB").into_response();
    }
    let mut strings = Vec::new();
    collect_config_strings(&config, "", &mut strings);
    let bad: Vec<String> = strings
        .iter()
        .filter(|(path, value)| config_url_field(path) && !safe_link_value(value))
        .map(|(path, _)| path.clone())
        .collect();
    if !bad.is_empty() {
        return (
            StatusCode::BAD_REQUEST,
            format!(
                "以下字段只接受 http(s) 链接或站内路径：{}",
                bad.join("、")
            ),
        )
            .into_response();
    }
    state.data.write().await.site_config = config.clone();
    crate::schedule_persist(&state);
    Json(json!({ "status": "ok", "bytes": size })).into_response()
}

/// 出网受限时的离线 Release 快照。文件由 CI 或管理员从 GitHub Release 同步，
/// 保留真实 assets，避免官网下载区在服务器无外网时只剩一个版本号。
fn release_snapshot() -> Option<Value> {
    let path = env::var("VRCDOG_RELEASE_SNAPSHOT_FILE").ok()?;
    let raw = std::fs::read_to_string(path.trim()).ok()?;
    let mut value: Value = serde_json::from_str(&raw).ok()?;
    if !value.is_object() {
        return None;
    }
    value["fallback"] = Value::Bool(true);
    value["snapshot"] = Value::Bool(true);
    Some(value)
}

fn fallback_release(repo: &str) -> Value {
    if let Some(snapshot) = release_snapshot() {
        return snapshot;
    }
    json!({
        "tag_name": format!("v{}", env!("CARGO_PKG_VERSION")),
        "version": env!("CARGO_PKG_VERSION"),
        "published_at": Value::Null,
        "html_url": format!("https://github.com/{repo}/releases"),
        "assets": [],
        "fallback": true,
    })
}

/// 官网「最新版本」缓存：仓库 -> (抓取时间, 归一化后的 Release)。
static RELEASE_CACHE: OnceLock<tokio::sync::Mutex<Option<(String, Instant, Value)>>> = OnceLock::new();

/// 官网实时版本：服务端代理 GitHub Releases，10 分钟缓存，避免浏览器直连被限流。
async fn public_latest_release(State(state): State<AppState>) -> Response {
    let repo = {
        let data = state.data.read().await;
        data.site_config
            .get("release_repo")
            .and_then(Value::as_str)
            .filter(|value| !value.trim().is_empty())
            .unwrap_or("KingXiaoTaoOVO/vrcdog-releases")
            .to_string()
    };
    let valid = repo.len() <= 120
        && repo.split('/').count() == 2
        && repo
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.' | '/'));
    if !valid {
        return (StatusCode::BAD_REQUEST, "release_repo 不合法").into_response();
    }

    let cache = RELEASE_CACHE.get_or_init(|| tokio::sync::Mutex::new(None));
    let mut guard = cache.lock().await;
    if let Some((cached_repo, fetched_at, value)) = guard.as_ref() {
        if cached_repo == &repo && fetched_at.elapsed() < StdDuration::from_secs(600) {
            return Json(json!({ "release": value.clone() })).into_response();
        }
    }

    let client = match ClientBuilder::new().timeout(StdDuration::from_secs(12)).build() {
        Ok(client) => client,
        Err(error) => {
            error!(%error, "GitHub release client 构建失败");
            return Json(json!({ "release": fallback_release(&repo) })).into_response();
        }
    };
    let response = {
        let mut request = client
            .get(format!(
                "{}/repos/{repo}/releases/latest",
                relay_base("GITHUB_API_BASE", "https://api.github.com")
            ))
            .header("User-Agent", "VrcDog-Site")
            .header("Accept", "application/vnd.github+json");
        if let Some(token) = relay_token() {
            request = request.header("x-vrcdog-relay", token);
        }
        request.send().await
    };
    let response = match response {
        Ok(response) if response.status().is_success() => response,
        Ok(response) => {
            warn!(status = %response.status(), %repo, "GitHub release 请求失败");
            return Json(json!({ "release": fallback_release(&repo) })).into_response();
        }
        Err(error) => {
            warn!(%error, %repo, "GitHub release 连接失败");
            return Json(json!({ "release": fallback_release(&repo) })).into_response();
        }
    };
    let data: Value = match response.json().await {
        Ok(data) => data,
        Err(error) => {
            warn!(%error, "GitHub release 解析失败");
            return Json(json!({ "release": fallback_release(&repo) })).into_response();
        }
    };

    let assets: Vec<Value> = data["assets"]
        .as_array()
        .map(|items| {
            items
                .iter()
                .map(|asset| {
                    json!({
                        "name": asset["name"].as_str().unwrap_or(""),
                        "size": asset["size"].as_u64().unwrap_or(0),
                        "url": asset["browser_download_url"].as_str().unwrap_or(""),
                    })
                })
                .collect()
        })
        .unwrap_or_default();
    let tag = data["tag_name"].as_str().unwrap_or("").to_string();
    let version = tag.trim_start_matches(|c: char| c == 'v' || c == 'V').to_string();
    let release = json!({
        "tag_name": tag,
        "version": version,
        "published_at": data["published_at"].as_str(),
        "html_url": data["html_url"].as_str(),
        "assets": assets,
    });
    *guard = Some((repo, Instant::now(), release.clone()));
    Json(json!({ "release": release })).into_response()
}

async fn admin_save_server_settings(
    State(state): State<AppState>,
    Json(settings): Json<ServerSettings>,
) -> Response {
    if let Err(message) = validate_server_settings(&settings) {
        return (StatusCode::BAD_REQUEST, message).into_response();
    }
    state.data.write().await.server_settings = settings.clone();
    schedule_persist(&state);
    Json(json!({ "status": "ok", "settings": settings })).into_response()
}

async fn admin_survey_settings(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    Json(json!(data.survey_settings))
}

async fn admin_save_survey_settings(
    State(state): State<AppState>,
    Json(settings): Json<SurveySettings>,
) -> Json<Value> {
    state.data.write().await.survey_settings = settings.clone();
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "enabled": settings.enabled,
        "message": "Survey settings saved"
    }))
}

async fn admin_surveys(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    let mut surveys: Vec<Survey> = data.surveys.values().cloned().collect();
    surveys.sort_by(|left, right| right.updated_at.cmp(&left.updated_at));
    Json(json!({ "surveys": surveys }))
}

async fn admin_save_survey(
    State(state): State<AppState>,
    Json(mut incoming): Json<Survey>,
) -> Json<Value> {
    if let Err(message) = survey::validate_survey(&mut incoming) {
        return Json(json!({ "success": false, "message": message }));
    }
    let now = now_string();
    let mut data = state.data.write().await;
    if let Some(reward) = &incoming.reward {
        if !data.roles.contains_key(&reward.role_id) {
            return Json(json!({
                "success": false,
                "message": "奖励角色不存在，请选择一个有效角色"
            }));
        }
    }
    if let Some(existing) = data.surveys.get(&incoming.survey_id) {
        incoming.created_at = existing.created_at.clone();
        incoming.revision = existing.revision.max(1);
        if existing.status == "published" {
            let content_changed = existing.title != incoming.title
                || existing.description != incoming.description
                || existing.required_for_access != incoming.required_for_access
                || existing.questions != incoming.questions;
            if content_changed {
                incoming.revision += 1;
                incoming.status = "published".to_string();
                incoming.published_at = Some(now.clone());
            } else {
                incoming.published_at = existing.published_at.clone();
            }
        }
    } else {
        incoming.created_at = now.clone();
        incoming.revision = 1;
        if incoming.status == "published" {
            incoming.published_at = Some(now.clone());
        }
    }
    incoming.updated_at = now;
    let survey_id = incoming.survey_id.clone();
    let revision = incoming.revision;
    data.surveys.insert(survey_id.clone(), incoming);
    drop(data);
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "survey_id": survey_id,
        "revision": revision,
        "message": "Survey saved"
    }))
}

async fn admin_publish_survey(
    State(state): State<AppState>,
    Json(request): Json<SurveyIdRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    let Some(survey) = data.surveys.get_mut(&request.survey_id) else {
        return Json(json!({ "success": false, "message": "Survey not found" }));
    };
    let now = now_string();
    if survey.status == "published" {
        survey.revision += 1;
    }
    survey.status = "published".to_string();
    survey.published_at = Some(now.clone());
    survey.updated_at = now;
    let revision = survey.revision;
    drop(data);
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "revision": revision,
        "message": "Survey published"
    }))
}

async fn admin_resend_survey(
    State(state): State<AppState>,
    Json(request): Json<SurveyIdRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    let Some(survey) = data.surveys.get_mut(&request.survey_id) else {
        return Json(json!({ "success": false, "message": "Survey not found" }));
    };
    if survey.status != "published" {
        return Json(json!({ "success": false, "message": "Publish the survey before resending" }));
    }
    survey.revision += 1;
    survey.published_at = Some(now_string());
    survey.updated_at = now_string();
    let revision = survey.revision;
    drop(data);
    schedule_persist(&state);
    Json(json!({
        "success": true,
        "revision": revision,
        "message": "Survey resent to all users"
    }))
}

async fn admin_delete_survey(
    State(state): State<AppState>,
    Json(request): Json<SurveyIdRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    let removed = data.surveys.remove(&request.survey_id).is_some();
    if removed {
        data.survey_submissions
            .retain(|_, submission| submission.survey_id != request.survey_id);
    }
    drop(data);
    if removed {
        schedule_persist(&state);
    }
    Json(json!({
        "success": removed,
        "message": if removed { "Survey and its submissions deleted" } else { "Survey not found" }
    }))
}

async fn admin_survey_submissions(State(state): State<AppState>) -> Json<Value> {
    let data = state.data.read().await;
    let mut submissions: Vec<SurveySubmission> =
        data.survey_submissions.values().cloned().collect();
    submissions.sort_by(|left, right| right.submitted_at.cmp(&left.submitted_at));
    Json(json!({ "submissions": submissions }))
}

/// Raw click log for the admin panel. Clicks keep server-side snapshots of the
/// survey/question/option labels, so they remain readable even for deleted or
/// revised surveys. Optional `survey_id` query parameter filters the output.
#[derive(Deserialize)]
struct SurveyClicksQuery {
    survey_id: Option<String>,
}

async fn admin_survey_clicks(
    State(state): State<AppState>,
    Query(query): Query<SurveyClicksQuery>,
) -> Json<Value> {
    let data = state.data.read().await;
    let mut clicks: Vec<SurveyClickEvent> = data
        .survey_click_events
        .iter()
        .filter(|event| {
            query
                .survey_id
                .as_deref()
                .map_or(true, |survey_id| event.survey_id == survey_id)
        })
        .cloned()
        .collect();
    clicks.sort_by(|left, right| right.clicked_at.cmp(&left.clicked_at));
    Json(json!({ "clicks": clicks }))
}

async fn admin_delete_submission(
    State(state): State<AppState>,
    Json(request): Json<DeleteSubmissionRequest>,
) -> Json<Value> {
    let mut data = state.data.write().await;
    let removed = data
        .survey_submissions
        .remove(&request.submission_id)
        .is_some();
    drop(data);
    if removed {
        schedule_persist(&state);
    }
    Json(json!({
        "success": removed,
        "message": if removed { "Submission deleted" } else { "Submission not found" }
    }))
}

fn router(state: AppState) -> Router {
    // 官网访客侧：VRChat 登录 + 反馈/改模定制。附件上传放宽到 210 MiB。
    let site_routes = Router::new()
        .route("/api/site/auth", post(site_auth))
        .route("/api/site/me", get(site_me))
        .route("/api/site/logout", post(site_logout))
        .route("/api/site/inquiry/submit", post(site_inquiry_submit))
        .route("/api/site/inquiry/mine", get(site_inquiry_mine))
        .route("/api/site/inquiry/files/{file_name}", get(site_inquiry_file))
        .route("/api/site/inquiry/upload", post(site_inquiry_upload))
        .route("/api/site/asset/{file_name}", get(site_asset_file))
        .route("/api/site/visit", post(site_visit))
        .route("/api/site/captcha", get(site_captcha))
        .layer(DefaultBodyLimit::max(210 * 1024 * 1024));

    let admin_routes = Router::new()
        .route("/api/admin/me", get(admin_me))
        .route("/api/admin/change-password", post(admin_change_password))
        .route("/api/admin/inquiries", get(admin_inquiries))
        .route("/api/admin/inquiries/update", post(admin_inquiry_update))
        .route("/api/admin/inquiries/delete", post(admin_inquiry_delete))
        .route("/api/admin/inquiry/upload", post(admin_inquiry_upload))
        .route("/api/admin/site-asset", post(admin_site_asset_upload))
        .route("/api/admin/site-visitors", get(admin_site_visitors))
        .route("/api/admin/site-users", get(admin_site_users))
        .route(
            "/api/admin/mail-settings",
            get(admin_mail_settings_get).post(admin_mail_settings_save),
        )
        .route("/api/admin/mail-test", post(admin_mail_test))
        .route("/api/admin/clients", get(admin_clients))
        .route("/api/admin/users", get(admin_users))
        .route("/api/admin/kick", post(admin_kick))
        .route("/api/admin/ban", post(admin_ban))
        .route("/api/admin/unban", post(admin_unban))
        .route("/api/admin/freeze", post(admin_freeze))
        .route("/api/admin/unfreeze", post(admin_unfreeze))
        .route("/api/admin/remove", post(admin_remove))
        .route("/api/admin/roles", get(admin_roles).post(admin_save_role))
        .route("/api/admin/roles/delete", post(admin_delete_role))
        .route("/api/admin/roles/set_default", post(admin_set_default_role))
        .route("/api/admin/users/set_role", post(admin_set_user_role))
        .route(
            "/api/admin/survey-settings",
            get(admin_survey_settings).post(admin_save_survey_settings),
        )
        .route(
            "/api/admin/surveys",
            get(admin_surveys).post(admin_save_survey),
        )
        .route("/api/admin/surveys/publish", post(admin_publish_survey))
        .route("/api/admin/surveys/resend", post(admin_resend_survey))
        .route("/api/admin/surveys/delete", post(admin_delete_survey))
        .route(
            "/api/admin/survey-submissions",
            get(admin_survey_submissions),
        )
        .route(
            "/api/admin/survey-submissions/delete",
            post(admin_delete_submission),
        )
        .route("/api/admin/survey-clicks", get(admin_survey_clicks))
        // ── 资产社区管理 ────────────────────────────────────────────────
        .route(
            "/api/admin/community/settings",
            get(community::admin_settings_get).post(community::admin_settings_save),
        )
        .route(
            "/api/admin/server-settings",
            get(admin_server_settings).post(admin_save_server_settings),
        )
        .route("/api/admin/uploads/cleanup", post(admin_cleanup_uploads))
        .route(
            "/api/admin/site-config",
            get(admin_site_config_get).post(admin_site_config_save),
        )
        .route(
            "/api/admin/sponsor/settings",
            get(sponsor::admin_settings_get).post(sponsor::admin_settings_save),
        )
        .route("/api/admin/sponsor/list", get(sponsor::admin_list))
        .route("/api/admin/sponsor/upsert", post(sponsor::admin_upsert))
        .route("/api/admin/sponsor/delete", post(sponsor::admin_delete))        .route("/api/admin/community/assets", get(community::admin_assets))
        .route("/api/admin/community/moderate", post(community::admin_moderate))
        .route("/api/admin/community/grant", post(community::admin_grant_points))
        .route("/api/admin/community/ledger", get(community::admin_ledger))
        // 安全：vrchat-proxy 仅限管理员，随 admin_routes 一起套用 require_admin_session
        .route(
            "/api/vrchat-proxy",
            on(
                MethodFilter::GET
                    .or(MethodFilter::POST)
                    .or(MethodFilter::PUT)
                    .or(MethodFilter::DELETE)
                    .or(MethodFilter::PATCH)
                    .or(MethodFilter::OPTIONS),
                vrchat_api_proxy,
            ),
        )
        .route_layer(middleware::from_fn_with_state(state.clone(), require_admin_session))
        .layer(DefaultBodyLimit::max(210 * 1024 * 1024));

    // L2: client token 保护的路由（register 除外，因为 token 在 register 时才下发）
    let client_protected_routes = Router::new()
        .route("/api/client/heartbeat", post(heartbeat))
        .route("/api/client/disconnect", post(disconnect))
        .route("/api/client/check-status/{user_id}", get(check_status))
        .route("/api/client/features/{user_id}", get(get_features))
        .route("/api/client/surveys/{user_id}", get(client_surveys))
        .route("/api/client/surveys/submit", post(client_submit_survey))
        .route("/api/client/surveys/click", post(client_click_survey))
        .route("/api/client/surveys/dismiss", post(client_dismiss_survey))
        // `Bytes` 提取器默认有 2 MiB 的请求体上限，而下面 handler 按管理端设置的
        // `server_settings.max_upload_mb` 判断额度（默认 10 MiB，最大 64 MiB）。
        // 路由层抬到硬上限，超限时由 handler 返回带说明文案的 413。
        .route(
            "/api/client/surveys/upload",
            post(client_upload_file)
                .layer(DefaultBodyLimit::max(MAX_UPLOAD_HARD_BYTES as usize)),
        )
        .route("/api/client/uploads/{file_id}", get(client_get_upload))
        .route("/api/client/sponsor/{user_id}", get(sponsor::client_status))
        .route("/api/client/sponsor/claim", post(sponsor::client_claim))
        // ── 资产社区（客户端） ──────────────────────────────────────────
        .route("/api/client/community/assets", get(community::list_assets))
        .route("/api/client/community/assets/{asset_id}", get(community::get_asset))
        .route("/api/client/community/mine", get(community::my_assets))
        .route("/api/client/community/publish", post(community::publish_asset))
        .route(
            "/api/client/community/upload",
            post(community::upload_file)
                .layer(DefaultBodyLimit::max(MAX_COMMUNITY_UPLOAD_BYTES)),
        )
        .route(
            "/api/client/community/assets/{asset_id}/download",
            post(community::download_asset),
        )
        .route(
            "/api/client/community/assets/{asset_id}/buy",
            post(community::buy_asset),
        )
        .route("/api/client/community/files/{asset_id}", get(community::download_file))
        .route("/api/client/community/delete", post(community::delete_asset))
        .route("/api/client/community/points", get(community::points_overview))
        .route("/api/client/community/notifications", get(community::notifications))
        .route(
            "/api/client/community/notifications/read",
            post(community::mark_notifications_read),
        )
        .route(
            "/api/client/survey-history/{user_id}",
            get(client_survey_history),
        )
        .route(
            "/api/client/survey-history/delete",
            post(client_delete_submission),
        )
        .route_layer(middleware::from_fn_with_state(state.clone(), require_client_token));

    Router::new()
        .route("/", get(status_page))
        .route("/admin", get(admin_page))
        .route("/ping", get(ping))
        .route("/api/version", get(api_version))
        .route("/api/site-config", get(public_site_config))
        .route("/api/latest-release", get(public_latest_release))
        .route("/api/server-info", get(server_info))
        .route("/api/admin/auth", post(admin_auth))
        .route("/api/client/register", post(register))
        .route("/api/remote-assist/ws", get(remote_assist_ws))
        .route("/api/midi/library", get(midi_library::midi_library_search))
        .route("/api/midi/search", get(midi_library::midi_library_search))
        .route("/api/midi/categories", get(midi_library::midi_library_categories))
        .route("/api/midi/sources", get(midi_library::midi_library_sources))
        .route("/api/midi/file/{id}", get(midi_library::midi_library_file))
        .route("/api/midi/proxy", get(midi_library::midi_proxy_file))
        .merge(client_protected_routes)
        .merge(site_routes)
        .merge(admin_routes)
        .layer(
            // 只对自家官网和本地调试端口开放跨域；桌面客户端不走 CORS，不受影响。
            CorsLayer::new()
                .allow_origin(vec![
                    HeaderValue::from_static("https://vrcdog.pcb.im"),
                    HeaderValue::from_static("https://www.vrcdog.pcb.im"),
                    HeaderValue::from_static("http://127.0.0.1:8899"),
                    HeaderValue::from_static("http://localhost:8899"),
                ])
                .allow_methods(Any)
                .allow_headers(Any),
        )
        .layer(TraceLayer::new_for_http())
        .layer(middleware::from_fn(security_headers))
        .with_state(state)
}

/// 所有响应统一补上基础安全头：管理台不允许被 iframe 嵌套，附件/接口不允许 MIME 嗅探。
async fn security_headers(
    request: axum::extract::Request,
    next: axum::middleware::Next,
) -> Response {
    let mut response = next.run(request).await;
    let headers = response.headers_mut();
    headers
        .entry(X_CONTENT_TYPE_OPTIONS)
        .or_insert(HeaderValue::from_static("nosniff"));
    headers
        .entry(axum::http::header::HeaderName::from_static("x-frame-options"))
        .or_insert(HeaderValue::from_static("DENY"));
    headers
        .entry(axum::http::header::HeaderName::from_static("referrer-policy"))
        .or_insert(HeaderValue::from_static("strict-origin-when-cross-origin"));
    headers
        .entry(axum::http::header::HeaderName::from_static("content-security-policy"))
        .or_insert(HeaderValue::from_static("frame-ancestors 'none'"));
    response
}

async fn cleanup_stale_clients(state: AppState) {
    loop {
        tokio::time::sleep(std::time::Duration::from_secs(60)).await;
        let cutoff = Local::now().naive_local() - Duration::hours(2);
        let stale_ids: Vec<String> = state
            .clients
            .read()
            .await
            .iter()
            .filter_map(|(user_id, client)| {
                NaiveDateTime::parse_from_str(&client.last_heartbeat, "%Y-%m-%d %H:%M:%S")
                    .ok()
                    .filter(|heartbeat| *heartbeat < cutoff)
                    .map(|_| user_id.clone())
            })
            .collect();
        if stale_ids.is_empty() {
            continue;
        }
        for user_id in stale_ids {
            warn!(%user_id, "heartbeat timed out");
            mark_offline(&state, &user_id).await;
        }
        schedule_persist(&state);
    }
}

async fn cleanup_expired_sessions(state: AppState) {
    loop {
        tokio::time::sleep(std::time::Duration::from_secs(300)).await;
        let cutoff = Local::now().naive_local() - Duration::hours(24);
        let mut sessions = state.admin_sessions.write().await;
        sessions.retain(|_, session| {
            NaiveDateTime::parse_from_str(&session.created_at, "%Y-%m-%d %H:%M:%S")
                .map(|created| created > cutoff)
                .unwrap_or(false)
        });
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "vrcdog_server=info,tower_http=info".into()),
        )
        .init();

    info!("Starting vrcdog-server v{}", env!("CARGO_PKG_VERSION"));

    let host = env::var("VRCDOG_HOST").unwrap_or_else(|_| "0.0.0.0".to_string());
    let port = env::var("VRCDOG_PORT")
        .ok()
        .and_then(|value| value.parse::<u16>().ok())
        .unwrap_or(11451);
    let data_file = PathBuf::from(
        env::var("VRCDOG_DATA_FILE").unwrap_or_else(|_| "./data/server-state.json".to_string()),
    );
    let data = load_data(&data_file).await;
    let http_client = Arc::new(
        ClientBuilder::new()
            .cookie_store(false)
            .redirect(reqwest::redirect::Policy::none())
            .user_agent("VRCDog/5.1.3 (https://vrcdog.pcb.im; vrcdog@pcb.im)")
            .build()?,
    );
    let state = AppState {
        clients: Arc::new(RwLock::new(HashMap::new())),
        data: Arc::new(RwLock::new(data)),
        data_file: Arc::new(data_file),
        remote_assist: remote_assist_hub::RemoteAssistHub::default(),
        persist_dirty: Arc::new(AtomicBool::new(false)),
        persist_notify: Arc::new(Notify::new()),
        admin_sessions: Arc::new(RwLock::new(HashMap::new())),
        site_sessions: Arc::new(RwLock::new(HashMap::new())),
        vrchat_login_tickets: Arc::new(RwLock::new(HashMap::new())),
        captchas: Arc::new(RwLock::new(HashMap::new())),
        http_client,
    };
    if let Err(error) = persist_inner(&state).await {
        error!(
            data_file = %state.data_file.display(),
            %error,
            "Initial persist failed! If running in Docker, ensure the host data directory has correct permissions: `chown -R 10001:10001 ./data` or `chmod -R 777 ./data`"
        );
        return Err(format!("initial persist failed: {error}").into());
    }
    tokio::spawn(persist_worker(state.clone()));
    tokio::spawn(cleanup_stale_clients(state.clone()));
    tokio::spawn(cleanup_expired_sessions(state.clone()));

    let address: SocketAddr = format!("{host}:{port}").parse()?;

    // R5: optional TLS termination for the relay (wss://). When both cert and key
    // are configured the server serves TLS so the remote-assist channel is not
    // exposed to transport-level MITM. Without it we still serve plain ws:// (the
    // relay payloads are E2E-encrypted, but operators should enable TLS in prod).
    let tls_cert = env::var("VRCDOG_SERVER_TLS_CERT").ok().filter(|v| !v.is_empty());
    let tls_key = env::var("VRCDOG_SERVER_TLS_KEY").ok().filter(|v| !v.is_empty());
    match (tls_cert, tls_key) {
        (Some(cert_path), Some(key_path)) => {
            let rustls_config = axum_server::tls_rustls::RustlsConfig::from_pem_file(&cert_path, &key_path).await?;
            info!(%address, "VRCDog standalone server started (TLS/wss enabled)");
            let serve_future = axum_server::bind_rustls(address, rustls_config)
                .serve(router(state.clone()).into_make_service_with_connect_info::<SocketAddr>());
            let shutdown_state = state.clone();
            let result = tokio::select! {
                res = serve_future => res,
                _ = tokio::signal::ctrl_c() => {
                    info!("shutdown signal received");
                    let _ = persist_inner(&shutdown_state).await;
                    return Ok(());
                }
            };
            if let Err(e) = result {
                return Err(e.into());
            }
        }
        _ => {
            let listener = tokio::net::TcpListener::bind(address).await?;
            warn!(
                %address,
                "VRCDog standalone server started WITHOUT TLS (ws://). Remote-assist traffic is \
                 unencrypted at the transport layer — set VRCDOG_SERVER_TLS_CERT / VRCDOG_SERVER_TLS_KEY \
                 to enable wss:// and mitigate MITM on the key exchange."
            );
            axum::serve(
                listener,
                router(state.clone()).into_make_service_with_connect_info::<SocketAddr>(),
            )
            .with_graceful_shutdown(async move {
                let _ = tokio::signal::ctrl_c().await;
                info!("shutdown signal received");
                let _ = persist_inner(&state).await;
            })
            .await?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod admin_auth_tests {
    use super::*;

    /// TEST-NET-3（RFC 5737）地址，不会与任何真实来源 IP 冲突。
    ///
    /// 注意：ADMIN_AUTH_ATTEMPTS 是进程级全局状态，而 cargo test 默认并行执行，
    /// 因此每条用例必须使用互不相交的 IP，否则会互相清掉对方的计数。
    const IP_A: &str = "203.0.113.1";
    const IP_B: &str = "203.0.113.2";
    const IP_C: &str = "203.0.113.3";

    #[test]
    fn locks_source_ip_after_repeated_failures() {
        admin_auth_record_success(IP_A);
        assert_eq!(admin_auth_lock_remaining(IP_A), 0, "初始状态不应锁定");

        // 未达阈值：只累计失败次数，不锁定
        for _ in 0..ADMIN_AUTH_MAX_FAILURES - 1 {
            admin_auth_record_failure(IP_A);
            assert_eq!(admin_auth_lock_remaining(IP_A), 0, "未达阈值不应锁定");
        }

        // 达到阈值：锁定
        admin_auth_record_failure(IP_A);
        let remaining = admin_auth_lock_remaining(IP_A);
        assert!(remaining > 0, "达到阈值后应锁定");
        assert!(remaining <= ADMIN_AUTH_LOCKOUT_SECS, "锁定时长超出上限");

        // 认证成功即清零
        admin_auth_record_success(IP_A);
        assert_eq!(admin_auth_lock_remaining(IP_A), 0, "认证成功后应解锁");
    }

    /// 计数器按 IP 隔离：一个来源被锁定不影响其它来源。
    /// 用 IP_B / IP_C，与上面那条用例的 IP_A 错开。
    #[test]
    fn failure_counter_is_per_ip() {
        admin_auth_record_success(IP_B);
        admin_auth_record_success(IP_C);
        for _ in 0..ADMIN_AUTH_MAX_FAILURES {
            admin_auth_record_failure(IP_B);
        }
        assert!(admin_auth_lock_remaining(IP_B) > 0, "IP_B 应被锁定");
        assert_eq!(admin_auth_lock_remaining(IP_C), 0, "IP_C 不应受 IP_B 影响");
        admin_auth_record_success(IP_B);
        admin_auth_record_success(IP_C);
    }
}
#[cfg(test)]
mod client_ownership_tests {
    use super::*;

    /// `/api/client/*` 的归属校验：路径 / 查询里声明的 user_id 必须与 token 验证出来的身份一致。
    /// `require_client_token` 中间件已经把验证过的 user_id 放进 request extension，
    /// 各 handler 必须比对它 —— 否则任何一台已注册设备都能读别人的封禁状态、
    /// 权限开关、问卷进度，或把附件记到别人名下。
    #[test]
    fn owner_check_accepts_only_the_matching_identity() {
        assert!(assert_client_owner("u1", "u1").is_ok());

        let rejected = assert_client_owner("u1", "u2")
            .err()
            .expect("身份不一致必须被拒绝");
        assert_eq!(rejected.0["status"], json!("auth_failed"));
    }

    #[test]
    fn empty_claimed_user_is_rejected() {
        // `/api/client/features/` 这种空路径参数不能被当成合法身份
        let rejected = assert_client_owner("u1", "")
            .err()
            .expect("空的声明身份必须被拒绝");
        assert_eq!(rejected.0["status"], json!("auth_failed"));
    }
}

#[cfg(test)]
mod server_settings_tests {
    use super::*;

    #[test]
    fn upload_limit_stays_in_range() {
        let mut settings = ServerSettings::default();
        assert_eq!(settings.max_upload_mb, 10, "默认额度应保持历史行为");
        assert!(validate_server_settings(&settings).is_ok());

        settings.max_upload_mb = 64;
        assert!(validate_server_settings(&settings).is_ok());

        settings.max_upload_mb = 0;
        assert!(validate_server_settings(&settings).is_err());

        settings.max_upload_mb = 65;
        assert!(validate_server_settings(&settings).is_err());
    }

    #[test]
    fn maintenance_message_is_bounded() {
        let mut settings = ServerSettings::default();
        settings.maintenance_message = "维护中".repeat(60); // 180 字符
        assert!(validate_server_settings(&settings).is_ok());

        settings.maintenance_message = "维".repeat(201);
        assert!(validate_server_settings(&settings).is_err());
    }
}
