//! 资产社区 + 日豆积分账本。
//!
//! 设计要点（与 `main.rs` 里既有的持久化/鉴权风格保持一致）：
//! - 所有数据挂在 `PersistentData` 的一个字段里，由主进程的 persist worker
//!   统一落盘，因此这里**不自己写文件**，改完数据后调用 `crate::schedule_persist`。
//! - 客户端身份来自 `require_client_token` 注入的 `Extension<String>`（已校验的 user_id），
//!   管理员身份来自 `require_admin_session`。
//! - 计费逻辑集中在纯函数（`apply_purchase` / `apply_download`），handler 只做校验与
//!   响应包装，这样经济规则可以单测，不用起 HTTP。
//!
//! 经济规则：
//! - 资产 `price = 0` 为免费；免费资产任何人可下载，创作者按「每个不同用户首次下载」
//!   获得 `reward_per_download` 日豆（受 `daily_reward_cap` 日上限约束）。
//! - 付费资产按 `price` 扣买家日豆，扣掉 `purchase_commission_percent` 的平台抽成后
//!   余额进入创作者账户；同一用户重复购买会被拒绝。
//! - 每次下载 / 购买都会给创作者（以及购买时的买家）写一条站内通知。

use axum::{
    body::Bytes,
    extract::{Path, Query, State},
    http::{header, HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    Extension, Json,
};
use chrono::Local;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::HashMap;

use crate::AppState;

// ─── 常量 ────────────────────────────────────────────────────────────────────

const MAX_TITLE_CHARS: usize = 80;
const MAX_DESCRIPTION_CHARS: usize = 4000;
const MAX_TAG_CHARS: usize = 24;
const MAX_TAGS: usize = 8;
const MAX_BASES: usize = 8;
const MAX_VERSION_CHARS: usize = 24;
const LEDGER_KEEP: usize = 20_000;
const NOTIFICATIONS_PER_USER: usize = 100;

// ─── 数据结构 ────────────────────────────────────────────────────────────────

#[derive(Clone, Serialize, Deserialize, Debug)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum AssetSource {
    /// 文件托管在 VRCDog 服务器
    Hosted {
        stored_name: String,
        file_name: String,
        mime: String,
        size: u64,
        sha256: String,
    },
    /// 只登记外部链接（Booth / 网盘 / GitHub）
    External { url: String },
}

#[derive(Clone, Copy, Serialize, Deserialize, Debug, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum AssetStatus {
    Pending,
    Approved,
    Rejected,
    Hidden,
}

impl AssetStatus {
    pub fn as_str(self) -> &'static str {
        match self {
            AssetStatus::Pending => "pending",
            AssetStatus::Approved => "approved",
            AssetStatus::Rejected => "rejected",
            AssetStatus::Hidden => "hidden",
        }
    }
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct CommunityAsset {
    pub id: String,
    pub owner_id: String,
    pub owner_name: String,
    #[serde(default)]
    pub owner_avatar: String,
    pub title: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub category: String,
    #[serde(default)]
    pub bases: Vec<String>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub version: String,
    /// 0 = 免费；>0 = 需要多少日豆
    pub price: u64,
    pub source: AssetSource,
    pub status: AssetStatus,
    #[serde(default)]
    pub downloads: u64,
    #[serde(default)]
    pub purchases: u64,
    /// user_id → 首次下载时间（免费奖励只发一次）
    #[serde(default)]
    pub downloaders: HashMap<String, String>,
    /// user_id → 购买时间
    #[serde(default)]
    pub buyers: HashMap<String, String>,
    pub created_at: String,
    pub updated_at: String,
    #[serde(default)]
    pub review_note: String,
}

#[derive(Clone, Serialize, Deserialize, Debug, Default)]
pub struct PointsAccount {
    #[serde(default)]
    pub balance: i64,
    #[serde(default)]
    pub earned: i64,
    #[serde(default)]
    pub spent: i64,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct LedgerEntry {
    pub id: String,
    pub user_id: String,
    pub delta: i64,
    pub balance_after: i64,
    pub reason: String,
    #[serde(default)]
    pub asset_id: Option<String>,
    pub created_at: String,
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct CommunityNotification {
    pub id: String,
    pub user_id: String,
    pub kind: String,
    pub title: String,
    #[serde(default)]
    pub body: String,
    #[serde(default)]
    pub asset_id: Option<String>,
    #[serde(default)]
    pub read: bool,
    pub created_at: String,
}

fn default_true() -> bool {
    true
}

#[derive(Clone, Serialize, Deserialize, Debug)]
pub struct CommunitySettings {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_true")]
    pub allow_hosted_upload: bool,
    #[serde(default = "default_max_upload_mb")]
    pub max_upload_mb: u64,
    #[serde(default = "default_reward_per_download")]
    pub reward_per_download: i64,
    #[serde(default)]
    pub purchase_commission_percent: u64,
    #[serde(default = "default_min_price")]
    pub min_price: u64,
    #[serde(default = "default_max_price")]
    pub max_price: u64,
    #[serde(default)]
    pub require_review: bool,
    #[serde(default = "default_first_publish_grant")]
    pub first_publish_grant: i64,
    /// 新用户注册时一次性赠送的日豆（0 = 不送）。每人只会拿一次。
    #[serde(default = "default_signup_grant")]
    pub signup_grant: i64,
    #[serde(default = "default_daily_reward_cap")]
    pub daily_reward_cap: i64,
    #[serde(default)]
    pub external_host_allowlist: Vec<String>,
}

fn default_max_upload_mb() -> u64 {
    64
}
fn default_reward_per_download() -> i64 {
    10
}
fn default_min_price() -> u64 {
    1
}
fn default_max_price() -> u64 {
    5000
}
fn default_first_publish_grant() -> i64 {
    0
}
fn default_daily_reward_cap() -> i64 {
    500
}
fn default_signup_grant() -> i64 {
    0
}

impl Default for CommunitySettings {
    fn default() -> Self {
        Self {
            enabled: true,
            allow_hosted_upload: true,
            max_upload_mb: default_max_upload_mb(),
            reward_per_download: default_reward_per_download(),
            purchase_commission_percent: 0,
            min_price: default_min_price(),
            max_price: default_max_price(),
            require_review: false,
            first_publish_grant: default_first_publish_grant(),
            signup_grant: default_signup_grant(),
            daily_reward_cap: default_daily_reward_cap(),
            external_host_allowlist: Vec::new(),
        }
    }
}

impl CommunitySettings {
    /// 后台保存前的校验。返回中文错误信息，直接回给管理页。
    pub fn validate(&mut self) -> Result<(), String> {
        if self.max_upload_mb == 0 || self.max_upload_mb > 512 {
            return Err("单文件上限必须在 1–512 MB 之间".into());
        }
        if self.reward_per_download < 0 || self.reward_per_download > 10_000 {
            return Err("下载奖励必须在 0–10000 日豆之间".into());
        }
        if self.purchase_commission_percent > 100 {
            return Err("平台抽成百分比必须在 0–100 之间".into());
        }
        if self.min_price > self.max_price {
            return Err("最低价格不能高于最高价格".into());
        }
        if self.max_price == 0 || self.max_price > 1_000_000 {
            return Err("最高价格必须在 1–1000000 日豆之间".into());
        }
        if self.daily_reward_cap < 0 || self.daily_reward_cap > 1_000_000 {
            return Err("每日奖励上限必须在 0–1000000 日豆之间".into());
        }
        if self.first_publish_grant < 0 || self.first_publish_grant > 100_000 {
            return Err("首次发布奖励必须在 0–100000 日豆之间".into());
        }
        if self.signup_grant < 0 || self.signup_grant > 100_000 {
            return Err("新人赠送必须在 0–100000 日豆之间".into());
        }
        self.external_host_allowlist = self
            .external_host_allowlist
            .iter()
            .map(|host| host.trim().to_ascii_lowercase())
            .filter(|host| !host.is_empty())
            .collect();
        Ok(())
    }
}

#[derive(Clone, Serialize, Deserialize, Debug, Default)]
pub struct CommunityData {
    #[serde(default)]
    pub assets: HashMap<String, CommunityAsset>,
    #[serde(default)]
    pub accounts: HashMap<String, PointsAccount>,
    #[serde(default)]
    pub ledger: Vec<LedgerEntry>,
    #[serde(default)]
    pub notifications: HashMap<String, Vec<CommunityNotification>>,
    #[serde(default)]
    pub settings: CommunitySettings,
    /// 已经拿过「首次发布奖励」的用户
    #[serde(default)]
    pub first_publish_granted: Vec<String>,
    /// 已经拿过「新人赠送」的用户（与首次发布奖励分开记账，两者互不影响）
    #[serde(default)]
    pub signup_granted: Vec<String>,
}

impl CommunityData {
    pub fn settings(&self) -> &CommunitySettings {
        &self.settings
    }
}

// ─── 小工具 ──────────────────────────────────────────────────────────────────

fn now_string() -> String {
    Local::now().format("%Y-%m-%d %H:%M:%S").to_string()
}

fn new_id() -> String {
    uuid::Uuid::new_v4().simple().to_string()
}

fn account_mut<'a>(data: &'a mut CommunityData, user_id: &str) -> &'a mut PointsAccount {
    data.accounts.entry(user_id.to_string()).or_default()
}

fn push_ledger(
    data: &mut CommunityData,
    user_id: &str,
    delta: i64,
    balance_after: i64,
    reason: &str,
    asset_id: Option<&str>,
) {
    data.ledger.push(LedgerEntry {
        id: new_id(),
        user_id: user_id.to_string(),
        delta,
        balance_after,
        reason: reason.to_string(),
        asset_id: asset_id.map(|value| value.to_string()),
        created_at: now_string(),
    });
    if data.ledger.len() > LEDGER_KEEP {
        let excess = data.ledger.len() - LEDGER_KEEP;
        data.ledger.drain(0..excess);
    }
}

fn push_notification(
    data: &mut CommunityData,
    user_id: &str,
    kind: &str,
    title: &str,
    body: &str,
    asset_id: Option<&str>,
) {
    let entry = CommunityNotification {
        id: new_id(),
        user_id: user_id.to_string(),
        kind: kind.to_string(),
        title: title.to_string(),
        body: body.to_string(),
        asset_id: asset_id.map(|value| value.to_string()),
        read: false,
        created_at: now_string(),
    };
    let list = data.notifications.entry(user_id.to_string()).or_default();
    list.push(entry);
    if list.len() > NOTIFICATIONS_PER_USER {
        let excess = list.len() - NOTIFICATIONS_PER_USER;
        list.drain(0..excess);
    }
}

/// 新用户注册后的「新人赠送」日豆。
///
/// 由 `register` 在用户记录落库之后调用；同一个 user_id 只会发一次
/// （`signup_granted` 记账），管理员之后调整 `signup_grant` 不会重复补发。
/// 社区被关闭或 `signup_grant == 0` 时直接跳过，不写账本也不发通知。
pub async fn grant_signup_points(state: &AppState, user_id: &str) {
    let mut guard = state.data.write().await;
    let settings = guard.community.settings.clone();
    if !settings.enabled || settings.signup_grant <= 0 {
        return;
    }
    if guard
        .community
        .signup_granted
        .iter()
        .any(|id| id == user_id)
    {
        return;
    }
    guard.community.signup_granted.push(user_id.to_string());
    let granted = settings.signup_grant;
    {
        let data = &mut guard.community;
        let after = {
            let account = ensure_account(data, user_id);
            account.balance += granted;
            account.earned += granted;
            account.balance
        };
        push_ledger(data, user_id, granted, after, "signup", None);
        let body = format!("新人赠送 {granted} 日豆已到账，可以在资产社区下载或购买作品。");
        push_notification(
            data,
            user_id,
            "points_signup",
            "新人日豆已到账",
            &body,
            None,
        );
        tracing::info!(%user_id, granted, "community signup grant issued");
    }
    drop(guard);
    crate::schedule_persist(state);
}

/// 今天已经拿到的下载奖励总额（用于每日上限）
fn today_reward_total(data: &CommunityData, user_id: &str) -> i64 {
    let today = Local::now().format("%Y-%m-%d").to_string();
    data.ledger
        .iter()
        .filter(|entry| entry.user_id == user_id && entry.reason == "download_reward")
        .filter(|entry| entry.created_at.starts_with(&today))
        .map(|entry| entry.delta)
        .sum()
}

fn ensure_account<'a>(data: &'a mut CommunityData, user_id: &str) -> &'a mut PointsAccount {
    data.accounts.entry(user_id.to_string()).or_default()
}

fn user_profile(data: &crate::PersistentData, user_id: &str) -> (String, String) {
    match data.users.get(user_id) {
        Some(record) => (record.display_name.clone(), record.avatar_url.clone()),
        None => (user_id.to_string(), String::new()),
    }
}

// ─── 计费纯逻辑（可单测） ────────────────────────────────────────────────────

#[derive(Debug, PartialEq, Eq)]
pub struct PurchaseOutcome {
    pub price: u64,
    pub payout: i64,
    pub commission: i64,
    pub buyer_balance: i64,
    pub owner_balance: i64,
}

/// 购买资产：从买家扣款、给创作者结算（扣平台抽成）。
pub fn apply_purchase(
    data: &mut CommunityData,
    buyer_id: &str,
    asset_id: &str,
) -> Result<PurchaseOutcome, String> {
    let settings = data.settings.clone();
    let (price, owner_id, title) = {
        let asset = data
            .assets
            .get(asset_id)
            .ok_or_else(|| "资产不存在".to_string())?;
        if asset.status != AssetStatus::Approved {
            return Err("该资产当前不可购买".into());
        }
        if asset.owner_id == buyer_id {
            return Err("不能购买自己发布的资产".into());
        }
        if asset.buyers.contains_key(buyer_id) {
            return Err("你已经购买过这个资产".into());
        }
        if asset.price == 0 {
            return Err("这是免费资产，直接下载即可".into());
        }
        (
            asset.price,
            asset.owner_id.clone(),
            asset.title.clone(),
        )
    };

    let buyer_balance = account_mut(data, buyer_id).balance;
    if buyer_balance < price as i64 {
        return Err(format!("日豆不足：需要 {price}，当前 {buyer_balance}"));
    }

    let commission = if settings.purchase_commission_percent == 0 {
        0
    } else {
        (price as i128 * settings.purchase_commission_percent as i128 / 100) as i64
    };
    let payout = price as i64 - commission;

    let buyer_after = {
        let account = account_mut(data, buyer_id);
        account.balance -= price as i64;
        account.spent += price as i64;
        account.balance
    };
    push_ledger(
        data,
        buyer_id,
        -(price as i64),
        buyer_after,
        "purchase",
        Some(asset_id),
    );

    let owner_after = {
        let account = account_mut(data, &owner_id);
        account.balance += payout;
        account.earned += payout;
        account.balance
    };
    push_ledger(
        data,
        &owner_id,
        payout,
        owner_after,
        "sale",
        Some(asset_id),
    );

    let stamp = now_string();
    if let Some(asset) = data.assets.get_mut(asset_id) {
        asset.purchases += 1;
        asset.buyers.insert(buyer_id.to_string(), stamp.clone());
        asset.updated_at = stamp;
    }

    push_notification(
        data,
        &owner_id,
        "asset_purchased",
        "你的资产被购买了",
        &format!("「{title}」被一位用户用 {price} 日豆购买，到账 {payout} 日豆。"),
        Some(asset_id),
    );
    push_notification(
        data,
        buyer_id,
        "asset_purchase_ok",
        "购买成功",
        &format!("你已购买「{title}」，花费 {price} 日豆。"),
        Some(asset_id),
    );

    Ok(PurchaseOutcome {
        price,
        payout,
        commission,
        buyer_balance: buyer_after,
        owner_balance: owner_after,
    })
}

#[derive(Debug, PartialEq, Eq)]
pub struct DownloadOutcome {
    pub reward: i64,
    pub first_time: bool,
    pub owner_balance: i64,
}

/// 下载资产：记录下载；免费资产按「每个用户首次下载」给创作者奖励。
pub fn apply_download(
    data: &mut CommunityData,
    user_id: &str,
    asset_id: &str,
) -> Result<DownloadOutcome, String> {
    let settings = data.settings.clone();
    let (price, owner_id, title) = {
        let asset = data
            .assets
            .get(asset_id)
            .ok_or_else(|| "资产不存在".to_string())?;
        if asset.status != AssetStatus::Approved && asset.owner_id != user_id {
            return Err("该资产当前不可下载".into());
        }
        (asset.price, asset.owner_id.clone(), asset.title.clone())
    };

    if price > 0 && !data.assets[asset_id].buyers.contains_key(user_id) && owner_id != user_id {
        return Err("这是付费资产，请先购买".into());
    }

    let first_time = !data.assets[asset_id].downloaders.contains_key(user_id);
    let stamp = now_string();
    if let Some(asset) = data.assets.get_mut(asset_id) {
        asset.downloads += 1;
        if first_time {
            asset.downloaders.insert(user_id.to_string(), stamp.clone());
        }
        asset.updated_at = stamp;
    }

    let mut reward = 0i64;
    // 自己的资产不计奖励；免费资产才发下载奖励
    if price == 0 && owner_id != user_id && first_time && settings.reward_per_download > 0 {
        let already = today_reward_total(data, &owner_id);
        let room = (settings.daily_reward_cap - already).max(0);
        reward = settings.reward_per_download.min(room);
        if reward > 0 {
            let owner_after = {
                let account = account_mut(data, &owner_id);
                account.balance += reward;
                account.earned += reward;
                account.balance
            };
            push_ledger(
                data,
                &owner_id,
                reward,
                owner_after,
                "download_reward",
                Some(asset_id),
            );
        }
    }

    let owner_balance = account_mut(data, &owner_id).balance;

    if price == 0 && owner_id != user_id {
        push_notification(
            data,
            &owner_id,
            "asset_downloaded",
            "你的资产被下载",
            &format!("「{title}」被下载了{}。", if first_time { "（首次）" } else { "" }),
            Some(asset_id),
        );
    }

    Ok(DownloadOutcome {
        reward,
        first_time,
        owner_balance,
    })
}

// ─── 请求类型 ────────────────────────────────────────────────────────────────

#[derive(Deserialize, Default)]
pub struct ListQuery {
    #[serde(default)]
    pub q: Option<String>,
    #[serde(default)]
    pub category: Option<String>,
    #[serde(default)]
    pub base: Option<String>,
    #[serde(default)]
    pub price: Option<String>,
    #[serde(default)]
    pub sort: Option<String>,
    #[serde(default)]
    pub page: Option<u32>,
    #[serde(default)]
    pub n: Option<u32>,
}

#[derive(Deserialize)]
pub struct PublishRequest {
    pub title: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub category: String,
    #[serde(default)]
    pub bases: Vec<String>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub version: String,
    #[serde(default)]
    pub price: u64,
    /// 二选一：托管文件描述 或 外部链接
    pub hosted: Option<HostedRef>,
    pub external_url: Option<String>,
}

#[derive(Deserialize)]
pub struct HostedRef {
    pub stored_name: String,
    pub file_name: String,
    #[serde(default)]
    pub mime: String,
    #[serde(default)]
    pub size: u64,
    #[serde(default)]
    pub sha256: String,
}

#[derive(Deserialize)]
pub struct AssetAction {
    pub asset_id: String,
}

#[derive(Deserialize)]
pub struct ModerateRequest {
    pub asset_id: String,
    /// approve / reject / hide / delete
    pub action: String,
    #[serde(default)]
    pub note: String,
}

#[derive(Deserialize)]
pub struct GrantRequest {
    pub user_id: String,
    pub amount: i64,
    #[serde(default)]
    pub reason: String,
}

#[derive(Deserialize, Default)]
pub struct NotificationQuery {
    #[serde(default)]
    pub limit: Option<u32>,
}

// ─── 校验 ────────────────────────────────────────────────────────────────────

fn validate_publish(req: &PublishRequest, settings: &CommunitySettings) -> Result<(), String> {
    let title = req.title.trim();
    if title.chars().count() < 2 || title.chars().count() > MAX_TITLE_CHARS {
        return Err(format!(
            "标题长度必须在 2–{MAX_TITLE_CHARS} 个字符之间"
        ));
    }
    if req.description.chars().count() > MAX_DESCRIPTION_CHARS {
        return Err(format!("描述不能超过 {MAX_DESCRIPTION_CHARS} 个字符"));
    }
    if req.version.chars().count() > MAX_VERSION_CHARS {
        return Err(format!("版本号不能超过 {MAX_VERSION_CHARS} 个字符"));
    }
    if req.bases.len() > MAX_BASES {
        return Err(format!("适配素体最多 {MAX_BASES} 个"));
    }
    if req.tags.len() > MAX_TAGS {
        return Err(format!("标签最多 {MAX_TAGS} 个"));
    }
    if req.tags.iter().any(|tag| tag.chars().count() > MAX_TAG_CHARS) {
        return Err(format!("单个标签不能超过 {MAX_TAG_CHARS} 个字符"));
    }
    if req.price > 0 && (req.price < settings.min_price || req.price > settings.max_price) {
        return Err(format!(
            "价格必须在 {}–{} 日豆之间（0 表示免费）",
            settings.min_price, settings.max_price
        ));
    }
    match (&req.hosted, &req.external_url) {
        (Some(_), Some(_)) => Err("托管文件和外部链接只能二选一".into()),
        (None, None) => Err("必须提供托管文件或外部链接".into()),
        (Some(hosted), None) => {
            if !settings.allow_hosted_upload {
                return Err("后台已关闭直传托管，请改用外部链接".into());
            }
            if hosted.stored_name.is_empty()
                || hosted.stored_name.contains('/')
                || hosted.stored_name.contains('\\')
                || hosted.stored_name.contains("..")
            {
                return Err("托管文件标识非法".into());
            }
            Ok(())
        }
        (None, Some(url)) => validate_external_url(url, settings),
    }
}

fn validate_external_url(url: &str, settings: &CommunitySettings) -> Result<(), String> {
    let trimmed = url.trim();
    if trimmed.len() > 500 {
        return Err("外部链接过长".into());
    }
    let Some(rest) = trimmed.strip_prefix("https://") else {
        return Err("外部链接必须使用 https://".into());
    };
    let host = rest
        .split(['/', '?', '#'])
        .next()
        .unwrap_or_default()
        .to_ascii_lowercase();
    if host.is_empty() {
        return Err("外部链接缺少域名".into());
    }
    if !settings.external_host_allowlist.is_empty()
        && !settings
            .external_host_allowlist
            .iter()
            .any(|allowed| host == *allowed || host.ends_with(&format!(".{allowed}")))
    {
        return Err(format!("该域名不在后台允许列表里：{host}"));
    }
    Ok(())
}

// ─── 响应辅助 ────────────────────────────────────────────────────────────────

fn asset_view(data: &CommunityData, asset: &CommunityAsset, viewer: &str) -> Value {
    let owned = asset.buyers.contains_key(viewer)
        || asset.owner_id == viewer
        || asset.price == 0;
    let downloaded = asset.downloaders.contains_key(viewer);
    json!({
        "id": asset.id,
        "owner_id": asset.owner_id,
        "owner_name": asset.owner_name,
        "owner_avatar": asset.owner_avatar,
        "title": asset.title,
        "description": asset.description,
        "category": asset.category,
        "bases": asset.bases,
        "tags": asset.tags,
        "version": asset.version,
        "price": asset.price,
        "source_kind": match asset.source { AssetSource::Hosted { .. } => "hosted", AssetSource::External { .. } => "external" },
        "external_url": match &asset.source { AssetSource::External { url } => json!(url), _ => Value::Null },
        "file_name": match &asset.source { AssetSource::Hosted { file_name, .. } => json!(file_name), _ => Value::Null },
        "file_size": match &asset.source { AssetSource::Hosted { size, .. } => json!(size), _ => Value::Null },
        "status": asset.status.as_str(),
        "downloads": asset.downloads,
        "purchases": asset.purchases,
        "owned": owned,
        "downloaded": downloaded,
        "created_at": asset.created_at,
        "updated_at": asset.updated_at,
        "review_note": asset.review_note,
        "_my_points": data.accounts.get(viewer).map(|account| account.balance).unwrap_or(0),
    })
}

fn error_response(status: StatusCode, message: &str) -> Response {
    (status, Json(json!({ "success": false, "message": message }))).into_response()
}

fn require_community_enabled(data: &CommunityData) -> Result<(), Response> {
    if data.settings.enabled {
        Ok(())
    } else {
        Err(error_response(
            StatusCode::SERVICE_UNAVAILABLE,
            "资产社区已被管理员关闭",
        ))
    }
}

// ─── 客户端：浏览 ────────────────────────────────────────────────────────────

pub async fn list_assets(
    State(state): State<AppState>,
    Extension(viewer): Extension<String>,
    Query(query): Query<ListQuery>,
) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    if let Err(resp) = require_community_enabled(data) {
        return resp;
    }
    let needle = query.q.unwrap_or_default().trim().to_lowercase();
    let category = query.category.unwrap_or_default();
    let base = query.base.unwrap_or_default();
    let price_mode = query.price.unwrap_or_default();
    let sort = query.sort.unwrap_or_else(|| "new".into());

    let mut items: Vec<&CommunityAsset> = data
        .assets
        .values()
        .filter(|asset| asset.status == AssetStatus::Approved)
        .filter(|asset| {
            category.is_empty() || asset.category == category
        })
        .filter(|asset| {
            base.is_empty() || asset.bases.iter().any(|item| item == &base)
        })
        .filter(|asset| match price_mode.as_str() {
            "free" => asset.price == 0,
            "paid" => asset.price > 0,
            _ => true,
        })
        .filter(|asset| {
            needle.is_empty()
                || asset.title.to_lowercase().contains(&needle)
                || asset.description.to_lowercase().contains(&needle)
                || asset.tags.iter().any(|tag| tag.to_lowercase().contains(&needle))
                || asset.owner_name.to_lowercase().contains(&needle)
        })
        .collect();

    match sort.as_str() {
        "popular" => items.sort_by(|a, b| {
            b.downloads
                .cmp(&a.downloads)
                .then(b.purchases.cmp(&a.purchases))
        }),
        "price_asc" => items.sort_by(|a, b| a.price.cmp(&b.price)),
        "price_desc" => items.sort_by(|a, b| b.price.cmp(&a.price)),
        _ => items.sort_by(|a, b| b.created_at.cmp(&a.created_at)),
    }

    let total = items.len();
    let page = query.page.unwrap_or(1).max(1);
    let page_size = query.n.unwrap_or(24).clamp(1, 100) as usize;
    let offset = ((page - 1) as usize).saturating_mul(page_size);

    let payload: Vec<Value> = items
        .into_iter()
        .skip(offset)
        .take(page_size)
        .map(|asset| asset_view(data, asset, &viewer))
        .collect();

    Json(json!({
        "success": true,
        "items": payload,
        "total": total,
        "page": page,
        "page_size": page_size,
        "settings": {
            "enabled": data.settings.enabled,
            "allow_hosted_upload": data.settings.allow_hosted_upload,
            "max_upload_mb": data.settings.max_upload_mb,
            "min_price": data.settings.min_price,
            "max_price": data.settings.max_price,
            "reward_per_download": data.settings.reward_per_download,
            "require_review": data.settings.require_review,
        }
    }))
    .into_response()
}

pub async fn get_asset(
    State(state): State<AppState>,
    Extension(viewer): Extension<String>,
    Path(asset_id): Path<String>,
) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    match data.assets.get(&asset_id) {
        Some(asset) if asset.status == AssetStatus::Approved || asset.owner_id == viewer => {
            Json(json!({ "success": true, "asset": asset_view(data, asset, &viewer) })).into_response()
        }
        Some(_) => error_response(StatusCode::NOT_FOUND, "资产不存在或未通过审核"),
        None => error_response(StatusCode::NOT_FOUND, "资产不存在"),
    }
}

pub async fn my_assets(State(state): State<AppState>, Extension(viewer): Extension<String>) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    let mut items: Vec<&CommunityAsset> = data
        .assets
        .values()
        .filter(|asset| asset.owner_id == viewer)
        .collect();
    items.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    let payload: Vec<Value> = items
        .into_iter()
        .map(|asset| asset_view(data, asset, &viewer))
        .collect();
    Json(json!({
        "success": true,
        "items": payload,
        "balance": data.accounts.get(&viewer).map(|a| a.balance).unwrap_or(0)
    }))
    .into_response()
}

// ─── 客户端：上传 / 发布 ─────────────────────────────────────────────────────

pub async fn upload_file(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let settings = state.data.read().await.community.settings.clone();
    if !settings.enabled {
        return error_response(StatusCode::SERVICE_UNAVAILABLE, "资产社区已被管理员关闭");
    }
    if !settings.allow_hosted_upload {
        return error_response(StatusCode::FORBIDDEN, "后台已关闭直传托管，请改用外部链接");
    }
    if body.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "文件为空");
    }
    let limit = settings.max_upload_mb.saturating_mul(1024 * 1024);
    if body.len() as u64 > limit {
        return error_response(
            StatusCode::PAYLOAD_TOO_LARGE,
            &format!("文件超过上限（{} MB）", settings.max_upload_mb),
        );
    }

    let file_name = headers
        .get("x-file-name")
        .and_then(|value| value.to_str().ok())
        .map(|value| sanitize_file_name(value))
        .filter(|value| !value.is_empty())
        .unwrap_or_else(|| "asset.bin".to_string());
    let mime = headers
        .get(header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("application/octet-stream")
        .to_string();
    let ext = file_name
        .rsplit_once('.')
        .map(|(_, ext)| ext.to_ascii_lowercase())
        .filter(|ext| ext.len() <= 6 && ext.chars().all(|c| c.is_ascii_alphanumeric()))
        .unwrap_or_else(|| "bin".to_string());

    let dir = community_uploads_dir(&state);
    if let Err(error) = tokio::fs::create_dir_all(&dir).await {
        return error_response(
            StatusCode::INTERNAL_SERVER_ERROR,
            &format!("创建上传目录失败：{error}"),
        );
    }
    let stored_name = format!("{}.{}", new_id(), ext);
    let path = dir.join(&stored_name);
    if let Err(error) = tokio::fs::write(&path, &body).await {
        return error_response(
            StatusCode::INTERNAL_SERVER_ERROR,
            &format!("写入文件失败：{error}"),
        );
    }

    let mut hasher = Sha256::new();
    hasher.update(&body);
    let sha256 = hex::encode(hasher.finalize());

    tracing::info!(%user_id, stored_name = %stored_name, size = body.len(), "community asset uploaded");

    Json(json!({
        "success": true,
        "stored_name": stored_name,
        "file_name": file_name,
        "mime": mime,
        "size": body.len(),
        "sha256": sha256,
    }))
    .into_response()
}

pub async fn publish_asset(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    Json(req): Json<PublishRequest>,
) -> Response {
    let mut guard = state.data.write().await;
    let (owner_name, owner_avatar) = user_profile(&guard, &user_id);
    {
        let settings = guard.community.settings.clone();
        if !settings.enabled {
            return error_response(StatusCode::SERVICE_UNAVAILABLE, "资产社区已被管理员关闭");
        }
        if let Err(message) = validate_publish(&req, &settings) {
            return error_response(StatusCode::BAD_REQUEST, &message);
        }
    }
    let settings = guard.community.settings.clone();
    let data = &mut guard.community;
    let stamp = now_string();
    let asset_id = new_id();

    let source = match (req.hosted, req.external_url) {
        (Some(hosted), _) => {
            let path = community_uploads_dir(&state).join(&hosted.stored_name);
            if !tokio::fs::try_exists(&path).await.unwrap_or(false) {
                return error_response(StatusCode::BAD_REQUEST, "托管文件不存在，请重新上传");
            }
            AssetSource::Hosted {
                stored_name: hosted.stored_name,
                file_name: hosted.file_name,
                mime: if hosted.mime.is_empty() {
                    "application/octet-stream".to_string()
                } else {
                    hosted.mime
                },
                size: hosted.size,
                sha256: hosted.sha256,
            }
        }
        (None, Some(url)) => AssetSource::External { url: url.trim().to_string() },
        _ => unreachable!("validate_publish 已保证二选一"),
    };

    let status = if settings.require_review {
        AssetStatus::Pending
    } else {
        AssetStatus::Approved
    };

    let asset = CommunityAsset {
        id: asset_id.clone(),
        owner_id: user_id.clone(),
        owner_name,
        owner_avatar,
        title: req.title.trim().to_string(),
        description: req.description.trim().to_string(),
        category: req.category.trim().to_string(),
        bases: req.bases,
        tags: req.tags,
        version: req.version.trim().to_string(),
        price: req.price,
        source,
        status,
        downloads: 0,
        purchases: 0,
        downloaders: Default::default(),
        buyers: Default::default(),
        created_at: stamp.clone(),
        updated_at: stamp,
        review_note: String::new(),
    };
    data.assets.insert(asset_id.clone(), asset);

    // 首次发布奖励（可在后台配置，0 表示关闭）
    let mut granted = 0i64;
    if settings.first_publish_grant > 0 && !data.first_publish_granted.iter().any(|id| id == &user_id) {
        data.first_publish_granted.push(user_id.clone());
        granted = settings.first_publish_grant;
        let after = {
            let account = ensure_account(data, &user_id);
            account.balance += granted;
            account.earned += granted;
            account.balance
        };
        push_ledger(data, &user_id, granted, after, "first_publish", Some(&asset_id));
        push_notification(
            data,
            &user_id,
            "points_granted",
            "首次发布奖励到账",
            &format!("你第一次在资产社区发布内容，获得 {granted} 日豆。"),
            Some(&asset_id),
        );
    }

    if status == AssetStatus::Pending {
        push_notification(
            data,
            &user_id,
            "asset_pending",
            "资产已提交审核",
            "管理员审核通过后其他用户就能看到它。",
            Some(&asset_id),
        );
    }

    crate::schedule_persist(&state);
    Json(json!({
        "success": true,
        "asset_id": asset_id,
        "status": status.as_str(),
        "granted_points": granted,
    }))
    .into_response()
}

// ─── 客户端：下载 / 购买 ────────────────────────────────────────────────────

pub async fn download_asset(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    Path(asset_id): Path<String>,
) -> Response {
    let token = current_client_token(&state, &user_id).await.unwrap_or_default();
    let mut guard = state.data.write().await;
    let data = &mut guard.community;
    if let Err(resp) = require_community_enabled(data) {
        return resp;
    }
    let outcome = match apply_download(data, &user_id, &asset_id) {
        Ok(outcome) => outcome,
        Err(message) => return error_response(StatusCode::BAD_REQUEST, &message),
    };
    let download_url = match data.assets.get(&asset_id).map(|asset| asset.source.clone()) {
        Some(AssetSource::Hosted { .. }) => {
            Some(format!("/api/client/community/files/{asset_id}?t={token}"))
        }
        Some(AssetSource::External { url }) => Some(url),
        None => None,
    };
    crate::schedule_persist(&state);
    Json(json!({
        "success": true,
        "download_url": download_url,
        "reward_to_owner": outcome.reward,
        "first_time": outcome.first_time,
    }))
    .into_response()
}

pub async fn buy_asset(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    Path(asset_id): Path<String>,
) -> Response {
    let token = current_client_token(&state, &user_id).await.unwrap_or_default();
    let mut guard = state.data.write().await;
    let data = &mut guard.community;
    if let Err(resp) = require_community_enabled(data) {
        return resp;
    }
    let outcome = match apply_purchase(data, &user_id, &asset_id) {
        Ok(outcome) => outcome,
        Err(message) => return error_response(StatusCode::BAD_REQUEST, &message),
    };
    let download_url = match data.assets.get(&asset_id).map(|asset| asset.source.clone()) {
        Some(AssetSource::Hosted { .. }) => {
            Some(format!("/api/client/community/files/{asset_id}?t={token}"))
        }
        Some(AssetSource::External { url }) => Some(url),
        None => None,
    };
    crate::schedule_persist(&state);
    Json(json!({
        "success": true,
        "price": outcome.price,
        "payout_to_owner": outcome.payout,
        "commission": outcome.commission,
        "buyer_balance": outcome.buyer_balance,
        "download_url": download_url,
    }))
    .into_response()
}

/// 托管文件下载。`?t=` 里带 client token，因为浏览器无法给 `location.href` 加自定义头。
pub async fn download_file(
    State(state): State<AppState>,
    Path(asset_id): Path<String>,
    Query(query): Query<HashMap<String, String>>,
) -> Response {
    let token = query.get("t").cloned().unwrap_or_default();
    let Some(user_id) = current_user_for_token(&state, &token).await else {
        return error_response(StatusCode::UNAUTHORIZED, "缺少或无效的客户端令牌");
    };

    let (source, owner_id, price) = {
        let guard = state.data.read().await;
        match guard.community.assets.get(&asset_id) {
            Some(asset) => (asset.source.clone(), asset.owner_id.clone(), asset.price),
            None => return error_response(StatusCode::NOT_FOUND, "资产不存在"),
        }
    };
    let AssetSource::Hosted {
        stored_name,
        file_name,
        mime,
        size,
        ..
    } = source
    else {
        return error_response(StatusCode::BAD_REQUEST, "该资产是外部链接，不需要服务器转发");
    };

    if price > 0 && owner_id != user_id {
        let guard = state.data.read().await;
        let bought = guard
            .community
            .assets
            .get(&asset_id)
            .map(|asset| asset.buyers.contains_key(&user_id))
            .unwrap_or(false);
        if !bought {
            return error_response(StatusCode::PAYMENT_REQUIRED, "请先购买该资产");
        }
    }

    let path = community_uploads_dir(&state).join(&stored_name);
    let file = match tokio::fs::File::open(&path).await {
        Ok(file) => file,
        Err(error) => {
            return error_response(
                StatusCode::INTERNAL_SERVER_ERROR,
                &format!("读取文件失败：{error}"),
            )
        }
    };

    // 流式回包：托管文件上限 512 MiB，一次性 `read` 会在服务端留下同样大小的
    // 内存峰值。改成按块从磁盘读、按块写回客户端，峰值只跟块大小相关。
    let stream = tokio_util::io::ReaderStream::new(file);
    let mut response = Response::new(axum::body::Body::from_stream(stream));
    response.headers_mut().insert(
        header::CONTENT_TYPE,
        axum::http::HeaderValue::from_str(&mime)
            .unwrap_or_else(|_| axum::http::HeaderValue::from_static("application/octet-stream")),
    );
    if size > 0 {
        if let Ok(value) = axum::http::HeaderValue::from_str(&size.to_string()) {
            response.headers_mut().insert(header::CONTENT_LENGTH, value);
        }
    }
    let safe_name = sanitize_file_name(&file_name);
    response.headers_mut().insert(
        header::CONTENT_DISPOSITION,
        axum::http::HeaderValue::from_str(&format!(
            "attachment; filename*=UTF-8''{}",
            urlencode(&safe_name)
        ))
        .unwrap_or_else(|_| axum::http::HeaderValue::from_static("attachment")),
    );
    response
}

pub async fn delete_asset(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    Json(action): Json<AssetAction>,
) -> Response {
    let mut guard = state.data.write().await;
    let data = &mut guard.community;
    let Some(asset) = data.assets.get(&action.asset_id).cloned() else {
        return error_response(StatusCode::NOT_FOUND, "资产不存在");
    };
    if asset.owner_id != user_id {
        return error_response(StatusCode::FORBIDDEN, "只能删除自己发布的资产");
    }
    remove_asset_files(&state, &asset).await;
    data.assets.remove(&action.asset_id);
    crate::schedule_persist(&state);
    Json(json!({ "success": true })).into_response()
}

// ─── 客户端：日豆与通知 ─────────────────────────────────────────────────────

pub async fn points_overview(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    let account = data.accounts.get(&user_id).cloned().unwrap_or_default();
    let ledger: Vec<&LedgerEntry> = data
        .ledger
        .iter()
        .filter(|entry| entry.user_id == user_id)
        .rev()
        .take(50)
        .collect();
    Json(json!({
        "success": true,
        "balance": account.balance,
        "earned": account.earned,
        "spent": account.spent,
        "ledger": ledger,
        "reward_per_download": data.settings.reward_per_download,
        "today_reward": today_reward_total(data, &user_id),
        "daily_reward_cap": data.settings.daily_reward_cap,
    }))
    .into_response()
}

pub async fn notifications(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
    Query(query): Query<NotificationQuery>,
) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    let limit = query.limit.unwrap_or(30).clamp(1, 100) as usize;
    let list = data.notifications.get(&user_id).cloned().unwrap_or_default();
    let unread = list.iter().filter(|item| !item.read).count();
    let items: Vec<CommunityNotification> = list.into_iter().rev().take(limit).collect();
    Json(json!({ "success": true, "unread": unread, "items": items })).into_response()
}

pub async fn mark_notifications_read(
    State(state): State<AppState>,
    Extension(user_id): Extension<String>,
) -> Response {
    let mut guard = state.data.write().await;
    let mut changed = 0;
    if let Some(list) = guard.community.notifications.get_mut(&user_id) {
        for item in list.iter_mut() {
            if !item.read {
                item.read = true;
                changed += 1;
            }
        }
    }
    if changed > 0 {
        crate::schedule_persist(&state);
    }
    Json(json!({ "success": true, "changed": changed })).into_response()
}

// ─── 管理员 ─────────────────────────────────────────────────────────────────

pub async fn admin_settings_get(State(state): State<AppState>) -> Response {
    let guard = state.data.read().await;
    Json(json!({ "success": true, "settings": guard.community.settings })).into_response()
}

pub async fn admin_settings_save(
    State(state): State<AppState>,
    Json(mut settings): Json<CommunitySettings>,
) -> Response {
    if let Err(message) = settings.validate() {
        return error_response(StatusCode::BAD_REQUEST, &message);
    }
    let mut guard = state.data.write().await;
    guard.community.settings = settings;
    crate::schedule_persist(&state);
    Json(json!({ "success": true })).into_response()
}

pub async fn admin_assets(State(state): State<AppState>, Query(query): Query<ListQuery>) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    let status_filter = query.price.clone().unwrap_or_default(); // 复用 price 槽位传 status
    let mut items: Vec<&CommunityAsset> = data
        .assets
        .values()
        .filter(|asset| status_filter.is_empty() || asset.status.as_str() == status_filter)
        .collect();
    items.sort_by(|a, b| b.created_at.cmp(&a.created_at));
    let payload: Vec<Value> = items
        .into_iter()
        .map(|asset| asset_view(data, asset, ""))
        .collect();
    Json(json!({ "success": true, "items": payload, "total": payload.len() })).into_response()
}

pub async fn admin_moderate(
    State(state): State<AppState>,
    Json(req): Json<ModerateRequest>,
) -> Response {
    let mut guard = state.data.write().await;
    let data = &mut guard.community;
    let Some(asset) = data.assets.get(&req.asset_id).cloned() else {
        return error_response(StatusCode::NOT_FOUND, "资产不存在");
    };
    match req.action.as_str() {
        "approve" => {
            if let Some(entry) = data.assets.get_mut(&req.asset_id) {
                entry.status = AssetStatus::Approved;
                entry.review_note = req.note.clone();
                entry.updated_at = now_string();
            }
            push_notification(
                data,
                &asset.owner_id,
                "asset_approved",
                "资产审核通过",
                &format!("「{}」已通过审核，现在会出现在资产社区。", asset.title),
                Some(&req.asset_id),
            );
        }
        "reject" => {
            if let Some(entry) = data.assets.get_mut(&req.asset_id) {
                entry.status = AssetStatus::Rejected;
                entry.review_note = req.note.clone();
                entry.updated_at = now_string();
            }
            let body = if req.note.is_empty() {
                format!("「{}」未通过审核。", asset.title)
            } else {
                format!("「{}」未通过审核：{}", asset.title, req.note)
            };
            push_notification(
                data,
                &asset.owner_id,
                "asset_rejected",
                "资产审核未通过",
                &body,
                Some(&req.asset_id),
            );
        }
        "hide" => {
            if let Some(entry) = data.assets.get_mut(&req.asset_id) {
                entry.status = AssetStatus::Hidden;
                entry.review_note = req.note.clone();
                entry.updated_at = now_string();
            }
            let body = if req.note.is_empty() {
                format!("「{}」已被管理员下架。", asset.title)
            } else {
                format!("「{}」已被管理员下架：{}", asset.title, req.note)
            };
            push_notification(
                data,
                &asset.owner_id,
                "asset_hidden",
                "资产已下架",
                &body,
                Some(&req.asset_id),
            );
        }
        "delete" => {
            remove_asset_files(&state, &asset).await;
            data.assets.remove(&req.asset_id);
            let body = if req.note.is_empty() {
                format!("「{}」已被管理员删除。", asset.title)
            } else {
                format!("「{}」已被管理员删除：{}", asset.title, req.note)
            };
            push_notification(
                data,
                &asset.owner_id,
                "asset_deleted",
                "资产已删除",
                &body,
                Some(&req.asset_id),
            );
        }
        other => return error_response(StatusCode::BAD_REQUEST, &format!("未知操作：{other}")),
    }
    crate::schedule_persist(&state);
    Json(json!({ "success": true })).into_response()
}

pub async fn admin_grant_points(
    State(state): State<AppState>,
    Json(req): Json<GrantRequest>,
) -> Response {
    if req.amount == 0 || req.amount.abs() > 1_000_000 {
        return error_response(StatusCode::BAD_REQUEST, "调整数量必须在 ±1000000 以内且不为 0");
    }
    let mut guard = state.data.write().await;
    let known_user = guard.users.contains_key(&req.user_id)
        || guard.community.accounts.contains_key(&req.user_id);
    if !known_user {
        return error_response(StatusCode::BAD_REQUEST, "该用户不存在");
    }
    let data = &mut guard.community;
    let after = {
        let account = ensure_account(data, &req.user_id);
        account.balance += req.amount;
        if req.amount > 0 {
            account.earned += req.amount;
        } else {
            account.spent += -req.amount;
        }
        account.balance
    };
    let reason = if req.reason.trim().is_empty() {
        "admin_adjust".to_string()
    } else {
        format!("admin:{}", req.reason.trim())
    };
    push_ledger(data, &req.user_id, req.amount, after, &reason, None);
    push_notification(
        data,
        &req.user_id,
        "points_admin",
        "日豆变动",
        &format!(
            "管理员调整了你的日豆：{}{}，当前余额 {}。",
            if req.amount > 0 { "+" } else { "" },
            req.amount,
            after
        ),
        None,
    );
    crate::schedule_persist(&state);
    Json(json!({ "success": true, "balance": after })).into_response()
}

pub async fn admin_ledger(State(state): State<AppState>, Query(query): Query<NotificationQuery>) -> Response {
    let guard = state.data.read().await;
    let data = &guard.community;
    let limit = query.limit.unwrap_or(100).clamp(1, 500) as usize;
    let items: Vec<&LedgerEntry> = data.ledger.iter().rev().take(limit).collect();
    let total_issued: i64 = data.accounts.values().map(|account| account.balance).sum();
    Json(json!({
        "success": true,
        "items": items,
        "total_balance_in_circulation": total_issued,
        "asset_count": data.assets.len(),
    }))
    .into_response()
}

// ─── 内部辅助 ────────────────────────────────────────────────────────────────

fn community_uploads_dir(state: &AppState) -> std::path::PathBuf {
    let parent = state
        .data_file
        .parent()
        .map(|path| path.to_path_buf())
        .unwrap_or_else(|| std::path::PathBuf::from("."));
    parent.join("uploads").join("community")
}

async fn current_user_for_token(state: &AppState, token: &str) -> Option<String> {
    if token.is_empty() {
        return None;
    }
    let clients = state.clients.read().await;
    clients
        .values()
        .find(|client| client.client_token == token)
        .map(|client| client.user_id.clone())
}

async fn current_client_token(state: &AppState, user_id: &str) -> Option<String> {
    let clients = state.clients.read().await;
    clients
        .values()
        .find(|client| client.user_id == user_id)
        .map(|client| client.client_token.clone())
}

async fn remove_asset_files(state: &AppState, asset: &CommunityAsset) {
    if let AssetSource::Hosted { stored_name, .. } = &asset.source {
        let path = community_uploads_dir(state).join(stored_name);
        let _ = tokio::fs::remove_file(path).await;
    }
}

fn sanitize_file_name(raw: &str) -> String {
    let cleaned: String = raw
        .chars()
        .filter(|c| !matches!(c, '/' | '\\' | '\0' | ':' | '*' | '?' | '"' | '<' | '>' | '|'))
        .collect();
    cleaned.trim().trim_matches('.').chars().take(120).collect()
}

fn urlencode(value: &str) -> String {
    let mut out = String::with_capacity(value.len());
    for byte in value.as_bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                out.push(*byte as char)
            }
            _ => out.push_str(&format!("%{byte:02X}")),
        }
    }
    out
}

// ─── 单测 ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture(price: u64) -> (CommunityData, String, String) {
        let mut data = CommunityData::default();
        data.settings.reward_per_download = 10;
        data.settings.daily_reward_cap = 1000;
        let owner = "usr_owner".to_string();
        let buyer = "usr_buyer".to_string();
        data.accounts.insert(owner.clone(), PointsAccount::default());
        data.accounts.insert(
            buyer.clone(),
            PointsAccount {
                balance: 100,
                ..Default::default()
            },
        );
        let asset = CommunityAsset {
            id: "asset_1".into(),
            owner_id: owner.clone(),
            owner_name: "Owner".into(),
            owner_avatar: String::new(),
            title: "Kikyo 头发".into(),
            description: String::new(),
            category: "hair".into(),
            bases: vec!["Kikyo".into()],
            tags: vec![],
            version: "1.0".into(),
            price,
            source: AssetSource::External {
                url: "https://example.com/a.zip".into(),
            },
            status: AssetStatus::Approved,
            downloads: 0,
            purchases: 0,
            downloaders: Default::default(),
            buyers: Default::default(),
            created_at: "2026-01-01 00:00:00".into(),
            updated_at: "2026-01-01 00:00:00".into(),
            review_note: String::new(),
        };
        data.assets.insert(asset.id.clone(), asset);
        (data, owner, buyer)
    }

    #[test]
    fn purchase_moves_points_and_records_ledger() {
        let (mut data, owner, buyer) = fixture(30);
        let outcome = apply_purchase(&mut data, &buyer, "asset_1").expect("purchase ok");
        assert_eq!(outcome.price, 30);
        assert_eq!(outcome.payout, 30); // 默认抽成 0
        assert_eq!(data.accounts[&buyer].balance, 70);
        assert_eq!(data.accounts[&owner].balance, 30);
        assert_eq!(data.assets["asset_1"].purchases, 1);
        assert_eq!(data.ledger.len(), 2);
    }

    #[test]
    fn purchase_rejects_insufficient_balance_and_duplicate() {
        let (mut data, _owner, buyer) = fixture(200);
        assert!(apply_purchase(&mut data, &buyer, "asset_1").is_err());

        let (mut data, _owner, buyer) = fixture(30);
        apply_purchase(&mut data, &buyer, "asset_1").unwrap();
        assert!(apply_purchase(&mut data, &buyer, "asset_1").is_err());
    }

    #[test]
    fn commission_is_taken_from_payout() {
        let (mut data, owner, buyer) = fixture(100);
        data.settings.purchase_commission_percent = 20;
        let outcome = apply_purchase(&mut data, &buyer, "asset_1").unwrap();
        assert_eq!(outcome.commission, 20);
        assert_eq!(outcome.payout, 80);
        assert_eq!(data.accounts[&owner].balance, 80);
    }

    #[test]
    fn free_download_rewards_owner_once_per_user() {
        let (mut data, owner, buyer) = fixture(0);
        let first = apply_download(&mut data, &buyer, "asset_1").unwrap();
        assert!(first.first_time);
        assert_eq!(first.reward, 10);
        assert_eq!(data.accounts[&owner].balance, 10);

        let second = apply_download(&mut data, &buyer, "asset_1").unwrap();
        assert!(!second.first_time);
        assert_eq!(second.reward, 0);
        assert_eq!(data.accounts[&owner].balance, 10);
    }

    #[test]
    fn daily_reward_cap_limits_payout() {
        let (mut data, _owner, _buyer) = fixture(0);
        data.settings.daily_reward_cap = 5;
        let outcome = apply_download(&mut data, "usr_buyer", "asset_1").unwrap();
        assert_eq!(outcome.reward, 5);
    }

    #[test]
    fn paid_asset_requires_purchase_before_download() {
        let (mut data, _owner, buyer) = fixture(20);
        assert!(apply_download(&mut data, &buyer, "asset_1").is_err());
        apply_purchase(&mut data, &buyer, "asset_1").unwrap();
        assert!(apply_download(&mut data, &buyer, "asset_1").is_ok());
    }

    #[test]
    fn owner_cannot_buy_own_asset() {
        let (mut data, owner, _buyer) = fixture(20);
        assert!(apply_purchase(&mut data, &owner, "asset_1").is_err());
    }

    #[test]
    fn settings_validation_rejects_bad_ranges() {
        let mut settings = CommunitySettings::default();
        settings.max_upload_mb = 0;
        assert!(settings.validate().is_err());

        let mut settings = CommunitySettings::default();
        settings.min_price = 50;
        settings.max_price = 10;
        assert!(settings.validate().is_err());

        let mut settings = CommunitySettings::default();
        settings.purchase_commission_percent = 200;
        assert!(settings.validate().is_err());

        let mut settings = CommunitySettings::default();
        settings.signup_grant = -5;
        assert!(settings.validate().is_err());
        let mut settings = CommunitySettings::default();
        settings.signup_grant = 200_000;
        assert!(settings.validate().is_err());
        let mut settings = CommunitySettings::default();
        settings.signup_grant = 88;
        assert!(settings.validate().is_ok());
    }

    #[test]
    fn external_url_requires_https_and_allowlist() {
        let mut settings = CommunitySettings::default();
        settings.external_host_allowlist = vec!["booth.pm".into()];
        assert!(validate_external_url("http://booth.pm/x", &settings).is_err());
        assert!(validate_external_url("https://evil.example.com/x", &settings).is_err());
        assert!(validate_external_url("https://booth.pm/x", &settings).is_ok());
        assert!(validate_external_url("https://shop.booth.pm/x", &settings).is_ok());
    }

    #[test]
    fn publish_title_bounds_enforced() {
        let settings = CommunitySettings::default();
        let req = PublishRequest {
            title: "a".into(),
            description: String::new(),
            category: "hair".into(),
            bases: vec![],
            tags: vec![],
            version: "1.0".into(),
            price: 0,
            hosted: None,
            external_url: Some("https://example.com/a.zip".into()),
        };
        assert!(validate_publish(&req, &settings).is_err());
    }
}
