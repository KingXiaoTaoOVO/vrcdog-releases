# VRCDog Standalone Server

This directory is a self-contained server project that implements the same HTTP
API used by the embedded VRCDog server. It can run on Windows or Linux, or be
deployed with Docker.

For a production-oriented 1Panel deployment, see
[`docs/deployment/1panel-vrcdog-server.md`](../docs/deployment/1panel-vrcdog-server.md).
The current compatibility and security limits are tracked in
[`docs/audits/vrcdog-server-feature-adaptation.md`](../docs/audits/vrcdog-server-feature-adaptation.md).

## Run with Rust

```bash
cp .env.example .env
cargo run --release
```

The default endpoint is `http://0.0.0.0:11451`. In VRCDog, enter server mode,
verify the administrator password, choose **Remote service**, and enter the
public URL of this server.

## Run with Docker

```bash
docker compose up -d --build
```

Persisted users, bans, freezes, and roles are stored in
`data/server-state.json`. Surveys and submissions use the same file. Keep the
`data` directory on a persistent volume.

## Reverse proxy

The server speaks plain HTTP. For an internet-facing deployment, place it
behind Caddy, Nginx, or another TLS reverse proxy and connect with an HTTPS URL.
The client requires the base URL only, without `/ping`.

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `VRCDOG_HOST` | `0.0.0.0` | Listening interface |
| `VRCDOG_PORT` | `11451` | Listening port |
| `VRCDOG_DATA_FILE` | `./data/server-state.json` | JSON persistence path |
| `VRCDOG_SERVER_PASSWORD_BCRYPT` | Hash for `root` | BCrypt hash used by the remote administration API |
| `RUST_LOG` | `vrcdog_server=info,tower_http=info` | Log filtering |

## Health check

```bash
curl http://127.0.0.1:11451/ping
```
## Deploy with a prebuilt Linux binary

When the target host cannot pull Docker base images, build the server on a Linux
builder and place the binary at `bin/vrcdog-server`:

```bash
cargo build --release --locked
mkdir -p bin
cp target/release/vrcdog-server bin/
chmod +x bin/vrcdog-server
```

`docker-compose.override.yml` bind-mounts `./bin` into the container and uses it
as the entrypoint. `update.sh` keeps `vrcdog-server/bin` during `git clean` and
runs `docker compose up -d` without `--build` when the binary is present. If
GitHub is unreachable, it exits without resetting the working tree so the
current prebuilt version stays online.