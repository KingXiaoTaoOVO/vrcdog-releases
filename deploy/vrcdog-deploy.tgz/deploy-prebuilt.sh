#!/usr/bin/env bash
# VRCDog 预编译二进制部署脚本
# 用法：在 /opt/VRCDog 下执行  bash deploy-prebuilt.sh
# 作用：用部署包里的 bin/vrcdog-server 与 website-dist 覆盖线上，重启容器，做健康检查。
# 不会删除 data/ 与 .env，不会重新编译 Rust。
set -eu

REPO_DIR="${REPO_DIR:-/opt/VRCDog}"
SERVER_DIR="$REPO_DIR/vrcdog-server"
SITE_DIR="${SITE_DIR:-/opt/1panel/apps/openresty/openresty/www/sites/vrcdog.pcb.im/index}"
BIND_PORT="${VRCDOG_BIND_PORT:-21451}"

if [ ! -d "$REPO_DIR" ]; then
  echo "[x] 仓库目录不存在：$REPO_DIR"
  exit 1
fi
if [ ! -f "$SERVER_DIR/bin/vrcdog-server" ]; then
  echo "[x] 缺少 $SERVER_DIR/bin/vrcdog-server"
  exit 1
fi

echo "[1/4] 校验预编译二进制"
chmod +x "$SERVER_DIR/bin/vrcdog-server"
ls -lh "$SERVER_DIR/bin/vrcdog-server"
if command -v file >/dev/null 2>&1; then
  file "$SERVER_DIR/bin/vrcdog-server" || true
fi

echo "[2/4] 覆盖官网静态资源 -> $SITE_DIR"
mkdir -p "$SITE_DIR"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete "$REPO_DIR/website-dist/" "$SITE_DIR/"
else
  rm -rf "$SITE_DIR"
  mkdir -p "$SITE_DIR"
  \cp -rf "$REPO_DIR/website-dist/." "$SITE_DIR/"
fi
chmod -R 755 "$SITE_DIR" 2>/dev/null || true
echo "     index.html      $(stat -c%s "$SITE_DIR/index.html" 2>/dev/null || echo '?') bytes"
echo "     admin-ui.html   $(stat -c%s "$SITE_DIR/admin-ui.html" 2>/dev/null || echo '?') bytes"

echo "[3/4] 重启后端容器（--no-build，直接运行 bin/ 里的预编译二进制）"
cd "$SERVER_DIR"
mkdir -p data
chown -R 10001:10001 data 2>/dev/null || true
chmod -R 777 data 2>/dev/null || true
docker compose up -d --no-build --force-recreate
docker exec openresty nginx -s reload 2>/dev/null || true
sleep 5

echo "[4/4] 健康检查"
echo -n "  后端 /admin               : "
curl -s -o /tmp/_vd_admin.html -w "%{http_code} %{size_download} bytes\n" -m 8 "http://127.0.0.1:${BIND_PORT}/admin" || true
echo -n "  后端 /api/site/captcha    : "
curl -s -m 8 "http://127.0.0.1:${BIND_PORT}/api/site/captcha" | head -c 90 || true
echo
echo -n "  后端 POST /api/site/visit : "
curl -s -o /dev/null -w "%{http_code}\n" -m 8 -X POST -H 'content-type: application/json' \
  -d '{"path":"/deploy-check"}' "http://127.0.0.1:${BIND_PORT}/api/site/visit" || true
echo -n "  官网首页                  : "
curl -s -o /dev/null -w "%{http_code}\n" -m 8 "https://vrcdog.pcb.im/" || true
echo -n "  官网 /feedback/           : "
curl -s -o /dev/null -w "%{http_code}\n" -m 8 "https://vrcdog.pcb.im/feedback/" || true
echo -n "  官网 /admin               : "
curl -s -o /tmp/_vd_web_admin.html -w "%{http_code} %{size_download} bytes\n" -m 8 "https://vrcdog.pcb.im/admin" || true

echo
echo "部署完成。上面 /admin 的字节数应约为 77000，/api/site/captcha 应返回 {\"success\":true...。"
